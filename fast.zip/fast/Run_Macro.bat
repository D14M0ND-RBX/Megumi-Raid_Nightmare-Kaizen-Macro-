@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

Title Megumi Raid Nightmare

where py >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_EXE=py"
    set "PYTHON_ARGS=-3"
) else (
    where python >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_EXE=python"
        set "PYTHON_ARGS="
    ) else (
        echo [INFO] Python was not found on this machine.
        echo [INFO] Trying automatic install...

        where winget >nul 2>&1
        if not errorlevel 1 (
            winget install --id Python.Python.3.12 --source winget --accept-source-agreements --accept-package-agreements
            if errorlevel 1 (
                echo [WARN] winget could not install Python automatically.
                echo [INFO] Downloading Python installer from python.org...
                powershell -ExecutionPolicy Bypass -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\python312-installer.exe'; Start-Process -FilePath '%TEMP%\python312-installer.exe' -ArgumentList '/quiet InstallAllUsers=1 PrependPath=1' -Wait"
            )
        ) else (
            echo [WARN] winget is unavailable.
            echo [INFO] Please install Python 3.12 from https://www.python.org/downloads/windows/
            pause
            exit /b 1
        )

        where py >nul 2>&1
        if not errorlevel 1 (
            set "PYTHON_EXE=py"
            set "PYTHON_ARGS=-3"
        ) else (
            where python >nul 2>&1
            if not errorlevel 1 (
                set "PYTHON_EXE=python"
                set "PYTHON_ARGS="
            ) else (
                echo [ERROR] Python is still missing after the install attempt.
                pause
                exit /b 1
            )
        )
    )
)

echo [INFO] Updating pip and required packages...
%PYTHON_EXE% %PYTHON_ARGS% -m pip install --upgrade pip
if exist requirements.txt (
    %PYTHON_EXE% %PYTHON_ARGS% -m pip install -r requirements.txt
) else (
    %PYTHON_EXE% %PYTHON_ARGS% -m pip install mss opencv-python numpy pyautogui pydirectinput
)

echo [INFO] Starting Megumi Raid Nightmare...
%PYTHON_EXE% %PYTHON_ARGS% Megumi_Raid_Nightmare.py

if errorlevel 1 (
    echo [ERROR] The macro exited with an error.
)

pause

"""Megumi Raid Nightmare - made by Diamond/Lemon.

Retry / Megumi / Mahoraga image watcher for a 3440x1440 screen.

Requires: pip install mss opencv-python numpy pyautogui pydirectinput

Behavior (all three images are scanned every POLL_DELAY seconds, non-stop):
  * Retry.png found    -> stop whatever is running, glide to it, click 5x, repeat.
  * Megumi.png found   -> only acts if armed (armed again after each Retry click):
                          wait 5s, make sure slot 2/3 is equipped, hold W 1s,
                          press Q twice, wait 4.5s, spam X/C/V.
  * Slot 2/3 icons     -> scanned every POLL_DELAY in their own thread; the moment a slot
                          shows unequipped (and none is equipped) its key is pressed.
  * timer.png (22:00)  -> time limit: everything stops, then Esc, R, Enter (0.4s apart),
                          then the macro carries on.
  * Mahoraga.png found -> spam Z/X/C/V/R until Retry.png is found.

A small separate window shows "Loops" (one per Retry detected) and "Time" (how long the
macro has been running). The console shows one tidy, colour-coded line per event.
"""

import ctypes
import os
import queue
import signal
import threading
import time
import traceback
from pathlib import Path

import cv2
import mss
import numpy as np
import pyautogui  # unused directly, but importing it makes the process DPI-aware (correct coordinates)
import pydirectinput

ROOT = Path(__file__).resolve().parent

RETRY_PATH = ROOT / "Retry.png"
RETRY_REGION = (876, 841, 995, 887)  # left, top, right, bottom
RETRY_THRESHOLD = 0.70

MEGUMI_PATH = ROOT / "Megumi.png"
MEGUMI_REGION = (749, 122, 978, 155)
MEGUMI_THRESHOLD = 0.75

MAHORAGA_PATH = ROOT / "Mahoraga.png"
MAHORAGA_REGION = (749, 122, 978, 155)  # same banner box as Megumi
MAHORAGA_THRESHOLD = 0.75

# The banner regions above are only 33px tall but the templates are 30-34px, so
# the templates barely fit. This many extra pixels are scanned around them.
BANNER_PAD = 12

# Debug: print the best match score of each image once a second, and save what the
# script actually sees (debug_*.png) on startup. Set to False once it works.
DEBUG = False
DEBUG_INTERVAL = 1.0

POLL_DELAY = 0.05
CLICK_COUNT = 5
RETRY_MOVE_DELAY = 3.5  # wait after Retry is detected before the mouse starts moving
GLIDE_DURATION = 0.8
HOME_POS = (858, 926)     # cursor goes here when Retry is detected, and back here after clicking
HOME_GLIDE_DURATION = 0.6
CLICK_HOLD = 0.05  # how long each click stays pressed
CONSOLE_CLEAR_INTERVAL = 15 * 60

# Time limit: when the 22:00 image shows up, stop everything and press Esc, R, Enter.
TIMER_PATH = ROOT / "timer.png"
TIMER_REGION = (472, 46, 613, 102)  # left, top, right, bottom
TIMER_THRESHOLD = 0.92  # high on purpose: 20:00 / 21:00 etc. look very similar to 22:00
TIMER_CONFIRM_FRAMES = 2  # scans in a row before acting
TIMER_PAD = 6
TIMER_KEYS = ("esc", "r", "enter")
TIMER_KEY_DELAY = 0.4  # seconds between each key
TIMER_COOLDOWN = 30.0  # ignore the timer this long after a reset so it can't loop

# Long-run safety
CAPTURE_REFRESH_INTERVAL = 10 * 60  # re-create the screen-capture handle this often
STALL_SECONDS = 30  # warn if a scanner thread stops responding for this long

MEGUMI_START_DELAY = 5.0  # wait after Megumi is detected before doing anything
MEGUMI_KEYS = ("x", "c", "v")
MEGUMI_SPAM_DELAY = 4.5  # wait after the Q combo before spamming (0 = spam immediately)
MAHORAGA_KEYS = ("z", "x", "c", "v", "r")
KEY_DELAY = 0.05

# Hotbar slot check (replaces the old blind "press 2"). Scans for the slot 2 / slot 3
# icons; if one is shown unequipped, its key is pressed. Nothing is pressed if a slot is
# already equipped, so the key can't toggle it off.
SLOT_FILES = {
    ("2", "eq"): "Equipted2.png",
    ("2", "un"): "UnEquipted2.png",
    ("3", "eq"): "Equipted3.png",
    ("3", "un"): "UnEquipted3.png",
}
# Both slots sit inside (694, 1290)-(860, 1368); slot 2 is the left half, slot 3 the right.
SLOT_REGIONS = {
    "2": (694, 1290, 777, 1368),  # left, top, right, bottom
    "3": (777, 1290, 860, 1368),
}
SLOT_PAD = 6               # extra pixels scanned around each slot box (the icons nearly fill it)
EQUIP_THRESHOLD = 0.85
EQUIP_TRIES = 3            # extra presses if the slot still looks unequipped
EQUIP_RECHECK_DELAY = 0.5  # seconds to wait after a press before looking again
CONSTANT_EQUIP = True      # scan the slots in the main loop and equip whenever unequipped
EQUIP_COOLDOWN = 0.2       # minimum seconds between slot key presses (avoids double-toggling)
EQUIP_PAUSE_DURING_MEGUMI_WAIT = True  # no auto-equip during Megumi's 5s start delay
KEY_HOLD = 0.03          # how long each key stays down; instant taps can get dropped by games
AFTER_FOCUS_DELAY = 0.3  # let the game window settle after being focused, before the first key

# "Defeat Ma" / "Defeat Me" look almost identical, so a banner must win this many scans
# IN A ROW before the script acts on it (stops flicker from starting the wrong routine).
CONFIRM_FRAMES = 5

# Exact title of the game window. Keys are sent to whichever window has focus, and
# when you start the script from a terminal that's the terminal, not the game.
# Set to None to disable auto-focus.
GAME_WINDOW_TITLE = "Roblox"

pydirectinput.PAUSE = 0  # remove the built-in 0.1s delay after every call
pydirectinput.FAILSAFE = False  # a cursor parked in a screen corner must not raise and kill a thread

shutdown = threading.Event()

# ---- per-round state (only touched under state_lock) -----------------------
state_lock = threading.Lock()
current_stop = None      # Event for the running key routine, if any
current_thread = None
current_name = None      # "megumi" / "mahoraga" / None
megumi_armed = True      # Megumi may only trigger when armed; re-armed by a Retry click


# ---- console output ---------------------------------------------------------
APP_NAME = "Megumi Raid Nightmare"
CREDIT = "made by Diamond/Lemon"
USE_COLOR = True  # colour-coded tags; set False if your console shows odd characters
STATS_WINDOW = True  # small always-on-top window with Loops / Time

if USE_COLOR and os.name == "nt":
    os.system("")  # switches on ANSI colour support in the Windows console

TAG_COLORS = {
    "RETRY": "92", "MEGUMI": "95", "MAHORAGA": "91", "EQUIP": "96", "TIMER": "94",
    "SWITCH": "93", "WARN": "93", "ERROR": "91", "INFO": "37", "DEBUG": "90",
}

# All console output goes through a queue and one printer thread. If the console ever
# stalls (e.g. text selected in an old-style console window), only the printer waits -
# the scanning threads keep running instead of freezing on a print().
_CLEAR = object()
_log_queue = queue.SimpleQueue()


def _printer():
    while True:
        item = _log_queue.get()
        if item is None:
            return
        try:
            if item is _CLEAR:
                os.system("cls")
            else:
                print(item, flush=True)
        except Exception:
            pass


_printer_thread = threading.Thread(target=_printer, daemon=True)
_printer_thread.start()


def emit(line):
    _log_queue.put(line)


def log(tag, message):
    """One aligned line per event: time, coloured tag, message."""
    stamp = time.strftime("%H:%M:%S")
    if USE_COLOR:
        line = f"\033[90m{stamp}\033[0m  \033[{TAG_COLORS.get(tag, '37')}m{tag:<8}\033[0m {message}"
    else:
        line = f"{stamp}  {tag:<8} {message}"
    emit(line)


def print_header():
    bar = "=" * 50
    emit(bar)
    emit(f"  {APP_NAME.upper():<34}Ctrl+C = exit")
    emit(f"  \033[90m{CREDIT}\033[0m" if USE_COLOR else f"  {CREDIT}")
    emit(bar)
    emit("  Watching   Retry | Megumi | Mahoraga | Slots 2 & 3 | Timer")
    emit(f"  Scan rate  every {POLL_DELAY:.2f}s")
    emit("  Stats      separate window (Loops / Time)" if STATS_WINDOW else "  Stats      off")
    emit(bar)


ERROR_LOG = ROOT / "macro_errors.log"


def log_crash(name, exc):
    """Show a short error in the console and keep the full traceback in macro_errors.log."""
    log("ERROR", f"{name} crashed: {exc!r} (details in {ERROR_LOG.name})")
    try:
        with open(ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] {name} crashed | "
                    f"loops={loop_count} | uptime={format_uptime(time.monotonic() - start_time)}\n")
            f.write(traceback.format_exc())
    except Exception:
        pass


def disable_quickedit():
    """Stop clicking in an old-style console window from pausing the whole program."""
    try:
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-10)  # STD_INPUT_HANDLE
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, (mode.value | 0x0080) & ~0x0040)
    except Exception:
        pass


# ---- stats: loops + uptime ---------------------------------------------------
start_time = time.monotonic()
loop_count = 0  # +1 every time Retry is detected
loop_lock = threading.Lock()


def format_uptime(seconds):
    hours, rest = divmod(int(seconds), 3600)
    minutes, secs = divmod(rest, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def run_stats_window():
    """Small separate window showing Loops and Time. Runs on the main thread and returns
    when the window is closed (the macro keeps running) or on shutdown. Returns False if
    tkinter isn't available."""
    try:
        import tkinter as tk
    except Exception:
        return False
    try:
        root = tk.Tk()
    except Exception:
        return False

    bg, label_fg, value_fg = "#15171c", "#8b93a7", "#e8ecf4"
    root.title(APP_NAME)
    root.configure(bg=bg)
    root.attributes("-topmost", True)
    root.resizable(False, False)

    frame = tk.Frame(root, bg=bg, padx=18, pady=12)
    frame.pack()
    rows = {}
    for row, name in enumerate(("Loops", "Time")):
        tk.Label(frame, text=f"{name} :", bg=bg, fg=label_fg,
                 font=("Consolas", 13), anchor="w").grid(row=row, column=0, sticky="w", pady=2)
        value = tk.Label(frame, text="", bg=bg, fg=value_fg,
                         font=("Consolas", 20, "bold"), anchor="e", width=9)
        value.grid(row=row, column=1, sticky="e", padx=(14, 0), pady=2)
        rows[name] = value

    tk.Label(frame, text=CREDIT, bg=bg, fg="#5b6274",
             font=("Consolas", 8)).grid(row=2, column=0, columnspan=2, pady=(6, 0))

    # Park it in the top-right corner, away from the game's scan areas.
    root.update_idletasks()
    x = max(0, root.winfo_screenwidth() - root.winfo_width() - 24)
    root.geometry(f"+{x}+24")

    # Don't let clicking this window pull keyboard focus away from the game.
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetParent(root.winfo_id())
        user32.SetWindowLongW(hwnd, -20, user32.GetWindowLongW(hwnd, -20) | 0x08000000)  # NOACTIVATE
    except Exception:
        pass

    def tick():
        if shutdown.is_set():
            root.destroy()
            return
        rows["Loops"].config(text=str(loop_count))
        rows["Time"].config(text=format_uptime(time.monotonic() - start_time))
        root.after(200, tick)

    tick()
    root.mainloop()
    return True


def load_gray(path):
    if not path.exists():
        here = ", ".join(sorted(f.name for f in ROOT.iterdir() if f.suffix.lower() == ".png")) or "none"
        raise SystemExit(f"\n[ERROR] {path.name} not found in {ROOT}\n"
                         f"        PNG files in that folder: {here}\n"
                         f"        (check for a hidden extension like 'Megumi.png.png' or 'Megumi (1).png')")
    img = cv2.imdecode(np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise SystemExit(f"\n[ERROR] {path.name} exists but isn't a readable image - re-save it as a real PNG.")
    return img


def grab_gray(sct, region):
    left, top, right, bottom = region
    shot = sct.grab({"left": left, "top": top, "width": right - left, "height": bottom - top})
    return cv2.cvtColor(np.array(shot), cv2.COLOR_BGRA2GRAY)


def pad_region(region, pad):
    left, top, right, bottom = region
    return max(0, left - pad), max(0, top - pad), right + pad, bottom + pad


last_scores = {"retry": 0.0, "megumi": 0.0, "mahoraga": 0.0, "timer": 0.0}


def find_retry(sct, template):
    screen = grab_gray(sct, RETRY_REGION)
    if template.shape[0] > screen.shape[0] or template.shape[1] > screen.shape[1]:
        return None
    result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
    _, score, _, loc = cv2.minMaxLoc(result)
    last_scores["retry"] = float(score)
    if score < RETRY_THRESHOLD:
        return None
    h, w = template.shape[:2]
    return RETRY_REGION[0] + loc[0] + w // 2, RETRY_REGION[1] + loc[1] + h // 2, float(score)


def find_timer(sct, template):
    """Score of the best match for the 22:00 image inside the timer box."""
    screen = grab_gray(sct, pad_region(TIMER_REGION, TIMER_PAD))
    if template.shape[0] > screen.shape[0] or template.shape[1] > screen.shape[1]:
        return 0.0
    result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
    score = float(cv2.minMaxLoc(result)[1])
    last_scores["timer"] = score
    return score


def find_banner(sct, name, template, region):
    """Multi-scale match for a 'Defeat ..' banner. Returns (x, y, score), or None if the
    template can't fit. The caller applies the threshold."""
    region = pad_region(region, BANNER_PAD)
    screen = grab_gray(sct, region)
    best = None
    for scale in (0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1.0, 1.05, 1.10, 1.15):
        w = max(8, int(template.shape[1] * scale))
        h = max(8, int(template.shape[0] * scale))
        if w > screen.shape[1] or h > screen.shape[0]:
            continue
        resized = cv2.resize(template, (w, h), interpolation=cv2.INTER_AREA)
        result = cv2.matchTemplate(screen, resized, cv2.TM_CCOEFF_NORMED)
        _, score, _, loc = cv2.minMaxLoc(result)
        if best is None or score > best[0]:
            best = (float(score), loc, w, h)
    if best is None:
        return None
    last_scores[name] = best[0]
    score, loc, w, h = best
    return region[0] + loc[0] + w // 2, region[1] + loc[1] + h // 2, score


# ---- hotbar slot equip ------------------------------------------------------
slot_templates = {}
equip_lock = threading.Lock()
last_equip_press = 0.0
equip_hold_until = 0.0  # no auto-equip before this time (Megumi's start delay)
retry_active = threading.Event()  # set while the Retry sequence runs; auto-equip pauses
timer_active = threading.Event()  # set while the time-limit reset runs; auto-equip pauses
last_timer_time = -1e9
heartbeat = {"scanner": 0.0, "equip": 0.0}  # last time each scan thread looped


def load_slot_templates():
    for key, name in SLOT_FILES.items():
        slot_templates[key] = load_gray(ROOT / name)


def scan_slots(sct):
    """Return {"2": (state, score, None), ...} for each slot whose icon is found."""
    padded = {slot: pad_region(region, SLOT_PAD) for slot, region in SLOT_REGIONS.items()}
    box = (min(r[0] for r in padded.values()), min(r[1] for r in padded.values()),
           max(r[2] for r in padded.values()), max(r[3] for r in padded.values()))
    whole = grab_gray(sct, box)  # one small capture covering both slots

    found = {}
    for slot, (left, top, right, bottom) in padded.items():
        screen = whole[top - box[1]:bottom - box[1], left - box[0]:right - box[0]]
        scores = {}
        for state in ("eq", "un"):
            tpl = slot_templates[(slot, state)]
            if tpl.shape[0] > screen.shape[0] or tpl.shape[1] > screen.shape[1]:
                scores[state] = 0.0
                continue
            result = cv2.matchTemplate(screen, tpl, cv2.TM_CCOEFF_NORMED)
            scores[state] = float(cv2.minMaxLoc(result)[1])
        if scores["eq"] >= EQUIP_THRESHOLD and scores["eq"] > scores["un"]:
            found[slot] = ("equipped", scores["eq"], None)
        elif scores["un"] >= EQUIP_THRESHOLD:
            found[slot] = ("unequipped", scores["un"], None)
    return found


def press_slot(slot):
    """Press a slot key unless one was pressed very recently. The main loop and the
    Megumi routine both use this, so together they can't press twice and toggle it off."""
    global last_equip_press
    with equip_lock:
        if time.perf_counter() - last_equip_press < EQUIP_COOLDOWN:
            return False
        tap(slot)
        last_equip_press = time.perf_counter()
        return True


def equip_tick(sct):
    """Called every loop: press the key of a slot that shows unequipped."""
    if time.perf_counter() < equip_hold_until:
        return
    found = scan_slots(sct)
    if not found or any(v[0] == "equipped" for v in found.values()):
        return
    slot = min(found)  # slot 2 before slot 3
    if press_slot(slot):
        log("EQUIP", f"Slot {slot} was unequipped, pressed {slot}")


def equip_watcher():
    """Own thread: checks the slots every POLL_DELAY, independent of the slower banner
    scans, so a slot that gets unequipped is re-equipped right away."""
    while not shutdown.is_set():
        with mss.MSS() as sct:  # fresh capture handle every CAPTURE_REFRESH_INTERVAL
            session_start = time.monotonic()
            while not shutdown.is_set() and time.monotonic() - session_start < CAPTURE_REFRESH_INTERVAL:
                loop_start = time.perf_counter()
                heartbeat["equip"] = time.monotonic()
                if not retry_active.is_set() and not timer_active.is_set():
                    equip_tick(sct)
                time.sleep(max(0.0, POLL_DELAY - (time.perf_counter() - loop_start)))


def equip_slot(stop):
    """Megumi step: make sure slot 2/3 is equipped before moving on (a few tries)."""
    with mss.MSS() as sct:
        for attempt in range(EQUIP_TRIES + 1):
            if stop.is_set():
                return
            found = scan_slots(sct)
            if not found:
                log("WARN", "Neither slot 2 nor 3 found in the hotbar boxes, skipping equip")
                return
            summary = ", ".join(f"slot {s} {v[0]}" for s, v in sorted(found.items()))
            if any(v[0] == "equipped" for v in found.values()):
                log("EQUIP", f"{'Equipped' if attempt else 'Already equipped'} ({summary})")
                return
            if attempt == EQUIP_TRIES:
                log("WARN", f"Still unequipped after {EQUIP_TRIES} tries ({summary})")
                return
            slot = min(found)
            if press_slot(slot):
                log("EQUIP", f"{summary}, pressed {slot}")
            if stop.wait(EQUIP_RECHECK_DELAY):
                return


# ---- window focus -----------------------------------------------------------
_warned_no_window = False


def focus_game():
    """Bring the game window to the front so key presses reach it (Windows only)."""
    global _warned_no_window
    if not GAME_WINDOW_TITLE:
        return
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def visit(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if buf.value.strip().lower() == GAME_WINDOW_TITLE.lower():
                found.append(hwnd)
        return True

    user32.EnumWindows(visit, 0)
    if not found:
        if not _warned_no_window:
            log("WARN", f"No window titled '{GAME_WINDOW_TITLE}' found, click the game yourself")
            _warned_no_window = True
        return
    hwnd = found[0]
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.keybd_event(0x12, 0, 0, 0)  # tap Alt so Windows allows the focus change
    user32.keybd_event(0x12, 0, 2, 0)
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.15)


# ---- key routines -----------------------------------------------------------
def tap(key):
    pydirectinput.keyDown(key)
    try:
        time.sleep(KEY_HOLD)
    finally:
        pydirectinput.keyUp(key)


ALL_KEYS = ("w", "q", "z", "x", "c", "v", "r", "2", "3", "esc", "enter")


def release_keys(keys=("w",)):
    """Make sure keys are up (a crash mid-press must not leave W held down)."""
    for key in keys:
        try:
            pydirectinput.keyUp(key)
        except Exception:
            pass


def spam_keys(stop, keys):
    while not stop.is_set() and not shutdown.is_set():
        for key in keys:
            if stop.is_set() or shutdown.is_set():
                return
            tap(key)
            time.sleep(KEY_DELAY)


def megumi_routine(stop):
    if MEGUMI_START_DELAY and stop.wait(MEGUMI_START_DELAY):
        return
    log("MEGUMI", "Combo started (equip check, W 1s, Q x2)")
    focus_game()
    if stop.wait(AFTER_FOCUS_DELAY):
        return
    equip_slot(stop)
    if stop.is_set():
        return
    if stop.wait(0.1):
        return
    pydirectinput.keyDown("w")
    try:
        stop.wait(1.0)
    finally:
        pydirectinput.keyUp("w")
    if stop.is_set():
        return
    tap("q")
    if stop.wait(0.1):
        return
    tap("q")
    if MEGUMI_SPAM_DELAY and stop.wait(MEGUMI_SPAM_DELAY):
        return
    log("MEGUMI", "Combo done, spamming X C V")
    spam_keys(stop, MEGUMI_KEYS)


def mahoraga_routine(stop):
    focus_game()
    if stop.wait(AFTER_FOCUS_DELAY):
        return
    spam_keys(stop, MAHORAGA_KEYS)


def stop_routine():
    """Stop the running key routine (if any) and wait for it to finish."""
    global current_stop, current_thread, current_name
    with state_lock:
        stop, thread = current_stop, current_thread
        current_stop, current_thread, current_name = None, None, None
    if stop is not None:
        stop.set()
    if thread is not None:
        thread.join(timeout=1.5)
    release_keys()  # never leave W held


def _run_routine(name, target, stop):
    """Run a key routine; if it crashes, log it and free the slot so it can start again."""
    global current_stop, current_thread, current_name
    try:
        target(stop)
    except Exception as exc:
        log_crash(name, exc)
        release_keys(ALL_KEYS)
        with state_lock:
            if current_stop is stop:
                current_stop, current_thread, current_name = None, None, None


def start_routine(name, target):
    """Replace whatever is running with a new routine."""
    global current_stop, current_thread, current_name
    if current_name is not None:
        log("SWITCH", f"{current_name} -> {name}")
    stop_routine()
    stop = threading.Event()
    thread = threading.Thread(target=_run_routine, args=(name, target, stop), daemon=True)
    with state_lock:
        current_stop, current_thread, current_name = stop, thread, name
    thread.start()


# ---- retry click ------------------------------------------------------------
class _Point(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def glide_to(x, y, duration):
    """Smooth mouse glide. pyautogui.moveTo only takes ~16 steps for a 0.8s move,
    which looks choppy, so this moves by elapsed time instead of by step count."""
    user32 = ctypes.windll.user32
    start = _Point()
    user32.GetCursorPos(ctypes.byref(start))
    sx, sy = start.x, start.y
    t0 = time.perf_counter()
    while True:
        t = (time.perf_counter() - t0) / duration
        if t >= 1.0:
            break
        e = t * t * t * (t * (t * 6 - 15) + 10)  # smootherstep: gentle start and stop
        user32.SetCursorPos(int(sx + (x - sx) * e), int(sy + (y - sy) * e))
        time.sleep(0.002)
    user32.SetCursorPos(int(x), int(y))


def click_retry(x, y, score):
    global megumi_armed, equip_hold_until, loop_count
    detected_at = time.perf_counter()
    retry_active.set()  # pause auto-equip while the Retry sequence runs
    try:
        with loop_lock:
            loop_count += 1
            loop_no = loop_count
        log("RETRY", f"Found ({score:.2f}), loop #{loop_no}, clicking in {RETRY_MOVE_DELAY:g}s")
        stop_routine()
        if HOME_POS:  # first, park the cursor at the home spot
            glide_to(HOME_POS[0], HOME_POS[1], HOME_GLIDE_DURATION)
            pydirectinput.moveTo(*HOME_POS)
        # the 3.5s is counted from the moment Retry was detected
        time.sleep(max(0.0, RETRY_MOVE_DELAY - (time.perf_counter() - detected_at)))
        glide_to(x, y, GLIDE_DURATION)
        time.sleep(0.15)
        pydirectinput.moveTo(x, y)  # real mouse-move event so the game registers the hover
        time.sleep(0.1)
        for i in range(CLICK_COUNT):
            pydirectinput.mouseDown(button="left")
            time.sleep(CLICK_HOLD)  # hold briefly; instant press/release can get ignored
            pydirectinput.mouseUp(button="left")
            time.sleep(0.08)
        time.sleep(0.5)
        if HOME_POS:
            glide_to(HOME_POS[0], HOME_POS[1], HOME_GLIDE_DURATION)
            pydirectinput.moveTo(*HOME_POS)  # real move event so the game sees the cursor arrive
        log("RETRY", f"Clicked x{CLICK_COUNT}, cursor back home")
    finally:
        megumi_armed = True  # Megumi may trigger again after this Retry
        equip_hold_until = 0.0
        retry_active.clear()


def run_timer_reset(score):
    """Time limit reached: stop everything, press Esc, R, Enter, then carry on."""
    global megumi_armed, equip_hold_until, last_timer_time
    timer_active.set()  # pause auto-equip so it can't press keys in the middle of this
    try:
        log("TIMER", f"22:00 found ({score:.2f}), stopping everything")
        stop_routine()
        focus_game()
        time.sleep(AFTER_FOCUS_DELAY)
        for i, key in enumerate(TIMER_KEYS):
            if i:
                time.sleep(TIMER_KEY_DELAY)
            tap(key)
        log("TIMER", "Sent " + ", ".join(k.capitalize() for k in TIMER_KEYS) + ", resuming")
    finally:
        last_timer_time = time.perf_counter()
        megumi_armed = True  # fresh start: the Megumi combo may run again
        equip_hold_until = 0.0
        timer_active.clear()


# ---- main watcher -----------------------------------------------------------
def watcher():
    global megumi_armed, equip_hold_until
    retry_t = load_gray(RETRY_PATH)
    megumi_t = load_gray(MEGUMI_PATH)
    mahoraga_t = load_gray(MAHORAGA_PATH)
    timer_t = load_gray(TIMER_PATH)

    last_debug = 0.0
    saved_debug = False
    streak_label, streak = None, 0
    timer_streak = 0
    while not shutdown.is_set():
        with mss.MSS() as sct:  # fresh capture handle every CAPTURE_REFRESH_INTERVAL
            session_start = time.monotonic()
            if DEBUG and not saved_debug:
                saved_debug = True
                for name, region in (("retry", RETRY_REGION),
                                     ("banner", pad_region(MEGUMI_REGION, BANNER_PAD)),
                                     ("timer", pad_region(TIMER_REGION, TIMER_PAD))):
                    cv2.imwrite(str(ROOT / f"debug_{name}_region.png"), grab_gray(sct, region))
                log("DEBUG", "Saved debug_retry_region.png, debug_banner_region.png, debug_timer_region.png")

            while not shutdown.is_set() and time.monotonic() - session_start < CAPTURE_REFRESH_INTERVAL:
                loop_start = time.perf_counter()
                heartbeat["scanner"] = time.monotonic()

                if DEBUG and loop_start - last_debug >= DEBUG_INTERVAL:
                    last_debug = loop_start
                    log("DEBUG", "scores retry={retry:.2f} megumi={megumi:.2f} "
                                 "mahoraga={mahoraga:.2f} timer={timer:.2f}".format(**last_scores))

                # 1) Retry always has top priority
                match = find_retry(sct, retry_t)
                if match:
                    click_retry(*match)
                    continue

                # 2) Time limit: 22:00 on screen -> everything stops, Esc / R / Enter
                timer_score = find_timer(sct, timer_t)
                if (timer_score >= TIMER_THRESHOLD
                        and time.perf_counter() - last_timer_time >= TIMER_COOLDOWN):
                    timer_streak += 1
                    if timer_streak >= TIMER_CONFIRM_FRAMES:
                        timer_streak = 0
                        run_timer_reset(timer_score)
                        continue
                else:
                    timer_streak = 0

                # 3) Banners. "Defeat Ma" and "Defeat Me" differ by one letter, so each
                #    template also scores high on the other banner. Score both on the same
                #    frame and only act on the better match.
                mah = find_banner(sct, "mahoraga", mahoraga_t, MAHORAGA_REGION)
                meg = find_banner(sct, "megumi", megumi_t, MEGUMI_REGION)
                mah_score = mah[2] if mah else 0.0
                meg_score = meg[2] if meg else 0.0

                if mah_score >= MAHORAGA_THRESHOLD and mah_score > meg_score:
                    label = "mahoraga"
                elif meg_score >= MEGUMI_THRESHOLD and meg_score >= mah_score:
                    label = "megumi"
                else:
                    label = None

                # only act once the same banner has won several scans in a row
                if label == streak_label:
                    streak += 1
                else:
                    streak_label, streak = label, 1

                if label and streak >= CONFIRM_FRAMES:
                    if label == "mahoraga":
                        # Mahoraga: always scanned; takes over from Megumi if it shows up
                        if current_name != "mahoraga":
                            log("MAHORAGA", f"Detected ({mah_score:.2f}), spamming Z X C V R until Retry")
                            start_routine("mahoraga", mahoraga_routine)
                    elif megumi_armed and current_name != "mahoraga":
                        # Megumi: always scanned, but only acts when armed (re-armed by Retry)
                        log("MEGUMI", f"Detected ({meg_score:.2f}), starting in {MEGUMI_START_DELAY:g}s")
                        megumi_armed = False
                        if EQUIP_PAUSE_DURING_MEGUMI_WAIT:
                            equip_hold_until = time.perf_counter() + MEGUMI_START_DELAY
                        start_routine("megumi", megumi_routine)

                # sleep only the remaining time so the loop targets POLL_DELAY total
                elapsed = time.perf_counter() - loop_start
                time.sleep(max(0.0, POLL_DELAY - elapsed))


def supervised(name, fn):
    """Run fn until shutdown. If it crashes (screen capture hiccup, bad frame, ...), log it,
    free any held keys and start it again instead of silently dying."""
    while not shutdown.is_set():
        try:
            fn()
            return
        except Exception as exc:
            log_crash(name, exc)
            release_keys(ALL_KEYS)
            retry_active.clear()
            timer_active.clear()
            if shutdown.wait(2.0):
                return
            log("INFO", f"Restarting {name}")


def watchdog():
    """Warn if a scanner thread stops looping (can't be restarted, but the log shows it)."""
    warned = set()
    while not shutdown.wait(5.0):
        now = time.monotonic()
        for name, beat in list(heartbeat.items()):
            if name == "equip" and not CONSTANT_EQUIP:
                continue
            age = now - beat
            if age > STALL_SECONDS and name not in warned:
                warned.add(name)
                log("WARN", f"{name} thread has not responded for {age:.0f}s")
            elif age <= STALL_SECONDS and name in warned:
                warned.discard(name)
                log("INFO", f"{name} thread is responding again")


def console_cleaner():
    while not shutdown.wait(CONSOLE_CLEAR_INTERVAL):
        _log_queue.put(_CLEAR)
        print_header()
        log("INFO", f"Console cleared | Loops: {loop_count} | Time: {format_uptime(time.monotonic() - start_time)}")


def main():
    for path in (RETRY_PATH, MEGUMI_PATH, MAHORAGA_PATH, TIMER_PATH):  # fail early, clearly
        load_gray(path)
    load_slot_templates()
    # Ctrl+C just raises the shutdown flag; every loop (and the stats window) watches it.
    signal.signal(signal.SIGINT, lambda *_: shutdown.set())
    try:
        ctypes.windll.kernel32.SetConsoleTitleW(APP_NAME)  # console window title (Windows)
    except Exception:
        pass
    disable_quickedit()
    print_header()
    heartbeat["scanner"] = heartbeat["equip"] = time.monotonic()
    threading.Thread(target=supervised, args=("scanner", watcher), daemon=True).start()
    if CONSTANT_EQUIP:
        threading.Thread(target=supervised, args=("equip scanner", equip_watcher), daemon=True).start()
    threading.Thread(target=console_cleaner, daemon=True).start()
    threading.Thread(target=watchdog, daemon=True).start()
    try:
        if STATS_WINDOW and not run_stats_window():
            log("WARN", "tkinter not available, stats window disabled")
        elif STATS_WINDOW and not shutdown.is_set():
            log("INFO", "Stats window closed, macro still running (Ctrl+C to exit)")
        while not shutdown.is_set():
            time.sleep(0.25)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown.set()
        stop_routine()
        release_keys(ALL_KEYS)
        log("INFO", f"Stopped | Loops: {loop_count} | Time: {format_uptime(time.monotonic() - start_time)}")
        _log_queue.put(None)  # let the printer thread flush the last lines
        _printer_thread.join(timeout=1.0)


if __name__ == "__main__":
    main()

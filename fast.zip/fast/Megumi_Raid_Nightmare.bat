@goto :mrn_start
r"""
:mrn_start
@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Megumi Raid Nightmare

rem ===========================================================================
rem  MEGUMI RAID NIGHTMARE - one file, launcher plus macro. Made by Diamond/Lemon
rem
rem  Double-click this file. It finds or installs Python, updates the libraries,
rem  then runs the macro code that is stored further down in this same file.
rem  Start it with  --settings  to reopen the settings window.
rem  The PNG images and settings.json live in the same folder as this file.
rem ===========================================================================

rem --- what to install when no usable Python is found - edit here to change it
set "PY_WINGET_ID=Python.Python.3.12"
set "PY_URL=https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
set "PY_PACKAGES=mss opencv-python numpy pyautogui pydirectinput"

rem --- 1. look for a Python that really works. The Microsoft Store python stub
rem        does not count: it only prints "Python was not found"
set "PYEXE="
call :try_python py -3
call :try_python python
if not defined PYEXE call :find_installed
if defined PYEXE goto :have_python

rem --- 2. none found: install one
echo.
echo [INFO] No usable Python 3.9 or newer with tkinter was found. Installing Python...
where winget >nul 2>&1
if not errorlevel 1 (
    echo [INFO] Installing %PY_WINGET_ID% with winget - this can take a minute...
    winget install --id %PY_WINGET_ID% --exact --source winget --silent --accept-source-agreements --accept-package-agreements
)
call :find_installed
if not defined PYEXE call :try_python py -3
if defined PYEXE goto :have_python

echo [INFO] Downloading the Python installer from python.org...
set "PY_SETUP=%TEMP%\mrn_python_setup.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%PY_URL%' -OutFile '%PY_SETUP%'"
if exist "%PY_SETUP%" (
    echo [INFO] Installing Python - please wait...
    start /wait "" "%PY_SETUP%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=1 Include_test=0 Shortcuts=0
    del "%PY_SETUP%" >nul 2>&1
)
call :find_installed
if not defined PYEXE call :try_python py -3
if defined PYEXE goto :have_python

echo.
echo [ERROR] Python could not be installed automatically.
echo         Install Python 3.12 from https://www.python.org/downloads/windows/
echo         and tick "Add python.exe to PATH", then run this file again.
pause
exit /b 1

rem --- 3. update pip and the libraries, then start the macro
:have_python
echo [INFO] Using Python: %PYEXE%
echo [INFO] Updating pip and the required libraries - a few seconds...
%PYEXE% -m pip install --upgrade --disable-pip-version-check --quiet --retries 1 --timeout 15 pip >nul 2>&1
if exist requirements.txt (
    %PYEXE% -m pip install --upgrade --disable-pip-version-check --quiet --retries 1 --timeout 15 -r requirements.txt
) else (
    %PYEXE% -m pip install --upgrade --disable-pip-version-check --quiet --retries 1 --timeout 15 %PY_PACKAGES%
)
%PYEXE% -c "import mss, cv2, numpy, pyautogui, pydirectinput" >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] A required library is missing and could not be installed.
    echo         Check your internet connection and run this file again.
    pause
    exit /b 1
)

echo [INFO] Starting Megumi Raid Nightmare...
echo.
%PYEXE% -x "%~f0" %*
set "MRN_EXIT=%errorlevel%"
echo.
if not "%MRN_EXIT%"=="0" echo [ERROR] The macro stopped with error code %MRN_EXIT%.
pause
exit /b %MRN_EXIT%

rem ---------------------------------------------------------------------------
rem  subroutine: test one way of starting Python. Keeps it only if it runs, is
rem  version 3.9 or newer, and has tkinter for the settings window.
rem ---------------------------------------------------------------------------
:try_python
if defined PYEXE exit /b 0
%* -c "import sys, tkinter; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=%*"
exit /b 0

rem --- subroutine: look in the usual install folders, because a Python that was
rem     just installed is not on PATH yet in this window
:find_installed
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do call :try_python "%%D\python.exe"
for /d %%D in ("%ProgramFiles%\Python3*") do call :try_python "%%D\python.exe"
for /d %%D in ("%LOCALAPPDATA%\Python\pythoncore-3*") do call :try_python "%%D\python.exe"
exit /b 0
"""
# ============================================================================
#  Everything below is the macro itself (Python). The batch launcher above is
#  wrapped in a string so Python ignores it, and Python's -x flag skips line 1.
# ============================================================================
"""Megumi Raid Nightmare - made by Diamond/Lemon.

Retry / Megumi / Mahoraga image watcher for a 3440x1440 screen.

Requires: pip install mss opencv-python numpy pyautogui pydirectinput

Behavior (all three images are scanned every POLL_DELAY seconds, non-stop):
  * Retry.png found    -> stop whatever is running, glide to it, click 5x, repeat.
  * Megumi.png found   -> only acts if armed (armed again after each Retry click):
                          wait 5s, make sure slot 2/3 is equipped, hold W 1s,
                          press Q twice, wait 4.5s, spam X/C/V.
  * Slot 2/3 icons     -> scanned every POLL_DELAY in their own thread; the moment a slot
                          shows unequipped (and none is equipped) its key is pressed.
  * timer.png (22:00)  -> time limit: everything stops, then Esc, R, Enter (0.4s apart),
                          then the macro carries on.
  * Mahoraga.png found -> spam Z/X/C/V/R until Retry.png is found.

A small separate window shows "Loops", "Rejoins", and "Time" (how long the
macro has been running). The console shows one tidy, colour-coded line per event.
"""

import copy
import ctypes
import json
import os
import queue
import signal
import sys
import threading
import time
import traceback
from pathlib import Path

import cv2
import mss
import numpy as np
import pyautogui  # unused directly, but importing it makes the process DPI-aware (correct coordinates)
import pydirectinput

ROOT = Path(__file__).resolve().parent
ACTIVITY_LOG = ROOT / "macro_activity.log"
_activity_log_lock = threading.Lock()
_activity_log_warning_sent = False

RETRY_PATH = ROOT / "Retry.png"
RETRY_REGION = (876, 841, 995, 887)  # left, top, right, bottom
RETRY_THRESHOLD = 0.70

MEGUMI_PATH = ROOT / "Megumi.png"
MEGUMI_REGION = (749, 122, 978, 155)
MEGUMI_THRESHOLD = 0.75

MAHORAGA_PATH = ROOT / "Mahoraga.png"
MAHORAGA_REGION = (749, 122, 978, 155)  # same banner box as Megumi
MAHORAGA_THRESHOLD = 0.75

# The banner regions above are only 33px tall but the templates are 30-34px, so
# the templates barely fit. This many extra pixels are scanned around them.
BANNER_PAD = 12

# Debug: print the best match score of each image once a second, and save what the
# script actually sees (debug_*.png) on startup. Set to False once it works.
DEBUG = False
DEBUG_INTERVAL = 1.0

POLL_DELAY = 0.05
CLICK_COUNT = 5
RETRY_MOVE_DELAY = 3.5  # wait after Retry is detected before the mouse starts moving
GLIDE_DURATION = 0.8
HOME_POS = (858, 926)     # cursor goes here when Retry is detected, and back here after clicking
HOME_GLIDE_DURATION = 0.6
CLICK_HOLD = 0.05  # how long each click stays pressed
CONSOLE_CLEAR_INTERVAL = 15 * 60

# Time limit: when the 22:00 image shows up, stop everything and press Esc, R, Enter.
TIMER_PATH = ROOT / "timer.png"
TIMER_REGION = (472, 46, 613, 102)  # left, top, right, bottom
TIMER_THRESHOLD = 0.92  # high on purpose: 20:00 / 21:00 etc. look very similar to 22:00
TIMER_CONFIRM_FRAMES = 2  # scans in a row before acting
TIMER_PAD = 6
TIMER_KEYS = ("esc", "r", "enter")
TIMER_KEY_DELAY = 0.4  # seconds between each key
TIMER_COOLDOWN = 30.0  # ignore the timer this long after a reset so it can't loop

# Long-run safety
CAPTURE_REFRESH_INTERVAL = 10 * 60  # re-create the screen-capture handle this often
STALL_SECONDS = 30  # warn if a scanner thread stops responding for this long

MEGUMI_START_DELAY = 5.0  # wait after Megumi is detected before doing anything
MEGUMI_KEYS = ("x", "c", "v")
MEGUMI_SPAM_DELAY = 4.5  # wait after the Q combo before spamming (0 = spam immediately)
MAHORAGA_KEYS = ("z", "x", "c", "v", "r")
KEY_DELAY = 0.05

# Hotbar slot check (replaces the old blind "press 2"). Scans for the slot 2 / slot 3
# icons; if one is shown unequipped, its key is pressed. Nothing is pressed if a slot is
# already equipped, so the key can't toggle it off.
SLOT_FILES = {
    ("2", "eq"): "Equipted2.png",
    ("2", "un"): "UnEquipted2.png",
    ("3", "eq"): "Equipted3.png",
    ("3", "un"): "UnEquipted3.png",
}
# Both slots sit inside (694, 1290)-(860, 1368); slot 2 is the left half, slot 3 the right.
SLOT_REGIONS = {
    "2": (694, 1290, 777, 1368),  # left, top, right, bottom
    "3": (777, 1290, 860, 1368),
}
SLOT_PAD = 6               # extra pixels scanned around each slot box (the icons nearly fill it)
EQUIP_THRESHOLD = 0.85
EQUIP_TRIES = 3            # extra presses if the slot still looks unequipped
EQUIP_RECHECK_DELAY = 0.5  # seconds to wait after a press before looking again
CONSTANT_EQUIP = True      # scan the slots in the main loop and equip whenever unequipped
EQUIP_COOLDOWN = 0.2       # minimum seconds between slot key presses (avoids double-toggling)
EQUIP_PAUSE_DURING_MEGUMI_WAIT = True  # no auto-equip during Megumi's 5s start delay
KEY_HOLD = 0.03          # how long each key stays down; instant taps can get dropped by games
AFTER_FOCUS_DELAY = 0.3  # let the game window settle after being focused, before the first key

# "Defeat Ma" / "Defeat Me" look almost identical, so a banner must win this many scans
# IN A ROW before the script acts on it (stops flicker from starting the wrong routine).
CONFIRM_FRAMES = 5

# Exact title of the game window. Keys are sent to whichever window has focus, and
# when you start the script from a terminal that's the terminal, not the game.
# Set to None to disable auto-focus.
GAME_WINDOW_TITLE = "Roblox"
REJOIN_ENABLED = False
SNAP_ROBLOX_AFTER_REJOIN = True
ROBLOX_SNAP_REGION = (0, 0, 3438, 1378)
ROBLOX_SNAP_TARGET = (0, 664)
REJOIN_AREAS = {}
REJOIN_MENU_WAIT = 20.0
PORTAL_ARROW_INTERVAL = 0.5
PORTAL_MOVE_HOLD = 0.5
PORTAL_PLAYER_ANCHOR = (860, 1008)
PORTAL_STEER_DEADZONE = 70
REJOIN_SEARCH_SCROLL_WAIT = 2.5
REJOIN_SEARCH_SCROLL_COUNT = 10
REJOIN_SEARCH_SCROLL_DURATION = 2.0
REJOIN_SCROLL_INTERVAL = 0.5
SLOT_MISSING_TIMEOUT = 300.0
REJOIN_THRESHOLD = 0.80
REJOIN_STEP_THRESHOLDS = {8: 0.65, 17: 0.68, 18: 0.68}
REJOIN_MATCH_PAD = 16
PORTAL_ATTEMPT_TIMEOUT = 30.0
REJOIN_ACTIVE = threading.Event()
REJOIN_REQUESTED = threading.Event()

REJOIN_STEP_NAMES = {
    1: "Servers heading", 2: "Private server Join", 3: "Gamemodes", 4: "Raids tab",
    5: "Roblox menu icon", 6: "Leave menu item", 7: "Leave confirmation",
    8: "Roblox app icon", 9: "Launch Roblox", 10: "Search field", 11: "Kaizen result",
    12: "Raid selection", 13: "Raid card", 14: "Nightmare", 15: "Create lobby",
    16: "Portal", 17: "Roblox titlebar (blue)", 18: "Roblox titlebar (gray)",
    19: "Start raid button",
}
REJOIN_TEMPLATE_FILES = {
    1: "rejoin_01_servers.png", 2: "rejoin_02_private_server_join.png",
    3: "rejoin_03_gamemodes.png", 4: "rejoin_04_raids_tab.png",
    5: "rejoin_05_roblox_icon.png", 6: "rejoin_06_leave_hint.png",
    7: "rejoin_07_leave_confirm.png", 8: "rejoin_08_roblox_app_icon.png",
    9: "rejoin_09_launch_roblox.png", 10: "rejoin_10_search.png",
    11: "rejoin_11_kaizen.png", 12: "rejoin_12_raid_selection.png",
    13: "rejoin_13_raid_card_select.png", 14: "rejoin_14_nightmare.png",
    15: "rejoin_15_create_lobby.png", 16: "Portal.png",
    17: "rejoin_17_roblox_titlebar_blue.png", 18: "rejoin_18_roblox_titlebar_gray.png",
    19: "rejoin_19_start_raid.png",
}

pydirectinput.PAUSE = 0  # remove the built-in 0.1s delay after every call
pydirectinput.FAILSAFE = False  # a cursor parked in a screen corner must not raise and kill a thread
pyautogui.PAUSE = 0
pyautogui.FAILSAFE = False

shutdown = threading.Event()
game_available = threading.Event()

# ---- per-round state (only touched under state_lock) -----------------------
state_lock = threading.Lock()
current_stop = None      # Event for the running key routine, if any
current_thread = None
current_name = None      # "megumi" / "mahoraga" / None
megumi_armed = True      # Megumi may only trigger when armed; re-armed by a Retry click


# ---- console output ---------------------------------------------------------
# Filled in by apply_settings() from the settings window / settings.json
TEMPLATE_SCALE = 1.0
RESOLUTION_LABEL = ""
ENABLE_MEGUMI = True
ENABLE_MAHORAGA = True
ENABLE_TIMER = True
ENABLE_AUTO_EQUIP = True

APP_NAME = "Megumi Raid Nightmare"
CREDIT = "made by Diamond/Lemon"
USE_COLOR = True  # colour-coded tags; set False if your console shows odd characters
STATS_WINDOW = True  # small always-on-top window with Loops / Rejoins / Time

if USE_COLOR and os.name == "nt":
    os.system("")  # switches on ANSI colour support in the Windows console

TAG_COLORS = {
    "RETRY": "92", "MEGUMI": "95", "MAHORAGA": "91", "EQUIP": "96", "TIMER": "94",
    "SWITCH": "93", "WARN": "93", "ERROR": "91", "INFO": "37", "DEBUG": "90",
}

# All console output goes through a queue and one printer thread. If the console ever
# stalls (e.g. text selected in an old-style console window), only the printer waits -
# the scanning threads keep running instead of freezing on a print().
_CLEAR = object()
_log_queue = queue.SimpleQueue()


def _printer():
    while True:
        item = _log_queue.get()
        if item is None:
            return
        try:
            if item is _CLEAR:
                os.system("cls")
            else:
                print(item, flush=True)
        except Exception:
            pass


_printer_thread = threading.Thread(target=_printer, daemon=True)
_printer_thread.start()


def emit(line):
    _log_queue.put(line)


def log(tag, message, console=True):
    """Write events to the activity log, optionally echoing them to the console."""
    global _activity_log_warning_sent
    stamp = time.strftime("%H:%M:%S")
    audit_line = f"{time.strftime('%Y-%m-%d')} {stamp} [{tag}] {message}"
    if USE_COLOR:
        line = f"\033[90m{stamp}\033[0m  \033[{TAG_COLORS.get(tag, '37')}m{tag:<8}\033[0m {message}"
    else:
        line = f"{stamp}  {tag:<8} {message}"
    try:
        with _activity_log_lock:
            with open(ACTIVITY_LOG, "a", encoding="utf-8") as activity_file:
                activity_file.write(audit_line + "\n")
                activity_file.flush()
    except Exception as exc:
        if not _activity_log_warning_sent:
            _activity_log_warning_sent = True
            emit(f"[LOG ERROR] Could not write {ACTIVITY_LOG.name}: {exc}")
    if console:
        emit(line)


def print_header():
    bar = "=" * 50
    emit(bar)
    emit(f"  {APP_NAME.upper():<34}Ctrl+C = exit")
    emit(f"  \033[90m{CREDIT}\033[0m" if USE_COLOR else f"  {CREDIT}")
    emit(bar)
    watching = ["Retry"]
    if ENABLE_MEGUMI:
        watching.append("Megumi")
    if ENABLE_MAHORAGA:
        watching.append("Mahoraga")
    if ENABLE_AUTO_EQUIP:
        watching.append("Slots 2 & 3")
    if ENABLE_TIMER:
        watching.append("Timer")
    emit("  Watching   " + " | ".join(watching))
    if RESOLUTION_LABEL:
        emit(f"  Setup      {RESOLUTION_LABEL}")
    emit(f"  Scan rate  every {POLL_DELAY:.2f}s")
    emit("  Stats      separate window (Loops / Rejoins / Time)" if STATS_WINDOW else "  Stats      off")
    emit(bar)


ERROR_LOG = ROOT / "macro_errors.log"


def log_crash(name, exc):
    """Show a short error and persist the traceback in both diagnostic logs."""
    log("ERROR", f"{name} crashed: {exc!r} (details in {ERROR_LOG.name})")
    details = traceback.format_exc()
    try:
        with open(ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] {name} crashed | "
                    f"loops={loop_count} | rejoins={rejoin_count} | "
                    f"uptime={format_uptime(time.monotonic() - start_time)}\n")
            f.write(details)
        with _activity_log_lock:
            with open(ACTIVITY_LOG, "a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [TRACEBACK] {name}\n{details}\n")
    except Exception:
        pass


def disable_quickedit():
    """Stop clicking in an old-style console window from pausing the whole program."""
    try:
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-10)  # STD_INPUT_HANDLE
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, (mode.value | 0x0080) & ~0x0040)
    except Exception:
        pass


# ---- stats: loops + uptime ---------------------------------------------------
start_time = time.monotonic()
loop_count = 0  # +1 every time Retry is detected
rejoin_count = 0  # +1 each time an automatic rejoin sequence starts
loop_lock = threading.Lock()


def format_uptime(seconds):
    hours, rest = divmod(int(seconds), 3600)
    minutes, secs = divmod(rest, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def run_stats_window():
    """Small separate window showing Loops, Rejoins, and Time. Runs on the main thread and returns
    when the window is closed (the macro keeps running) or on shutdown. Returns False if
    tkinter isn't available."""
    try:
        import tkinter as tk
    except Exception:
        return False
    try:
        root = tk.Tk()
    except Exception:
        return False

    bg, label_fg, value_fg = "#15171c", "#8b93a7", "#e8ecf4"
    root.title(APP_NAME)
    root.configure(bg=bg)
    root.attributes("-topmost", True)
    root.resizable(False, False)

    frame = tk.Frame(root, bg=bg, padx=18, pady=12)
    frame.pack()
    rows = {}
    for row, name in enumerate(("Loops", "Rejoins", "Time")):
        tk.Label(frame, text=f"{name} :", bg=bg, fg=label_fg,
                 font=("Consolas", 13), anchor="w").grid(row=row, column=0, sticky="w", pady=2)
        value = tk.Label(frame, text="", bg=bg, fg=value_fg,
                         font=("Consolas", 20, "bold"), anchor="e", width=9)
        value.grid(row=row, column=1, sticky="e", padx=(14, 0), pady=2)
        rows[name] = value

    tk.Label(frame, text=CREDIT, bg=bg, fg="#5b6274",
             font=("Consolas", 8)).grid(row=3, column=0, columnspan=2, pady=(6, 0))

    # Park it in the top-right corner, away from the game's scan areas.
    root.update_idletasks()
    x = max(0, root.winfo_screenwidth() - root.winfo_width() - 24)
    root.geometry(f"+{x}+24")

    # Don't let clicking this window pull keyboard focus away from the game.
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetParent(root.winfo_id())
        user32.SetWindowLongW(hwnd, -20, user32.GetWindowLongW(hwnd, -20) | 0x08000000)  # NOACTIVATE
    except Exception:
        pass

    def tick():
        if shutdown.is_set():
            root.destroy()
            return
        rows["Loops"].config(text=str(loop_count))
        rows["Rejoins"].config(text=str(rejoin_count))
        rows["Time"].config(text=format_uptime(time.monotonic() - start_time))
        root.after(200, tick)

    tick()
    root.mainloop()
    return True


def load_gray(path):
    if not path.exists():
        here = ", ".join(sorted(f.name for f in ROOT.iterdir() if f.suffix.lower() == ".png")) or "none"
        raise SystemExit(f"\n[ERROR] {path.name} not found in {ROOT}\n"
                         f"        PNG files in that folder: {here}\n"
                         f"        (check for a hidden extension like 'Megumi.png.png' or 'Megumi (1).png')")
    img = cv2.imdecode(np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise SystemExit(f"\n[ERROR] {path.name} exists but isn't a readable image - re-save it as a real PNG.")
    return img


def load_template(path):
    """Load an image and resize it for the chosen resolution (TEMPLATE_SCALE)."""
    img = load_gray(path)
    if abs(TEMPLATE_SCALE - 1.0) > 0.01:
        h, w = img.shape[:2]
        size = (max(4, round(w * TEMPLATE_SCALE)), max(4, round(h * TEMPLATE_SCALE)))
        img = cv2.resize(img, size, interpolation=cv2.INTER_AREA if TEMPLATE_SCALE < 1 else cv2.INTER_CUBIC)
    return img


def grab_gray(sct, region):
    left, top, right, bottom = region
    shot = sct.grab({"left": left, "top": top, "width": right - left, "height": bottom - top})
    return cv2.cvtColor(np.array(shot), cv2.COLOR_BGRA2GRAY)


def pad_region(region, pad):
    left, top, right, bottom = region
    return max(0, left - pad), max(0, top - pad), right + pad, bottom + pad


last_scores = {"retry": 0.0, "megumi": 0.0, "mahoraga": 0.0, "timer": 0.0}


def find_retry(sct, template):
    screen = grab_gray(sct, RETRY_REGION)
    if template.shape[0] > screen.shape[0] or template.shape[1] > screen.shape[1]:
        return None
    result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
    _, score, _, loc = cv2.minMaxLoc(result)
    last_scores["retry"] = float(score)
    if score < RETRY_THRESHOLD:
        return None
    h, w = template.shape[:2]
    return RETRY_REGION[0] + loc[0] + w // 2, RETRY_REGION[1] + loc[1] + h // 2, float(score)


def find_timer(sct, template):
    """Score of the best match for the 22:00 image inside the timer box."""
    screen = grab_gray(sct, pad_region(TIMER_REGION, TIMER_PAD))
    if template.shape[0] > screen.shape[0] or template.shape[1] > screen.shape[1]:
        return 0.0
    result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
    score = float(cv2.minMaxLoc(result)[1])
    last_scores["timer"] = score
    return score


def find_banner(sct, name, template, region):
    """Multi-scale match for a 'Defeat ..' banner. Returns (x, y, score), or None if the
    template can't fit. The caller applies the threshold."""
    region = pad_region(region, BANNER_PAD)
    screen = grab_gray(sct, region)
    best = None
    for scale in (0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1.0, 1.05, 1.10, 1.15):
        w = max(8, int(template.shape[1] * scale))
        h = max(8, int(template.shape[0] * scale))
        if w > screen.shape[1] or h > screen.shape[0]:
            continue
        resized = cv2.resize(template, (w, h), interpolation=cv2.INTER_AREA)
        result = cv2.matchTemplate(screen, resized, cv2.TM_CCOEFF_NORMED)
        _, score, _, loc = cv2.minMaxLoc(result)
        if best is None or score > best[0]:
            best = (float(score), loc, w, h)
    if best is None:
        return None
    last_scores[name] = best[0]
    score, loc, w, h = best
    return region[0] + loc[0] + w // 2, region[1] + loc[1] + h // 2, score


# ---- hotbar slot equip ------------------------------------------------------
slot_templates = {}
slot_missing_since = None
slot_presence_lock = threading.Lock()
slot_state_lock = threading.Lock()
last_slot_states = {}
last_slot_scores = {}
equip_lock = threading.Lock()
last_equip_press = 0.0
equip_hold_until = 0.0  # no auto-equip before this time (Megumi's start delay)
retry_active = threading.Event()  # set while the Retry sequence runs; auto-equip pauses
timer_active = threading.Event()  # set while the time-limit reset runs; auto-equip pauses
last_timer_time = -1e9
heartbeat = {"scanner": 0.0, "equip": 0.0}  # last time each scan thread looped
last_macro_activity = time.monotonic()


def load_slot_templates():
    for key, name in SLOT_FILES.items():
        slot_templates[key] = load_template(ROOT / name)


def scan_slots(sct):
    """Return {"2": (state, score, None), ...} for each slot whose icon is found."""
    padded = {slot: pad_region(region, SLOT_PAD) for slot, region in SLOT_REGIONS.items()}
    box = (min(r[0] for r in padded.values()), min(r[1] for r in padded.values()),
           max(r[2] for r in padded.values()), max(r[3] for r in padded.values()))
    whole = grab_gray(sct, box)  # one small capture covering both slots

    found = {}
    for slot, (left, top, right, bottom) in padded.items():
        screen = whole[top - box[1]:bottom - box[1], left - box[0]:right - box[0]]
        scores = {}
        for state in ("eq", "un"):
            tpl = slot_templates[(slot, state)]
            if tpl.shape[0] > screen.shape[0] or tpl.shape[1] > screen.shape[1]:
                scores[state] = 0.0
                continue
            result = cv2.matchTemplate(screen, tpl, cv2.TM_CCOEFF_NORMED)
            scores[state] = float(cv2.minMaxLoc(result)[1])
        if scores["eq"] >= EQUIP_THRESHOLD and scores["eq"] > scores["un"]:
            state_name = "equipped"
        elif scores["un"] >= EQUIP_THRESHOLD:
            state_name = "unequipped"
        else:
            state_name = "unrecognized"
        with slot_state_lock:
            previous_state = last_slot_states.get(slot)
            last_slot_states[slot] = state_name
            last_slot_scores[slot] = scores.copy()
        if previous_state != state_name:
            log("EQUIP", f"Slot {slot} state: {previous_state or 'unknown'} -> {state_name} "
                f"(equipped={scores['eq']:.2f}, unequipped={scores['un']:.2f})", console=False)
        if scores["eq"] >= EQUIP_THRESHOLD and scores["eq"] > scores["un"]:
            found[slot] = ("equipped", scores["eq"], None)
        elif scores["un"] >= EQUIP_THRESHOLD:
            found[slot] = ("unequipped", scores["un"], None)
    return found


def press_slot(slot):
    """Press a slot key unless one was pressed very recently. The main loop and the
    Megumi routine both use this, so together they can't press twice and toggle it off."""
    global last_equip_press
    with equip_lock:
        if time.perf_counter() - last_equip_press < EQUIP_COOLDOWN:
            return False
        tap(slot)
        last_equip_press = time.perf_counter()
        return True


def equip_tick(sct):
    """Called every loop: press the key of a slot that shows unequipped."""
    global last_macro_activity
    if time.perf_counter() < equip_hold_until:
        return
    found = scan_slots(sct)
    note_slot_presence(found)
    if not found or any(v[0] == "equipped" for v in found.values()):
        return
    slot = min(found)  # slot 2 before slot 3
    if press_slot(slot):
        last_macro_activity = time.monotonic()
        log("EQUIP", f"Slot {slot} was unequipped, pressed {slot}")


def note_slot_presence(found):
    global slot_missing_since
    if not REJOIN_ENABLED:
        return
    with slot_presence_lock:
        if found:
            slot_missing_since = None
        elif slot_missing_since is None:
            slot_missing_since = time.monotonic()
        elif time.monotonic() - slot_missing_since >= SLOT_MISSING_TIMEOUT:
            if not REJOIN_ACTIVE.is_set():
                log("WARN", f"No hotbar slot state recognized for {SLOT_MISSING_TIMEOUT / 60:g} minutes")
                REJOIN_REQUESTED.set()
            slot_missing_since = time.monotonic()


def equip_watcher():
    """Own thread: checks the slots every POLL_DELAY, independent of the slower banner
    scans, so a slot that gets unequipped is re-equipped right away."""
    while not shutdown.is_set():
        with mss.MSS() as sct:  # fresh capture handle every CAPTURE_REFRESH_INTERVAL
            session_start = time.monotonic()
            while not shutdown.is_set() and time.monotonic() - session_start < CAPTURE_REFRESH_INTERVAL:
                loop_start = time.perf_counter()
                heartbeat["equip"] = time.monotonic()
                if (not retry_active.is_set() and not timer_active.is_set()
                    and not REJOIN_ACTIVE.is_set()
                    and (not REJOIN_ENABLED or game_available.is_set())):
                    if ENABLE_AUTO_EQUIP:
                        equip_tick(sct)
                    elif REJOIN_ENABLED:
                        note_slot_presence(scan_slots(sct))
                time.sleep(max(0.0, POLL_DELAY - (time.perf_counter() - loop_start)))


def equip_slot(stop):
    """Megumi step: make sure slot 2/3 is equipped before moving on (a few tries)."""
    with mss.MSS() as sct:
        for attempt in range(EQUIP_TRIES + 1):
            if stop.is_set():
                return
            found = scan_slots(sct)
            if not found:
                log("WARN", "Neither slot 2 nor 3 found in the hotbar boxes, skipping equip")
                return
            summary = ", ".join(f"slot {s} {v[0]}" for s, v in sorted(found.items()))
            if any(v[0] == "equipped" for v in found.values()):
                log("EQUIP", f"{'Equipped' if attempt else 'Already equipped'} ({summary})")
                return
            if attempt == EQUIP_TRIES:
                log("WARN", f"Still unequipped after {EQUIP_TRIES} tries ({summary})")
                return
            slot = min(found)
            if press_slot(slot):
                log("EQUIP", f"{summary}, pressed {slot}")
            if stop.wait(EQUIP_RECHECK_DELAY):
                return


# ---- window focus -----------------------------------------------------------
_warned_no_window = False


def focus_game():
    """Bring the game window to the front so key presses reach it (Windows only)."""
    global _warned_no_window
    if not GAME_WINDOW_TITLE:
        return
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def visit(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if buf.value.strip().lower() == GAME_WINDOW_TITLE.lower():
                found.append(hwnd)
        return True

    user32.EnumWindows(visit, 0)
    if not found:
        if not _warned_no_window:
            log("WARN", f"No window titled '{GAME_WINDOW_TITLE}' found, click the game yourself")
            _warned_no_window = True
        return
    hwnd = found[0]
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.keybd_event(0x12, 0, 0, 0)  # tap Alt so Windows allows the focus change
    user32.keybd_event(0x12, 0, 2, 0)
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.15)


def game_window_exists():
    if not GAME_WINDOW_TITLE:
        return False
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def visit(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            length = user32.GetWindowTextLengthW(hwnd)
            title = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, title, length + 1)
            if title.value.strip().lower() == GAME_WINDOW_TITLE.lower():
                found.append(hwnd)
                return False
        return True

    user32.EnumWindows(visit, 0)
    return bool(found)


def load_rejoin_templates():
    return {step: load_template(ROOT / filename)
            for step, filename in REJOIN_TEMPLATE_FILES.items()}


rejoin_templates = {}
last_rejoin_scores = {step: None for step in REJOIN_TEMPLATE_FILES}


def find_rejoin_match(sct, step):
    left, top, right, bottom = REJOIN_AREAS[step]
    monitor = sct.monitors[0]
    region = (
        max(monitor["left"], left - REJOIN_MATCH_PAD),
        max(monitor["top"], top - REJOIN_MATCH_PAD),
        min(monitor["left"] + monitor["width"], right + REJOIN_MATCH_PAD),
        min(monitor["top"] + monitor["height"], bottom + REJOIN_MATCH_PAD),
    )
    screen = grab_gray(sct, region)
    template = rejoin_templates[step]
    if template.shape[0] > screen.shape[0] or template.shape[1] > screen.shape[1]:
        last_rejoin_scores[step] = -1.0
        return None
    result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
    _, score, _, location = cv2.minMaxLoc(result)
    last_rejoin_scores[step] = float(score)
    threshold = REJOIN_STEP_THRESHOLDS.get(step, REJOIN_THRESHOLD)
    if score < threshold:
        return None
    return (region[0] + location[0], region[1] + location[1],
            template.shape[1], template.shape[0], float(score))


def snap_roblox_window_left(sct, timeout=30.0):
    if not SNAP_ROBLOX_AFTER_REJOIN:
        log("REJOIN", "Roblox auto-snap disabled in settings")
        return True

    deadline = time.monotonic() + timeout
    while not shutdown.is_set() and time.monotonic() < deadline:
        loop_started = time.monotonic()
        match = find_rejoin_match(sct, 17) or find_rejoin_match(sct, 18)
        if match and game_window_exists():
            titlebar_x = match[0] + match[2] // 2
            titlebar_y = match[1] + match[3] // 2
            log("REJOIN", f"Roblox titlebar detected at ({titlebar_x},{titlebar_y}); "
                f"gliding to snap point {ROBLOX_SNAP_TARGET}")
            glide_to(titlebar_x, titlebar_y, GLIDE_DURATION)
            pydirectinput.mouseDown(button="left")
            try:
                glide_to(ROBLOX_SNAP_TARGET[0], ROBLOX_SNAP_TARGET[1], GLIDE_DURATION)
            finally:
                pydirectinput.mouseUp(button="left")
                pydirectinput.moveTo(*ROBLOX_SNAP_TARGET)
            if not wait_rejoin_delay(sct, 0.5):
                return False
            log("REJOIN", "Released Roblox window at configured half-screen snap point")
            return True
        wait_for_scan_tick(loop_started, deadline)

    log("WARN", f"Roblox titlebar not matched within {timeout:g}s; leaving window position unchanged")
    return not shutdown.is_set()


def wait_for_scan_tick(started_at, deadline=None):
    remaining = max(0.0, POLL_DELAY - (time.monotonic() - started_at))
    if deadline is not None:
        remaining = min(remaining, max(0.0, deadline - time.monotonic()))
    if remaining:
        shutdown.wait(remaining)


def wait_for_rejoin_image(sct, step, timeout=180.0):
    deadline = time.monotonic() + timeout
    while not shutdown.is_set() and time.monotonic() < deadline:
        loop_started = time.monotonic()
        match = find_rejoin_match(sct, step)
        if match:
            log("REJOIN", f"Detected image {step} ({REJOIN_STEP_NAMES[step]}, score={match[4]:.2f})")
            return match
        wait_for_scan_tick(loop_started, deadline)
    if shutdown.is_set():
        return None
    score = last_rejoin_scores[step]
    log("WARN", f"Timed out after {timeout:g}s waiting for image {step} ({REJOIN_STEP_NAMES[step]}, last score={score})")
    return None


def find_portal_with_right_taps(sct, timeout=180.0):
    deadline = time.monotonic() + timeout
    next_tap = 0.0
    log("REJOIN", "Searching for Portal.png; tapping Right until detected")
    while not shutdown.is_set() and time.monotonic() < deadline:
        loop_started = time.monotonic()
        portal_match = find_rejoin_match(sct, 16)
        if portal_match:
            log("REJOIN", f"Portal detected at ({portal_match[0]}, {portal_match[1]}) "
                f"score={portal_match[4]:.2f}")
            return portal_match
        now = time.monotonic()
        if now >= next_tap:
            pydirectinput.press("right")
            log("REJOIN", "Tapped Right while searching for Portal.png")
            next_tap = now + PORTAL_ARROW_INTERVAL
        wait_for_scan_tick(loop_started, deadline)
    log("WARN", f"Portal.png not found within {timeout:g}s; last score={last_rejoin_scores[16]}")
    return None


def portal_steering_keys(match):
    left, top, width, height, _ = match
    portal_x = left + width // 2
    portal_y = top + height // 2
    delta_x = portal_x - PORTAL_PLAYER_ANCHOR[0]
    delta_y = portal_y - PORTAL_PLAYER_ANCHOR[1]
    keys = []
    if abs(delta_y) > PORTAL_STEER_DEADZONE:
        keys.append("w" if delta_y < 0 else "s")
    if abs(delta_x) > PORTAL_STEER_DEADZONE:
        keys.append("a" if delta_x < 0 else "d")
    if not keys:
        keys.append("w")
    return tuple(keys), portal_x, portal_y, delta_x, delta_y


def move_through_portal_until_raid(sct, timeout=PORTAL_ATTEMPT_TIMEOUT):
    deadline = time.monotonic() + timeout
    active_keys = ()
    next_steer = 0.0
    raid_streak = 0
    log("REJOIN", "Steering toward Portal.png based on its position relative to the player anchor")
    try:
        while not shutdown.is_set() and time.monotonic() < deadline:
            loop_started = time.monotonic()
            if find_rejoin_match(sct, 12):
                raid_streak += 1
                if raid_streak >= 2:
                    log("REJOIN", "Raid-selection image detected during portal movement")
                    return True
            else:
                raid_streak = 0

            now = time.monotonic()
            if now >= next_steer:
                portal_match = find_rejoin_match(sct, 16)
                if portal_match:
                    desired_keys, portal_x, portal_y, delta_x, delta_y = portal_steering_keys(portal_match)
                    target_text = (f"portal=({portal_x},{portal_y}) offset=({delta_x},{delta_y}) "
                                   f"keys={'+'.join(key.upper() for key in desired_keys)}")
                else:
                    desired_keys = ("w",)
                    target_text = "portal not currently matched; continuing forward with W"
                if desired_keys != active_keys:
                    release_keys(active_keys)
                    for key in desired_keys:
                        pydirectinput.keyDown(key)
                    active_keys = desired_keys
                    log("REJOIN", f"Portal steering: {target_text}")
                next_steer = now + PORTAL_MOVE_HOLD
            wait_for_scan_tick(loop_started, deadline)
        log("WARN", f"Raid-selection image not found after {timeout:g}s of portal steering")
        return False
    finally:
        release_keys(("w", "a", "s", "d"))


def find_portal_and_enter_until_raid(sct):
    if find_rejoin_match(sct, 12):
        log("REJOIN", "Raid-selection image already visible; skipping portal navigation")
        return True
    attempt = 0
    while not shutdown.is_set():
        attempt += 1
        portal = find_portal_with_right_taps(sct, timeout=PORTAL_ATTEMPT_TIMEOUT)
        if shutdown.is_set():
            return False
        if not portal:
            log("WARN", f"No portal found in {PORTAL_ATTEMPT_TIMEOUT:g}s; continuing Right search")
            continue
        log("REJOIN", f"Portal approach attempt {attempt}")
        if move_through_portal_until_raid(sct, timeout=PORTAL_ATTEMPT_TIMEOUT):
            return True
        if shutdown.is_set():
            return False
        log("WARN", f"Portal not entered within {PORTAL_ATTEMPT_TIMEOUT:g}s; turning to find another")
        next_tap = 0.0
        while not shutdown.is_set():
            loop_started = time.monotonic()
            if not find_rejoin_match(sct, 16):
                log("REJOIN", "Previous portal left the view; searching for another")
                break
            now = time.monotonic()
            if now >= next_tap:
                pydirectinput.press("right")
                log("REJOIN", "Tapped Right to leave the previous portal view")
                next_tap = now + PORTAL_ARROW_INTERVAL
            wait_for_scan_tick(loop_started)
    return False


def wait_rejoin_delay(sct, duration, watched_steps=()):
    deadline = time.monotonic() + duration
    reported = set()
    while not shutdown.is_set() and time.monotonic() < deadline:
        loop_started = time.monotonic()
        for step in watched_steps:
            match = find_rejoin_match(sct, step)
            if match and step not in reported:
                reported.add(step)
                log("REJOIN", f"Image {step} appeared during the {duration:g}s wait")
        wait_for_scan_tick(loop_started, deadline)
    return not shutdown.is_set()


def click_rejoin_match(sct, step, offset=(0.5, 0.5), match=None):
    if match is None:
        match = find_rejoin_match(sct, step)
    if not match:
        return False
    left, top, width, height, score = match
    x = int(left + width * offset[0])
    y = int(top + height * offset[1])
    glide_to(x, y, GLIDE_DURATION)
    pydirectinput.click()
    log("REJOIN", f"Clicked image {step} ({REJOIN_STEP_NAMES[step]}, {score:.2f})")
    return True


def click_until_next(sct, step, next_step, timeout=180.0, offset=(0.5, 0.5)):
    deadline = time.monotonic() + timeout
    last_click = 0.0
    next_streak = 0
    while not shutdown.is_set() and time.monotonic() < deadline:
        loop_started = time.monotonic()
        current_match = find_rejoin_match(sct, step)
        next_match = find_rejoin_match(sct, next_step)
        if next_match:
            next_streak += 1
            if next_streak >= 2:
                log("REJOIN", f"Transition image {next_step} detected after clicking image {step}")
                return True
        else:
            next_streak = 0
        now = time.monotonic()
        if now - last_click >= 1.0 and current_match and click_rejoin_match(
                sct, step, offset, current_match):
            last_click = now
        wait_for_scan_tick(loop_started, deadline)
    log("WARN", f"Timed out waiting for image {next_step} ({REJOIN_STEP_NAMES[next_step]}) "
        f"after image {step}; last scores current={last_rejoin_scores[step]}, "
        f"next={last_rejoin_scores[next_step]}")
    return False


def click_server_and_enter_game(sct):
    if not wait_for_rejoin_image(sct, 1, timeout=12.0):
        return False
    if not wait_for_rejoin_image(sct, 2, timeout=30.0):
        return False
    if not click_until_next(sct, 2, 3):
        return False
    if not click_until_next(sct, 3, 4):
        return False
    return click_rejoin_match(sct, 4)


def scroll_to_raid_card(sct, timeout=180.0):
    if not wait_for_rejoin_image(sct, 12, timeout=180.0):
        return False
    left, top, right, bottom = REJOIN_AREAS[12]
    glide_to((left + right) // 2, (top + bottom) // 2, GLIDE_DURATION)
    next_scroll = time.monotonic()
    scroll_count = 0
    log("REJOIN", "Scanning for raid card; scrolling every 0.5s")
    deadline = time.monotonic() + timeout
    while not shutdown.is_set() and time.monotonic() < deadline:
        loop_started = time.monotonic()
        if find_rejoin_match(sct, 13):
            log("REJOIN", f"Raid card image detected after {scroll_count} scrolls")
            return True
        now = time.monotonic()
        if now >= next_scroll:
            pyautogui.scroll(-1)
            scroll_count += 1
            log("REJOIN", f"Raid-list scroll {scroll_count}")
            next_scroll = now + REJOIN_SCROLL_INTERVAL
        wait_for_scan_tick(loop_started)
    if not shutdown.is_set():
        log("WARN", f"Raid card not found after {timeout:g}s of scrolling")
    return False


def start_raid(sct, timeout=60.0):
    """After the lobby is created: scan every POLL_DELAY for the Start Raid button and click it."""
    log("REJOIN", "Lobby created; scanning for the Start Raid button")
    match = wait_for_rejoin_image(sct, 19, timeout=timeout)
    if not match:
        log("WARN", "Start Raid button not found; check the scan area (image 19) in settings")
        return False
    for attempt in range(1, 4):
        if not click_rejoin_match(sct, 19, match=match):
            break
        if not wait_rejoin_delay(sct, 1.0):
            return False
        match = find_rejoin_match(sct, 19)
        if not match:
            log("REJOIN", "Start Raid clicked; button is gone")
            return True
        log("REJOIN", f"Start Raid button still visible after click {attempt}")
    return True


def create_raid_lobby(sct):
    if not click_until_next(sct, 13, 14, offset=(0.88, 0.84)):
        return False
    if not click_until_next(sct, 14, 15):
        return False
    if not wait_for_rejoin_image(sct, 15):
        return False
    for click_number in range(5):
        if not click_rejoin_match(sct, 15):
            if click_number == 0:
                return False
            log("REJOIN", f"Create Lobby button gone after {click_number} click(s); lobby created")
            break
        if click_number < 4:
            if not wait_rejoin_delay(sct, 0.2, (15,)):
                return False
    start_raid(sct)  # a missing Start button only warns, so the lobby isn't re-created
    log("REJOIN", "Returning to raid watcher")
    return True


def close_roblox_with_alt_f4(timeout=12.0):
    if not game_window_exists():
        log("REJOIN", "Roblox is already closed; skipping Alt+F4")
        return True
    focus_game()
    if shutdown.is_set():
        return False
    log("REJOIN", "Holding Alt and pressing F4 to close Roblox for fallback")
    pydirectinput.keyDown("alt")
    try:
        tap("f4")
    finally:
        pydirectinput.keyUp("alt")
        release_keys(("alt", "f4"))

    deadline = time.monotonic() + timeout
    while not shutdown.is_set() and time.monotonic() < deadline:
        if not game_window_exists():
            log("REJOIN", "Roblox closed; continuing fallback")
            return True
        shutdown.wait(POLL_DELAY)
    log("WARN", f"Roblox window did not close after Alt+F4 within {timeout:g}s")
    return False


def run_primary_rejoin(sct):
    if not click_until_next(sct, 5, 6, timeout=8.0):
        return False
    if not click_until_next(sct, 6, 7):
        return False
    if not click_until_next(sct, 7, 1):
        return False
    if not click_server_and_enter_game(sct):
        return False
    log("REJOIN", f"Waiting {REJOIN_MENU_WAIT:g}s after selecting Raids")
    if not wait_rejoin_delay(sct, REJOIN_MENU_WAIT, (12,)):
        return False
    if not find_portal_and_enter_until_raid(sct):
        return False
    return scroll_to_raid_card(sct) and create_raid_lobby(sct)


def wait_for_fallback_landing(sct, timeout=180.0):
    deadline = time.monotonic() + timeout
    landing_steps = (12, 3, 9)
    while not shutdown.is_set() and time.monotonic() < deadline:
        loop_started = time.monotonic()
        for step in landing_steps:
            if find_rejoin_match(sct, step):
                log("REJOIN", f"Fallback launch landed on image {step} ({REJOIN_STEP_NAMES[step]})")
                return step
        wait_for_scan_tick(loop_started, deadline)
    log("WARN", "No game or Roblox launch screen detected after opening the Roblox icon")
    return None


def continue_from_game_modes(sct):
    if not click_until_next(sct, 3, 4):
        return False
    if not click_rejoin_match(sct, 4):
        return False
    log("REJOIN", f"Waiting {REJOIN_MENU_WAIT:g}s after selecting Raids")
    if not wait_rejoin_delay(sct, REJOIN_MENU_WAIT, (12,)):
        return False
    if not find_portal_and_enter_until_raid(sct):
        return False
    return scroll_to_raid_card(sct) and create_raid_lobby(sct)


def run_fallback_rejoin(sct):
    if find_rejoin_match(sct, 12):
        log("REJOIN", "Kaizen already opened at raid selection; skipping launcher search")
        if not snap_roblox_window_left(sct):
            return False
        return scroll_to_raid_card(sct) and create_raid_lobby(sct)
    if find_rejoin_match(sct, 3):
        log("REJOIN", "Kaizen already opened at GameModes; opening Raids")
        if not snap_roblox_window_left(sct):
            return False
        return continue_from_game_modes(sct)

    if not close_roblox_with_alt_f4():
        return False
    if not wait_for_rejoin_image(sct, 8, timeout=30.0):
        return False
    if not click_rejoin_match(sct, 8):
        return False
    landing = wait_for_fallback_landing(sct)
    if landing == 12:
        if not snap_roblox_window_left(sct):
            return False
        return scroll_to_raid_card(sct) and create_raid_lobby(sct)
    if landing == 3:
        log("REJOIN", "Roblox reopened directly into Kaizen; skipping web search")
        if not snap_roblox_window_left(sct):
            return False
        return continue_from_game_modes(sct)
    if landing != 9:
        return False
    if not click_until_next(sct, 9, 10):
        return False
    if not snap_roblox_window_left(sct):
        return False
    if not wait_for_rejoin_image(sct, 10):
        return False
    click_rejoin_match(sct, 10)
    pydirectinput.keyDown("ctrl")
    pydirectinput.press("a")
    pydirectinput.keyUp("ctrl")
    pydirectinput.write("KAIZEN", interval=0.05)
    pydirectinput.press("enter")
    log("REJOIN", "Typed KAIZEN and pressed Enter; waiting 1.5s")
    if not wait_rejoin_delay(sct, 1.5, (11,)):
        return False
    if not wait_for_rejoin_image(sct, 11):
        return False
    if not click_rejoin_match(sct, 11):
        return False

    log("REJOIN", f"Waiting {REJOIN_SEARCH_SCROLL_WAIT:g}s before search-page scrolling")
    if not wait_rejoin_delay(sct, REJOIN_SEARCH_SCROLL_WAIT, (12,)):
        return False
    left, top, right, bottom = REJOIN_AREAS[11]
    glide_to((left + right) // 2, (top + bottom) // 2, GLIDE_DURATION)
    scroll_delay = REJOIN_SEARCH_SCROLL_DURATION / REJOIN_SEARCH_SCROLL_COUNT
    scroll_started = time.monotonic()
    next_scroll = scroll_started + scroll_delay
    scroll_count = 0
    raid_selection_seen = False
    while not shutdown.is_set() and scroll_count < REJOIN_SEARCH_SCROLL_COUNT:
        loop_started = time.monotonic()
        if not raid_selection_seen and find_rejoin_match(sct, 12):
            raid_selection_seen = True
            log("REJOIN", "Raid-selection image detected during search scrolling")
        now = time.monotonic()
        if now >= next_scroll:
            pyautogui.scroll(-1)
            scroll_count += 1
            log("REJOIN", f"Search-page scroll {scroll_count}/{REJOIN_SEARCH_SCROLL_COUNT}")
            next_scroll = scroll_started + scroll_delay * (scroll_count + 1)
        wait_for_scan_tick(loop_started)
    if shutdown.is_set():
        return False
    if not wait_for_rejoin_image(sct, 12, timeout=10.0):
        return click_until_next(sct, 11, 12)
    return scroll_to_raid_card(sct) and create_raid_lobby(sct)


def run_rejoin_flow():
    with mss.MSS() as sct:
        ready = time.monotonic() + 180.0
        landing = None
        while not shutdown.is_set() and time.monotonic() < ready:
            loop_started = time.monotonic()
            for step in (12, 3, 8, 9):
                if find_rejoin_match(sct, step):
                    landing = step
                    break
            if landing is not None:
                break
            wait_for_scan_tick(loop_started, ready)
        else:
            log("WARN", "No rejoin starting screen appeared")
            return False
        if landing == 12:
            log("REJOIN", "Kaizen already opened at raid selection")
            if not snap_roblox_window_left(sct):
                return False
            return scroll_to_raid_card(sct) and create_raid_lobby(sct)
        if landing == 3:
            log("REJOIN", "Kaizen already opened at GameModes")
            if not snap_roblox_window_left(sct):
                return False
            return continue_from_game_modes(sct)
        log("REJOIN", "Starting fallback Roblox search route")
        return run_fallback_rejoin(sct)


def rejoin_watcher():
    """Request rejoin after Roblox disappears; slot watcher handles missing HUD templates."""
    seen_game = game_window_exists()
    missing_since = None
    while not shutdown.wait(2.0):
        if not REJOIN_ENABLED:
            continue
        if game_window_exists():
            seen_game = True
            missing_since = None
            game_available.set()
            continue
        game_available.clear()
        if not seen_game:
            continue
        if missing_since is None:
            missing_since = time.monotonic()
            release_keys(ALL_KEYS)
            retry_active.clear()
            timer_active.clear()
            stop_routine()
            log("WARN", "Roblox window disappeared; waiting before rejoin")
        elif time.monotonic() - missing_since >= 12.0 and not REJOIN_ACTIVE.is_set():
            REJOIN_REQUESTED.set()
            missing_since = time.monotonic()


def rejoin_runner():
    global rejoin_count, megumi_armed, equip_hold_until
    while not shutdown.is_set():
        if not REJOIN_REQUESTED.wait(0.5):
            continue
        REJOIN_REQUESTED.clear()
        if shutdown.is_set() or not REJOIN_ENABLED:
            continue
        rejoin_count += 1
        log("REJOIN", f"Automatic rejoin sequence #{rejoin_count} started")
        REJOIN_ACTIVE.set()
        try:
            while not shutdown.is_set() and REJOIN_ENABLED:
                release_keys(ALL_KEYS)
                retry_active.clear()
                timer_active.clear()
                stop_routine()
                try:
                    if run_rejoin_flow():
                        log("REJOIN", "Raid lobby ready")
                        megumi_armed = True  # new raid: the Megumi combo may run again
                        equip_hold_until = 0.0
                        break
                    log("WARN", "Rejoin steps did not finish; retrying in 10s")
                except Exception as exc:
                    log_crash("rejoin flow", exc)
                if shutdown.wait(10.0):
                    break
        finally:
            release_keys(ALL_KEYS)
            REJOIN_ACTIVE.clear()


# ---- key routines -----------------------------------------------------------
def tap(key):
    """Press and release a key (or "mmb": a middle mouse click at the cursor's position)."""
    if key == "mmb":
        pydirectinput.mouseDown(button="middle")
        try:
            time.sleep(KEY_HOLD)
        finally:
            pydirectinput.mouseUp(button="middle")
        return
    pydirectinput.keyDown(key)
    try:
        time.sleep(KEY_HOLD)
    finally:
        pydirectinput.keyUp(key)


ALL_KEYS = ("w", "a", "s", "d", "right", "alt", "f4", "ctrl", "q", "z", "x", "c", "v", "r", "2", "3", "esc", "enter", "mmb")


def release_keys(keys=("w",)):
    """Make sure keys are up (a crash mid-press must not leave W held down)."""
    for key in keys:
        try:
            if key == "mmb":
                pydirectinput.mouseUp(button="middle")
            else:
                pydirectinput.keyUp(key)
        except Exception:
            pass


def spam_keys(stop, keys):
    if not keys:  # no skills ticked: just wait until told to stop
        while not stop.is_set() and not shutdown.is_set():
            stop.wait(0.5)
        return
    while not stop.is_set() and not shutdown.is_set():
        for key in keys:
            if stop.is_set() or shutdown.is_set():
                return
            tap(key)
            time.sleep(KEY_DELAY)


def megumi_routine(stop):
    if MEGUMI_START_DELAY and stop.wait(MEGUMI_START_DELAY):
        return
    log("MEGUMI", "Combo started (equip check, W 1s, Q x2)")
    focus_game()
    if stop.wait(AFTER_FOCUS_DELAY):
        return
    if ENABLE_AUTO_EQUIP:
        equip_slot(stop)
    if stop.is_set():
        return
    if stop.wait(0.1):
        return
    pydirectinput.keyDown("w")
    try:
        stop.wait(1.0)
    finally:
        pydirectinput.keyUp("w")
    if stop.is_set():
        return
    tap("q")
    if stop.wait(0.1):
        return
    tap("q")
    if MEGUMI_SPAM_DELAY and stop.wait(MEGUMI_SPAM_DELAY):
        return
    log("MEGUMI", "Combo done, spamming X C V")
    spam_keys(stop, MEGUMI_KEYS)


def mahoraga_routine(stop):
    focus_game()
    if stop.wait(AFTER_FOCUS_DELAY):
        return
    spam_keys(stop, MAHORAGA_KEYS)


def stop_routine():
    """Stop the running key routine (if any) and wait for it to finish."""
    global current_stop, current_thread, current_name
    with state_lock:
        stop, thread = current_stop, current_thread
        current_stop, current_thread, current_name = None, None, None
    if stop is not None:
        stop.set()
    if thread is not None:
        thread.join(timeout=1.5)
    release_keys()  # never leave W held


def _run_routine(name, target, stop):
    """Run a key routine; if it crashes, log it and free the slot so it can start again."""
    global current_stop, current_thread, current_name
    try:
        target(stop)
    except Exception as exc:
        log_crash(name, exc)
        release_keys(ALL_KEYS)
        with state_lock:
            if current_stop is stop:
                current_stop, current_thread, current_name = None, None, None


def start_routine(name, target):
    """Replace whatever is running with a new routine."""
    global current_stop, current_thread, current_name
    if current_name is not None:
        log("SWITCH", f"{current_name} -> {name}")
    stop_routine()
    stop = threading.Event()
    thread = threading.Thread(target=_run_routine, args=(name, target, stop), daemon=True)
    with state_lock:
        current_stop, current_thread, current_name = stop, thread, name
    thread.start()


# ---- retry click ------------------------------------------------------------
class _Point(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def glide_to(x, y, duration):
    """Smooth mouse glide. pyautogui.moveTo only takes ~16 steps for a 0.8s move,
    which looks choppy, so this moves by elapsed time instead of by step count."""
    user32 = ctypes.windll.user32
    start = _Point()
    user32.GetCursorPos(ctypes.byref(start))
    sx, sy = start.x, start.y
    t0 = time.perf_counter()
    while True:
        t = (time.perf_counter() - t0) / duration
        if t >= 1.0:
            break
        e = t * t * t * (t * (t * 6 - 15) + 10)  # smootherstep: gentle start and stop
        user32.SetCursorPos(int(sx + (x - sx) * e), int(sy + (y - sy) * e))
        time.sleep(0.002)
    user32.SetCursorPos(int(x), int(y))


def click_retry(x, y, score):
    global megumi_armed, equip_hold_until, loop_count, last_macro_activity
    detected_at = time.perf_counter()
    retry_active.set()  # pause auto-equip while the Retry sequence runs
    last_macro_activity = time.monotonic()
    try:
        with loop_lock:
            loop_count += 1
            loop_no = loop_count
        log("RETRY", f"Found ({score:.2f}), loop #{loop_no}, clicking in {RETRY_MOVE_DELAY:g}s")
        stop_routine()
        if HOME_POS:  # first, park the cursor at the home spot
            glide_to(HOME_POS[0], HOME_POS[1], HOME_GLIDE_DURATION)
            pydirectinput.moveTo(*HOME_POS)
        # the 3.5s is counted from the moment Retry was detected
        time.sleep(max(0.0, RETRY_MOVE_DELAY - (time.perf_counter() - detected_at)))
        glide_to(x, y, GLIDE_DURATION)
        time.sleep(0.15)
        pydirectinput.moveTo(x, y)  # real mouse-move event so the game registers the hover
        time.sleep(0.1)
        for i in range(CLICK_COUNT):
            pydirectinput.mouseDown(button="left")
            time.sleep(CLICK_HOLD)  # hold briefly; instant press/release can get ignored
            pydirectinput.mouseUp(button="left")
            time.sleep(0.08)
        time.sleep(0.5)
        if HOME_POS:
            glide_to(HOME_POS[0], HOME_POS[1], HOME_GLIDE_DURATION)
            pydirectinput.moveTo(*HOME_POS)  # real move event so the game sees the cursor arrive
        log("RETRY", f"Clicked x{CLICK_COUNT}, cursor back home")
    finally:
        megumi_armed = True  # Megumi may trigger again after this Retry
        equip_hold_until = 0.0
        retry_active.clear()


def run_timer_reset(score):
    """Time limit reached: stop everything, press Esc/R/Enter, wait 4s, and repeat."""
    global megumi_armed, equip_hold_until, last_timer_time, last_macro_activity
    timer_active.set()  # pause auto-equip so it can't press keys in the middle of this
    last_macro_activity = time.monotonic()
    try:
        log("TIMER", f"22:00 found ({score:.2f}), stopping everything")
        stop_routine()
        focus_game()
        time.sleep(AFTER_FOCUS_DELAY)

        for reset_attempt in range(2):
            for i, key in enumerate(TIMER_KEYS):
                if i:
                    time.sleep(TIMER_KEY_DELAY)
                tap(key)
            if reset_attempt == 0:
                log("TIMER", "First reset sent; waiting 4s before second reset")
                time.sleep(4.0)

        log("TIMER", "Sent " + ", ".join(k.capitalize() for k in TIMER_KEYS) + " twice, 4s apart, resuming")
    finally:
        last_timer_time = time.perf_counter()
        megumi_armed = True  # fresh start: the Megumi combo may run again
        equip_hold_until = 0.0
        timer_active.clear()


# ---- main watcher -----------------------------------------------------------
def watcher():
    global megumi_armed, equip_hold_until
    banners_on = ENABLE_MEGUMI or ENABLE_MAHORAGA
    retry_t = load_template(RETRY_PATH)
    megumi_t = load_template(MEGUMI_PATH) if banners_on else None
    mahoraga_t = load_template(MAHORAGA_PATH) if banners_on else None
    timer_t = load_template(TIMER_PATH) if ENABLE_TIMER else None

    last_debug = 0.0
    saved_debug = False
    streak_label, streak = None, 0
    timer_streak = 0
    while not shutdown.is_set():
        with mss.MSS() as sct:  # fresh capture handle every CAPTURE_REFRESH_INTERVAL
            session_start = time.monotonic()
            if DEBUG and not saved_debug:
                saved_debug = True
                for name, region in (("retry", RETRY_REGION),
                                     ("banner", pad_region(MEGUMI_REGION, BANNER_PAD)),
                                     ("timer", pad_region(TIMER_REGION, TIMER_PAD))):
                    cv2.imwrite(str(ROOT / f"debug_{name}_region.png"), grab_gray(sct, region))
                log("DEBUG", "Saved debug_retry_region.png, debug_banner_region.png, debug_timer_region.png")

            while not shutdown.is_set() and time.monotonic() - session_start < CAPTURE_REFRESH_INTERVAL:
                if REJOIN_ACTIVE.is_set() or (REJOIN_ENABLED and not game_available.is_set()):
                    time.sleep(POLL_DELAY)
                    continue
                loop_start = time.perf_counter()
                heartbeat["scanner"] = time.monotonic()

                if DEBUG and loop_start - last_debug >= DEBUG_INTERVAL:
                    last_debug = loop_start
                    log("DEBUG", "scores retry={retry:.2f} megumi={megumi:.2f} "
                                 "mahoraga={mahoraga:.2f} timer={timer:.2f}".format(**last_scores))

                # 1) Retry always has top priority
                match = find_retry(sct, retry_t)
                if match:
                    last_macro_activity = time.monotonic()
                    click_retry(*match)
                    continue

                # 2) Time limit: 22:00 on screen -> everything stops, Esc / R / Enter
                timer_score = find_timer(sct, timer_t) if timer_t is not None else 0.0
                if (timer_score >= TIMER_THRESHOLD
                        and time.perf_counter() - last_timer_time >= TIMER_COOLDOWN):
                    timer_streak += 1
                    if timer_streak >= TIMER_CONFIRM_FRAMES:
                        timer_streak = 0
                        last_macro_activity = time.monotonic()
                        run_timer_reset(timer_score)
                        continue
                else:
                    timer_streak = 0

                # 3) Banners. "Defeat Ma" and "Defeat Me" differ by one letter, so each
                #    template also scores high on the other banner. Score both on the same
                #    frame and only act on the better match.
                mah = find_banner(sct, "mahoraga", mahoraga_t, MAHORAGA_REGION) if banners_on else None
                meg = find_banner(sct, "megumi", megumi_t, MEGUMI_REGION) if banners_on else None
                mah_score = mah[2] if mah else 0.0
                meg_score = meg[2] if meg else 0.0

                if mah_score >= MAHORAGA_THRESHOLD and mah_score > meg_score:
                    label = "mahoraga"
                elif meg_score >= MEGUMI_THRESHOLD and meg_score >= mah_score:
                    label = "megumi"
                else:
                    label = None
                if (label == "megumi" and not ENABLE_MEGUMI) or (label == "mahoraga" and not ENABLE_MAHORAGA):
                    label = None  # that boss is switched off in the settings

                # only act once the same banner has won several scans in a row
                if label == streak_label:
                    streak += 1
                else:
                    streak_label, streak = label, 1

                if label and streak >= CONFIRM_FRAMES:
                    if label == "mahoraga":
                        # Mahoraga: always scanned; takes over from Megumi if it shows up
                        if current_name != "mahoraga":
                            last_macro_activity = time.monotonic()
                            log("MAHORAGA", f"Detected ({mah_score:.2f}), spamming Z X C V R until Retry")
                            start_routine("mahoraga", mahoraga_routine)
                    elif megumi_armed and current_name != "mahoraga":
                        # Megumi: always scanned, but only acts when armed (re-armed by Retry)
                        last_macro_activity = time.monotonic()
                        log("MEGUMI", f"Detected ({meg_score:.2f}), starting in {MEGUMI_START_DELAY:g}s")
                        megumi_armed = False
                        if EQUIP_PAUSE_DURING_MEGUMI_WAIT:
                            equip_hold_until = time.perf_counter() + MEGUMI_START_DELAY
                        start_routine("megumi", megumi_routine)

                # sleep only the remaining time so the loop targets POLL_DELAY total
                elapsed = time.perf_counter() - loop_start
                time.sleep(max(0.0, POLL_DELAY - elapsed))


def supervised(name, fn):
    """Run fn until shutdown. If it crashes (screen capture hiccup, bad frame, ...), log it,
    free any held keys and start it again instead of silently dying."""
    while not shutdown.is_set():
        try:
            fn()
            return
        except Exception as exc:
            log_crash(name, exc)
            release_keys(ALL_KEYS)
            retry_active.clear()
            timer_active.clear()
            if shutdown.wait(2.0):
                return
            log("INFO", f"Restarting {name}")


def watchdog():
    """Warn if a scanner thread stops looping; supervised workers handle crashes."""
    warned = set()
    while not shutdown.wait(5.0):
        now = time.monotonic()
        for name, beat in list(heartbeat.items()):
            if name == "equip" and not CONSTANT_EQUIP:
                continue
            age = now - beat
            if age > STALL_SECONDS and name not in warned:
                warned.add(name)
                log("WARN", f"{name} thread has not responded for {age:.0f}s")
            elif age <= STALL_SECONDS and name in warned:
                warned.discard(name)
                log("INFO", f"{name} thread is responding again")


def diagnostic_logger():
    while not shutdown.wait(60.0):
        now = time.monotonic()
        heartbeat_ages = {name: round(now - beat, 1) for name, beat in heartbeat.items()}
        missing_age = None
        with slot_presence_lock:
            if slot_missing_since is not None:
                missing_age = round(now - slot_missing_since, 1)
        with slot_state_lock:
            slot_states = dict(last_slot_states)
            slot_scores = {slot: dict(scores) for slot, scores in last_slot_scores.items()}
        log("DIAG", f"uptime={format_uptime(now - start_time)} loops={loop_count} rejoins={rejoin_count} "
            f"routine={current_name} game_window={game_window_exists()} "
            f"scanner_heartbeat_age={heartbeat_ages} scores={last_scores} "
            f"rejoin_scores={last_rejoin_scores} rejoin_active={REJOIN_ACTIVE.is_set()} "
            f"slot_states={slot_states} slot_scores={slot_scores} "
            f"slot_unrecognized_seconds={missing_age}", console=False)


def console_cleaner():
    while not shutdown.wait(CONSOLE_CLEAR_INTERVAL):
        _log_queue.put(_CLEAR)
        print_header()
        log("INFO", f"Console cleared | Loops: {loop_count} | Rejoins: {rejoin_count} "
            f"| Time: {format_uptime(time.monotonic() - start_time)}")


# ---- settings (pop-up shown before the macro starts) -------------------------
SETTINGS_PATH = ROOT / "settings.json"

RESOLUTIONS = [
    "1280x720", "1366x768", "1600x900", "1920x1080", "1920x1200", "2560x1080", "2560x1440",
    "2560x1600", "3440x1440", "3840x1080", "3840x1600", "3840x2160", "5120x1440", "5120x2160",
]
SKILL_KEYS = ("z", "x", "c", "v", "r", "mmb")  # "mmb" = middle mouse button click
SKILL_LABELS = {"mmb": "Middle click"}
IMAGE_FILES = ("Retry.png", "Megumi.png", "Mahoraga.png", "timer.png",
               "Equipted2.png", "Equipted3.png", "UnEquipted2.png", "UnEquipted3.png") + tuple(
                   REJOIN_TEMPLATE_FILES.values())

# The default coordinates were measured on a 3440x1440 screen. The scan boxes are always
# exactly what is typed in the settings (they are never scaled); only the PNG images are
# resized for other resolutions, by screen height compared with 1440 (the "image scale").
BASE_RES = (3440, 1440)

DEFAULT_SETTINGS = {
    "resolution": "3440x1440",
    "screen_mode": "half",      # "full" or "half" (recorded for reference)
    "image_scale": 1.0,         # size of the game's UI compared with the 3440x1440 layout
    "megumi_skills": ["x", "c", "v"],
    "mahoraga_skills": ["z", "x", "c", "v", "r"],
    "game_window": "Roblox",
    "areas": {                  # left, top, right, bottom
        "banner": [749, 122, 978, 155],
        "skills": [694, 1290, 860, 1368],
        "retry": [876, 841, 995, 887],
        "timer": [472, 46, 613, 102],
    },
    "home": [858, 926],
    "timing": {"retry_wait": 3.5, "megumi_wait": 5.0, "megumi_spam_wait": 4.5,
                               "clicks": 5, "timer_key_delay": 0.4, "raid_menu_wait": 20.0,
                               "portal_arrow_interval": 0.5, "portal_move_hold": 0.5,
                             "search_scroll_wait": 2.5, "search_scroll_count": 10,
                             "search_scroll_duration": 2.0, "raid_scroll_interval": 0.5,
                             "slot_missing_minutes": 5.0},
    "features": {"megumi": True, "mahoraga": True, "auto_equip": True, "timer": True,
                                 "stats_window": True, "color": True, "auto_rejoin": False,
                                 "snap_roblox_left": True},
    "portal_anchor": [860, 1008],
    "portal_deadzone": 70,
    "roblox_snap_target": [0, 664],
        "rejoin_areas": {
                "1": [139, 138, 1717, 693], "2": [262, 431, 1447, 494],
                "3": [30, 776, 247, 815], "4": [591, 625, 847, 728],
                "5": [22, 51, 78, 104], "6": [364, 1097, 690, 1154],
                "7": [592, 592, 862, 678], "8": [1920, 1375, 2046, 1438],
                "9": [1361, 492, 2082, 839], "10": [654, 43, 1165, 94],
                "11": [79, 109, 1699, 836], "12": [268, 177, 1104, 297],
                "13": [313, 517, 1390, 811], "14": [491, 608, 1206, 785],
                "15": [506, 1058, 894, 1143], "16": [0, 0, 3440, 1440],
                "17": [0, 0, 3438, 1378], "18": [0, 0, 3438, 1378],
                "19": [997, 942, 1317, 1053],
        },
    "skip_settings": False,
}

AREA_NAMES = {
    "banner": "Defeat Megumi/Mahoraga name",
    "skills": "Skills (hotbar slots 2 & 3)",
    "retry": "Retry button",
    "timer": "Timer (22:00)",
}


def parse_resolution(text):
    try:
        width, height = str(text).lower().replace(" ", "").split("x")
        width, height = int(width), int(height)
    except Exception:
        return None
    return (width, height) if width >= 320 and height >= 240 else None


def _merge(base, new):
    for key, value in new.items():
        if key in base:
            if isinstance(base[key], dict) and isinstance(value, dict):
                _merge(base[key], value)
            else:
                base[key] = value


def validate_settings(cfg):
    """Return an error message, or None if the settings are usable."""
    try:
        if parse_resolution(cfg["resolution"]) is None:
            return "Resolution must look like 2560x1440"
        if cfg["screen_mode"] not in ("full", "half"):
            return "Screen must be Fullscreen or Halfscreen"
        if not 0.3 <= float(cfg["image_scale"]) <= 3.0:
            return "Image scale must be between 0.3 and 3.0"
        for key, label in AREA_NAMES.items():
            box = cfg["areas"][key]
            if not (isinstance(box, list) and len(box) == 4
                    and all(isinstance(v, int) and not isinstance(v, bool) for v in box)):
                return f"{label}: coordinates must be whole numbers"
            left, top, right, bottom = box
            if min(box) < 0:
                return f"{label}: coordinates can't be negative"
            if right <= left or bottom <= top:
                return f"{label}: the two corners must be opposite corners of a box"
        home = cfg["home"]
        if not (isinstance(home, list) and len(home) == 2
                and all(isinstance(v, int) and not isinstance(v, bool) and v >= 0 for v in home)):
            return "Cursor home spot must be two whole numbers"
        timing = cfg["timing"]
        if min(float(timing["retry_wait"]), float(timing["megumi_wait"]),
               float(timing["megumi_spam_wait"])) < 0:
            return "Waits can't be negative"
        if not 1 <= int(timing["clicks"]) <= 30:
            return "Replay clicks must be between 1 and 30"
        if not 0.05 <= float(timing["timer_key_delay"]) <= 5:
            return "Delay between Esc / R / Enter must be between 0.05 and 5 seconds"
        if not 0.1 <= float(timing["portal_arrow_interval"]) <= 5:
            return "Portal arrow interval must be between 0.1 and 5 seconds"
        if not 0.1 <= float(timing["portal_move_hold"]) <= 5:
            return "Portal movement hold must be between 0.1 and 5 seconds"
        for name in ("megumi_skills", "mahoraga_skills"):
            if not all(k in SKILL_KEYS for k in cfg[name]):
                return "Skills can only be Z, X, C, V, R or Middle click"
        if not isinstance(cfg["game_window"], str):
            return "Game window title must be text"
        for key, box in cfg["rejoin_areas"].items():
            if str(key) not in {str(step) for step in REJOIN_STEP_NAMES} or not (
                    isinstance(box, list) and len(box) == 4
                    and all(isinstance(v, int) and not isinstance(v, bool) for v in box)):
                return f"Rejoin image {key}: scan area needs four whole-number coordinates"
            left, top, right, bottom = box
            if min(box) < 0 or right <= left or bottom <= top:
                return f"Rejoin image {key}: scan area corners are invalid"
        anchor = cfg["portal_anchor"]
        if not (isinstance(anchor, list) and len(anchor) == 2
            and all(isinstance(value, int) and not isinstance(value, bool) and value >= 0
                for value in anchor)):
            return "Portal player anchor must be two non-negative whole-number coordinates"
        if not 0 <= int(cfg["portal_deadzone"]) <= 500:
            return "Portal steering dead zone must be between 0 and 500 pixels"
        snap_target = cfg["roblox_snap_target"]
        if not (isinstance(snap_target, list) and len(snap_target) == 2
            and all(isinstance(value, int) and not isinstance(value, bool) and value >= 0
                for value in snap_target)):
            return "Roblox snap target must be two non-negative whole-number coordinates"
        timing = cfg["timing"]
        if float(timing["raid_menu_wait"]) < 0 or float(timing["search_scroll_wait"]) < 0:
            return "Rejoin waits cannot be negative"
        if not 1 <= int(timing["search_scroll_count"]) <= 50:
            return "Search-page scroll count must be between 1 and 50"
        if not 0.1 <= float(timing["search_scroll_duration"]) <= 10:
            return "Search-page scroll duration must be between 0.1 and 10 seconds"
        if not 0.1 <= float(timing["raid_scroll_interval"]) <= 5:
            return "Raid-list scroll interval must be between 0.1 and 5 seconds"
        if not 0.5 <= float(timing["slot_missing_minutes"]) <= 60:
            return "Missing hotbar timeout must be between 0.5 and 60 minutes"
        for name in ("megumi", "mahoraga", "auto_equip", "timer", "stats_window", "color",
                 "auto_rejoin", "snap_roblox_left"):
            if not isinstance(cfg["features"][name], bool):
                return "Feature switches must be on or off"
    except (KeyError, TypeError, ValueError):
        return "Some settings are missing or invalid"
    return None


def required_files(cfg):
    f = cfg["features"]
    need = ["Retry.png"]
    if f["megumi"] or f["mahoraga"]:
        need += ["Megumi.png", "Mahoraga.png"]  # both: they're told apart by comparing scores
    if f["timer"]:
        need.append("timer.png")
    if f["auto_equip"] or f["auto_rejoin"]:
        need += ["Equipted2.png", "Equipted3.png", "UnEquipted2.png", "UnEquipted3.png"]
    if f["auto_rejoin"]:
        need.extend(REJOIN_TEMPLATE_FILES.values())
    return need


def missing_files(cfg):
    return [name for name in required_files(cfg) if not (ROOT / name).exists()]


def image_size(name):
    path = ROOT / name
    if not path.exists():
        return None
    img = cv2.imdecode(np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
    return None if img is None else (img.shape[1], img.shape[0])


def check_fit(cfg):
    """Return a message if a scan box is too small to ever contain its image."""
    scale = float(cfg["image_scale"])
    f = cfg["features"]

    def too_small(label, box, names, pad, factor):
        left, top, right, bottom = box
        box_w, box_h = right - left + 2 * pad, bottom - top + 2 * pad
        for name in names:
            size = image_size(name)
            if size is None:
                continue
            need_w, need_h = round(size[0] * scale * factor), round(size[1] * scale * factor)
            if need_w > box_w or need_h > box_h:
                return (f"{label} box is too small for {name}: it needs at least {need_w}x{need_h}px "
                        f"but the box is {box_w}x{box_h}px. Make the box bigger or check the image scale")
        return None

    a = cfg["areas"]
    checks = [too_small("Retry", a["retry"], ["Retry.png"], 0, 1.0)]
    if f["megumi"] or f["mahoraga"]:
        checks.append(too_small("Defeat Megumi/Mahoraga name", a["banner"],
                                ["Megumi.png", "Mahoraga.png"], BANNER_PAD, 0.70))
    if f["timer"]:
        checks.append(too_small("Timer", a["timer"], ["timer.png"], TIMER_PAD, 1.0))
    if f["auto_equip"]:
        left, top, right, bottom = a["skills"]
        mid = (left + right) // 2
        for slot, (x1, x2) in (("2", (left, mid)), ("3", (mid, right))):
            checks.append(too_small(f"Skills slot {slot}", [x1, top, x2, bottom],
                                    [f"Equipted{slot}.png", f"UnEquipted{slot}.png"], SLOT_PAD, 1.0))
    if f["auto_rejoin"]:
        for step, filename in REJOIN_TEMPLATE_FILES.items():
            checks.append(too_small(f"Rejoin image {step}", cfg["rejoin_areas"][str(step)],
                                    [filename], REJOIN_MATCH_PAD, 1.0))
    return next((c for c in checks if c), None)


def load_settings():
    """Returns (settings, found_a_valid_saved_file)."""
    cfg = copy.deepcopy(DEFAULT_SETTINGS)
    if not SETTINGS_PATH.exists():
        return cfg, False
    try:
        _merge(cfg, json.loads(SETTINGS_PATH.read_text(encoding="utf-8")))
        problem = validate_settings(cfg)
    except Exception as exc:
        problem = f"could not be read ({exc})"
    if problem:
        log("WARN", f"{SETTINGS_PATH.name}: {problem} - using the default settings")
        return copy.deepcopy(DEFAULT_SETTINGS), False
    return cfg, True


def save_settings(cfg):
    try:
        tmp = SETTINGS_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        tmp.replace(SETTINGS_PATH)
        log("INFO", f"Settings saved to {SETTINGS_PATH.name}")
    except Exception as exc:
        log("WARN", f"Could not save settings: {exc}")


def apply_settings(cfg):
    """Copy the chosen settings into the macro's configuration values."""
    global RETRY_REGION, MEGUMI_REGION, MAHORAGA_REGION, TIMER_REGION, SLOT_REGIONS, HOME_POS
    global MEGUMI_KEYS, MAHORAGA_KEYS, GAME_WINDOW_TITLE, TEMPLATE_SCALE, RESOLUTION_LABEL
    global RETRY_MOVE_DELAY, MEGUMI_START_DELAY, MEGUMI_SPAM_DELAY, CLICK_COUNT, TIMER_KEY_DELAY
    global ENABLE_MEGUMI, ENABLE_MAHORAGA, ENABLE_TIMER, ENABLE_AUTO_EQUIP, CONSTANT_EQUIP
    global STATS_WINDOW, USE_COLOR
    global REJOIN_ENABLED, REJOIN_AREAS, REJOIN_MENU_WAIT
    global SNAP_ROBLOX_AFTER_REJOIN, ROBLOX_SNAP_REGION, ROBLOX_SNAP_TARGET
    global PORTAL_ARROW_INTERVAL, PORTAL_MOVE_HOLD
    global PORTAL_PLAYER_ANCHOR, PORTAL_STEER_DEADZONE
    global REJOIN_SEARCH_SCROLL_WAIT, REJOIN_SEARCH_SCROLL_COUNT, REJOIN_SEARCH_SCROLL_DURATION
    global REJOIN_SCROLL_INTERVAL, SLOT_MISSING_TIMEOUT

    areas = cfg["areas"]
    RETRY_REGION = tuple(areas["retry"])
    MEGUMI_REGION = MAHORAGA_REGION = tuple(areas["banner"])
    TIMER_REGION = tuple(areas["timer"])
    left, top, right, bottom = areas["skills"]
    mid = (left + right) // 2
    SLOT_REGIONS = {"2": (left, top, mid, bottom), "3": (mid, top, right, bottom)}
    HOME_POS = tuple(cfg["home"])

    MEGUMI_KEYS = tuple(k for k in SKILL_KEYS if k in cfg["megumi_skills"])
    MAHORAGA_KEYS = tuple(k for k in SKILL_KEYS if k in cfg["mahoraga_skills"])
    GAME_WINDOW_TITLE = cfg["game_window"].strip() or None
    TEMPLATE_SCALE = float(cfg["image_scale"])
    REJOIN_AREAS = {int(key): tuple(box) for key, box in cfg["rejoin_areas"].items()}
    ROBLOX_SNAP_REGION = tuple(cfg["rejoin_areas"]["17"])
    gray_snap_region = tuple(cfg["rejoin_areas"]["18"])
    if gray_snap_region != ROBLOX_SNAP_REGION:
        log("WARN", "Roblox titlebar template scan regions differ; using image 17 bounds")
    ROBLOX_SNAP_TARGET = tuple(cfg["roblox_snap_target"])
    PORTAL_PLAYER_ANCHOR = tuple(cfg["portal_anchor"])
    PORTAL_STEER_DEADZONE = int(cfg["portal_deadzone"])

    timing = cfg["timing"]
    RETRY_MOVE_DELAY = float(timing["retry_wait"])
    MEGUMI_START_DELAY = float(timing["megumi_wait"])
    MEGUMI_SPAM_DELAY = float(timing["megumi_spam_wait"])
    CLICK_COUNT = int(timing["clicks"])
    TIMER_KEY_DELAY = float(timing["timer_key_delay"])
    REJOIN_MENU_WAIT = float(timing["raid_menu_wait"])
    PORTAL_ARROW_INTERVAL = float(timing["portal_arrow_interval"])
    PORTAL_MOVE_HOLD = float(timing["portal_move_hold"])
    REJOIN_SEARCH_SCROLL_WAIT = float(timing["search_scroll_wait"])
    REJOIN_SEARCH_SCROLL_COUNT = int(timing["search_scroll_count"])
    REJOIN_SEARCH_SCROLL_DURATION = float(timing["search_scroll_duration"])
    REJOIN_SCROLL_INTERVAL = float(timing["raid_scroll_interval"])
    SLOT_MISSING_TIMEOUT = float(timing["slot_missing_minutes"]) * 60.0

    features = cfg["features"]
    ENABLE_MEGUMI = features["megumi"]
    ENABLE_MAHORAGA = features["mahoraga"]
    ENABLE_TIMER = features["timer"]
    ENABLE_AUTO_EQUIP = CONSTANT_EQUIP = features["auto_equip"]
    STATS_WINDOW = features["stats_window"]
    USE_COLOR = features["color"]
    REJOIN_ENABLED = features["auto_rejoin"]
    SNAP_ROBLOX_AFTER_REJOIN = features["snap_roblox_left"]

    where = "Fullscreen" if cfg["screen_mode"] == "full" else "Halfscreen"
    RESOLUTION_LABEL = f"{cfg['resolution']} {where} | image scale {TEMPLATE_SCALE:.2f}"
    log("SETTINGS", "Applied configuration: " + json.dumps(cfg, sort_keys=True, separators=(",", ":")))


def run_settings_window(cfg):
    """Pop-up shown before the macro starts. Returns the confirmed settings dict, or None if
    the window was closed / Quit was pressed. Without tkinter it returns cfg unchanged."""
    try:
        import tkinter as tk
        root = tk.Tk()
    except Exception:
        log("WARN", "tkinter not available, skipping the settings window")
        return cfg

    log("SETTINGS", "Settings window opened")

    BG, PANEL, FG, MUTED = "#15171c", "#1d2027", "#e8ecf4", "#8b93a7"
    ENTRY_BG, LINE, ACCENT, GOOD, BAD = "#0f1115", "#2a2f3a", "#6ea8ff", "#35c46b", "#ef6b63"
    F, FB, FS = ("Segoe UI", 10), ("Segoe UI", 10, "bold"), ("Segoe UI", 9)

    root.title(f"{APP_NAME} - Settings")
    root.configure(bg=BG)
    screen_w, screen_h = root.winfo_screenwidth(), root.winfo_screenheight()
    win_w, win_h = min(960, screen_w - 60), min(980, screen_h - 110)
    root.geometry(f"{win_w}x{win_h}+{max(0, (screen_w - win_w) // 2)}+{max(0, (screen_h - win_h) // 2 - 20)}")
    root.minsize(640, 480)
    root.lift()
    root.attributes("-topmost", True)
    root.after(400, lambda: root.attributes("-topmost", False))
    result = {"cfg": None}
    ui = {}

    # ---- form variables ------------------------------------------------------
    res_var, mode_var = tk.StringVar(), tk.StringVar()
    scale_var, window_var, custom_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
    megumi_keys = {k: tk.BooleanVar() for k in SKILL_KEYS}
    mahoraga_keys = {k: tk.BooleanVar() for k in SKILL_KEYS}
    area_vars = {key: [tk.StringVar() for _ in range(4)] for key in AREA_NAMES}  # TR x,y  BL x,y
    rejoin_area_vars = {key: [tk.StringVar() for _ in range(4)]
                        for key in DEFAULT_SETTINGS["rejoin_areas"]}
    roblox_snap_target_vars = [tk.StringVar(), tk.StringVar()]
    portal_anchor_vars = [tk.StringVar(), tk.StringVar()]
    portal_deadzone_var = tk.StringVar()
    home_vars = [tk.StringVar(), tk.StringVar()]
    timing_vars = {name: tk.StringVar() for name in DEFAULT_SETTINGS["timing"]}
    feature_vars = {name: tk.BooleanVar() for name in DEFAULT_SETTINGS["features"]}
    skip_var = tk.BooleanVar()

    # ---- tick / cross chips --------------------------------------------------
    chips = []

    def refresh():
        for paint in chips:
            paint()
        if "selected" in ui:
            ui["selected"].config(text=f"Selected: {res_var.get() or '-'}")

    def make_chip(parent, text, is_on, on_click):
        lbl = tk.Label(parent, font=FB, padx=10, pady=4, cursor="hand2")

        def paint():
            on = is_on()
            lbl.config(text=("\u2714 " if on else "\u2716 ") + text,
                       bg="#1c3a29" if on else "#2b2124", fg="#6ee79a" if on else "#d68c8c")

        lbl.bind("<Button-1>", lambda event: on_click())
        chips.append(paint)
        paint()
        return lbl

    def choice_chip(parent, text, var, value, after=None):
        def click():
            var.set(value)
            refresh()
            if after:
                after()
        return make_chip(parent, text, lambda: var.get() == value, click)

    def toggle_chip(parent, text, var):
        def click():
            var.set(not var.get())
            refresh()
        return make_chip(parent, text, var.get, click)

    def file_chip(parent, name):
        return make_chip(parent, name, lambda: (ROOT / name).exists(), lambda: None)

    # ---- small widget helpers ------------------------------------------------
    def label(parent, text, fg=FG, font=F):
        return tk.Label(parent, text=text, bg=BG, fg=fg, font=font, anchor="w")

    def entry(parent, var, width=7):
        return tk.Entry(parent, textvariable=var, width=width, bg=ENTRY_BG, fg=FG, insertbackground=FG,
                        relief="flat", justify="center", font=F, highlightthickness=1,
                        highlightbackground=LINE, highlightcolor=ACCENT)

    def button(parent, text, command, bg=LINE, fg=FG, font=F):
        return tk.Button(parent, text=text, command=command, bg=bg, fg=fg, activebackground=bg,
                         activeforeground=fg, relief="flat", bd=0, padx=12, pady=5, font=font,
                         cursor="hand2")

    # ---- footer (message + buttons) -----------------------------------------
    footer = tk.Frame(root, bg=PANEL, padx=16, pady=10)
    footer.pack(side="bottom", fill="x")
    msg_var = tk.StringVar(value="")
    msg_label = tk.Label(footer, textvariable=msg_var, bg=PANEL, fg=MUTED, font=FS, justify="left",
                         anchor="w", wraplength=max(200, win_w - 420))

    def say(text, kind="info"):
        msg_var.set(text)
        msg_label.config(fg={"bad": BAD, "good": GOOD}.get(kind, MUTED))

    # ---- behaviour -----------------------------------------------------------
    def show_area(key, box):
        left, top, right, bottom = box
        x1, y1, x2, y2 = area_vars[key]
        x1.set(str(right)); y1.set(str(top)); x2.set(str(left)); y2.set(str(bottom))

    def fill_form(c):
        res_var.set(c["resolution"]); mode_var.set(c["screen_mode"])
        scale_var.set(f"{float(c['image_scale']):.2f}"); window_var.set(c["game_window"])
        for k in SKILL_KEYS:
            megumi_keys[k].set(k in c["megumi_skills"])
            mahoraga_keys[k].set(k in c["mahoraga_skills"])
        for key in AREA_NAMES:
            show_area(key, c["areas"][key])
        for key, box in c["rejoin_areas"].items():
            left, top, right, bottom = box
            x1, y1, x2, y2 = rejoin_area_vars[key]
            x1.set(str(right)); y1.set(str(top)); x2.set(str(left)); y2.set(str(bottom))
        portal_anchor_vars[0].set(str(c["portal_anchor"][0]))
        portal_anchor_vars[1].set(str(c["portal_anchor"][1]))
        portal_deadzone_var.set(str(c["portal_deadzone"]))
        roblox_snap_target_vars[0].set(str(c["roblox_snap_target"][0]))
        roblox_snap_target_vars[1].set(str(c["roblox_snap_target"][1]))
        home_vars[0].set(str(c["home"][0])); home_vars[1].set(str(c["home"][1]))
        for name, var in timing_vars.items():
            var.set(str(c["timing"][name]))
        for name, var in feature_vars.items():
            var.set(c["features"][name])
        skip_var.set(c["skip_settings"])
        refresh()

    def on_resolution(*_):
        """Picking a resolution only updates the image scale - the scan boxes are never touched."""
        res = parse_resolution(res_var.get())
        if res is None:
            return
        scale_var.set(f"{res[1] / BASE_RES[1]:.2f}")
        say(f"Image scale set to {scale_var.get()} for {res[0]}x{res[1]}. Your scan boxes are unchanged.")

    def detect():
        res_var.set(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")
        on_resolution()
        refresh()

    def use_custom():
        res = parse_resolution(custom_var.get())
        if res is None:
            say("\u2716 Type a resolution like 2560x1600", "bad")
            return
        res_var.set(f"{res[0]}x{res[1]}")
        on_resolution()
        refresh()

    def auto_scale():
        res = parse_resolution(res_var.get())
        if res:
            scale_var.set(f"{res[1] / BASE_RES[1]:.2f}")

    def grab(xvar, yvar, desc):
        """3-second countdown, then read where the mouse pointer is."""
        def step(n):
            if n > 0:
                say(f"Move the mouse onto the {desc} - capturing in {n}...")
                root.after(1000, lambda: step(n - 1))
                return
            try:
                point = _Point()
                ctypes.windll.user32.GetCursorPos(ctypes.byref(point))
            except Exception:
                say("\u2716 Couldn't read the mouse position (Windows only)", "bad")
                return
            xvar.set(str(point.x)); yvar.set(str(point.y))
            say(f"Captured {desc}: X {point.x}, Y {point.y}", "good")
        step(3)

    def collect():
        """Read the form. Returns (settings, error message)."""
        new = copy.deepcopy(DEFAULT_SETTINGS)
        new["resolution"] = res_var.get().strip().lower()
        new["screen_mode"] = mode_var.get()
        try:
            new["image_scale"] = float(scale_var.get())
        except ValueError:
            return None, "Image scale must be a number like 1.00"
        new["megumi_skills"] = [k for k in SKILL_KEYS if megumi_keys[k].get()]
        new["mahoraga_skills"] = [k for k in SKILL_KEYS if mahoraga_keys[k].get()]
        new["game_window"] = window_var.get().strip()
        for key, label_text in AREA_NAMES.items():
            try:
                x1, y1, x2, y2 = (int(v.get()) for v in area_vars[key])
            except ValueError:
                return None, f"{label_text}: coordinates must be whole numbers"
            # the two corners can be any opposite pair; store as left, top, right, bottom
            new["areas"][key] = [min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)]
        for key, variables in rejoin_area_vars.items():
            try:
                x1, y1, x2, y2 = (int(value.get()) for value in variables)
            except ValueError:
                return None, f"Rejoin image {key}: coordinates must be whole numbers"
            new["rejoin_areas"][key] = [min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)]
        try:
            new["portal_anchor"] = [int(value.get()) for value in portal_anchor_vars]
            new["portal_deadzone"] = int(portal_deadzone_var.get())
        except ValueError:
            return None, "Portal anchor and dead zone must be whole numbers"
        try:
            new["roblox_snap_target"] = [int(value.get()) for value in roblox_snap_target_vars]
        except ValueError:
            return None, "Roblox snap destination must be two whole-number coordinates"
        try:
            new["home"] = [int(home_vars[0].get()), int(home_vars[1].get())]
        except ValueError:
            return None, "Cursor home spot: coordinates must be whole numbers"
        try:
            new["timing"] = {
                "retry_wait": float(timing_vars["retry_wait"].get()),
                "megumi_wait": float(timing_vars["megumi_wait"].get()),
                "megumi_spam_wait": float(timing_vars["megumi_spam_wait"].get()),
                "clicks": int(timing_vars["clicks"].get()),
                "timer_key_delay": float(timing_vars["timer_key_delay"].get()),
                "raid_menu_wait": float(timing_vars["raid_menu_wait"].get()),
                "portal_arrow_interval": float(timing_vars["portal_arrow_interval"].get()),
                "portal_move_hold": float(timing_vars["portal_move_hold"].get()),
                "search_scroll_wait": float(timing_vars["search_scroll_wait"].get()),
                "search_scroll_count": int(timing_vars["search_scroll_count"].get()),
                "search_scroll_duration": float(timing_vars["search_scroll_duration"].get()),
                "raid_scroll_interval": float(timing_vars["raid_scroll_interval"].get()),
                "slot_missing_minutes": float(timing_vars["slot_missing_minutes"].get()),
            }
        except ValueError:
            return None, "Timing values must be numbers (Replay clicks a whole number)"
        new["features"] = {name: var.get() for name, var in feature_vars.items()}
        new["skip_settings"] = skip_var.get()
        return new, None

    def on_save():
        new, problem = collect()
        if not problem:
            problem = validate_settings(new)
        if not problem:
            missing = missing_files(new)
            if missing:
                problem = "Missing image file(s): " + ", ".join(missing) + " - put them next to the macro"
        if not problem:
            problem = check_fit(new)
        if problem:
            log("SETTINGS", f"Save rejected: {problem}")
            say("\u2716 " + problem, "bad")
            return
        result["cfg"] = new
        log("SETTINGS", "Save & Run accepted")
        root.destroy()

    def on_reset():
        fill_form(DEFAULT_SETTINGS)
        log("SETTINGS", "Reset settings to defaults in the form")
        say("Back to the default settings (nothing is saved until you press Save & Run).")

    def on_quit():
        log("SETTINGS", "Settings window closed without starting")
        root.destroy()

    button(footer, "Save & Run", on_save, bg="#2f9e5b", fg="#ffffff", font=FB).pack(side="right")
    button(footer, "Quit", on_quit).pack(side="right", padx=(0, 10))
    button(footer, "Reset to defaults", on_reset).pack(side="right", padx=(0, 10))
    msg_label.pack(side="left", fill="x", expand=True)

    # ---- scrollable body -----------------------------------------------------
    canvas = tk.Canvas(root, bg=BG, highlightthickness=0)
    scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    body = tk.Frame(canvas, bg=BG, padx=24, pady=12)
    body_id = canvas.create_window((0, 0), window=body, anchor="nw")
    body.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>", lambda e: canvas.itemconfigure(body_id, width=e.width))
    root.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120), "units"))

    def section(title, note=None):
        tk.Label(body, text=title, bg=BG, fg=ACCENT, font=("Segoe UI", 11, "bold"),
                 anchor="w").pack(fill="x", pady=(18, 2))
        tk.Frame(body, bg=LINE, height=1).pack(fill="x", pady=(0, 6))
        if note:
            tk.Label(body, text=note, bg=BG, fg=MUTED, font=FS, justify="left", anchor="w",
                     wraplength=max(300, win_w - 110)).pack(fill="x", pady=(0, 6))
        frame = tk.Frame(body, bg=BG)
        frame.pack(fill="x")
        return frame

    tk.Label(body, text=APP_NAME.upper(), bg=BG, fg=FG, font=("Segoe UI", 18, "bold"),
             anchor="w").pack(fill="x")
    tk.Label(body, text=f"Settings   |   {CREDIT}", bg=BG, fg=MUTED, font=FS,
             anchor="w").pack(fill="x")

    # ---- MONITOR / GAME ------------------------------------------------------
    mg = section("MONITOR / GAME", "Click an option to tick it (\u2714) or untick it (\u2716).")
    label(mg, "Resolution").grid(row=0, column=0, sticky="nw", padx=(0, 18), pady=4)
    res_grid = tk.Frame(mg, bg=BG)
    res_grid.grid(row=0, column=1, sticky="w")
    for i, res in enumerate(RESOLUTIONS):
        choice_chip(res_grid, res, res_var, res, on_resolution).grid(row=i // 5, column=i % 5,
                                                                  padx=3, pady=3, sticky="w")
    res_tools = tk.Frame(mg, bg=BG)
    res_tools.grid(row=1, column=1, sticky="w", pady=(2, 8))
    ui["selected"] = label(res_tools, "", font=FB)
    ui["selected"].pack(side="left", padx=(3, 14))
    button(res_tools, "Detect my screen", detect).pack(side="left", padx=(0, 14))
    label(res_tools, "Other:", fg=MUTED).pack(side="left")
    entry(res_tools, custom_var, 11).pack(side="left", padx=4)
    button(res_tools, "Use", use_custom).pack(side="left")

    label(mg, "Screen").grid(row=2, column=0, sticky="nw", padx=(0, 18), pady=4)
    screen_row = tk.Frame(mg, bg=BG)
    screen_row.grid(row=2, column=1, sticky="w")
    choice_chip(screen_row, "Fullscreen", mode_var, "full").pack(side="left", padx=3, pady=3)
    choice_chip(screen_row, "Halfscreen", mode_var, "half").pack(side="left", padx=3)

    label(mg, "Skills vs Megumi").grid(row=3, column=0, sticky="nw", padx=(0, 18), pady=4)
    megumi_row = tk.Frame(mg, bg=BG)
    megumi_row.grid(row=3, column=1, sticky="w")
    for k in SKILL_KEYS:
        toggle_chip(megumi_row, SKILL_LABELS.get(k, k.upper()), megumi_keys[k]).pack(side="left", padx=3, pady=3)

    label(mg, "Skills vs Mahoraga").grid(row=4, column=0, sticky="nw", padx=(0, 18), pady=4)
    mahoraga_row = tk.Frame(mg, bg=BG)
    mahoraga_row.grid(row=4, column=1, sticky="w")
    for k in SKILL_KEYS:
        toggle_chip(mahoraga_row, SKILL_LABELS.get(k, k.upper()), mahoraga_keys[k]).pack(side="left", padx=3, pady=3)

    label(mg, "Game window title").grid(row=5, column=0, sticky="w", padx=(0, 18), pady=4)
    window_row = tk.Frame(mg, bg=BG)
    window_row.grid(row=5, column=1, sticky="w")
    entry(window_row, window_var, 22).pack(side="left", padx=3)
    label(window_row, "  exact title of the game window (used to bring it to the front)",
          fg=MUTED, font=FS).pack(side="left")

    label(mg, "Image scale").grid(row=6, column=0, sticky="w", padx=(0, 18), pady=4)
    scale_row = tk.Frame(mg, bg=BG)
    scale_row.grid(row=6, column=1, sticky="w")
    entry(scale_row, scale_var, 7).pack(side="left", padx=3)
    button(scale_row, "Auto", auto_scale, font=FS).pack(side="left", padx=6)
    label(scale_row, "resizes the PNG images for your resolution (1.00 = the 3440x1440 size); "
                     "set automatically when you pick a resolution", fg=MUTED, font=FS).pack(side="left")
    mg.grid_columnconfigure(1, weight=1)

    # ---- SCAN AREAS ------------------------------------------------------------
    sa = section(
        "SCAN AREAS",
        "These are the boxes on your screen that the macro watches. For every box enter two "
        "OPPOSITE corners: the TOP-RIGHT corner and the BOTTOM-LEFT corner (X = across, "
        "Y = down, in screen pixels). Tip: press Grab, then hover your mouse over that corner "
        "for 3 seconds. These boxes are always exactly what you type here - changing the "
        "resolution above never moves them.")
    label(sa, "Top-right corner", fg=MUTED, font=FS).grid(row=0, column=1, sticky="w")
    label(sa, "Bottom-left corner", fg=MUTED, font=FS).grid(row=0, column=2, sticky="w", padx=(24, 0))

    def corner(parent, xvar, yvar, desc):
        frame = tk.Frame(parent, bg=BG)
        label(frame, "X", fg=MUTED, font=FS).pack(side="left")
        entry(frame, xvar, 6).pack(side="left", padx=(3, 8))
        label(frame, "Y", fg=MUTED, font=FS).pack(side="left")
        entry(frame, yvar, 6).pack(side="left", padx=(3, 8))
        button(frame, "Grab", lambda: grab(xvar, yvar, desc), font=FS).pack(side="left")
        return frame

    for i, (key, text) in enumerate(AREA_NAMES.items(), start=1):
        label(sa, text).grid(row=i, column=0, sticky="w", padx=(0, 18), pady=5)
        corner(sa, area_vars[key][0], area_vars[key][1], f"{text} - top-right corner").grid(
            row=i, column=1, sticky="w")
        corner(sa, area_vars[key][2], area_vars[key][3], f"{text} - bottom-left corner").grid(
            row=i, column=2, sticky="w", padx=(24, 0))
    home_row = len(AREA_NAMES) + 1
    label(sa, "Mouse parks at (home spot)").grid(row=home_row, column=0, sticky="w", padx=(0, 18), pady=5)
    corner(sa, home_vars[0], home_vars[1], "home spot").grid(row=home_row, column=1, sticky="w")

    # ---- TIMING ----------------------------------------------------------------
    tm = section("TIMING (seconds)")
    timing_rows = [
        ("Wait after Retry appears", "retry_wait"),
        ("Wait after Megumi appears", "megumi_wait"),
        ("Wait before Megumi skill spam", "megumi_spam_wait"),
        ("Replay button clicks", "clicks"),
        ("Delay between Esc / R / Enter", "timer_key_delay"),
        ("Wait after selecting Raids", "raid_menu_wait"),
        ("Portal arrow tap interval", "portal_arrow_interval"),
        ("Portal movement step hold", "portal_move_hold"),
        ("Wait before search-page scrolling", "search_scroll_wait"),
        ("Search-page scroll count", "search_scroll_count"),
        ("Search-page scroll duration", "search_scroll_duration"),
        ("Raid-list scroll interval", "raid_scroll_interval"),
        ("Missing hotbar timeout (minutes)", "slot_missing_minutes"),
    ]
    for i, (text, name) in enumerate(timing_rows):
        label(tm, text).grid(row=i // 2, column=(i % 2) * 2, sticky="w", padx=(0, 12), pady=5)
        entry(tm, timing_vars[name], 7).grid(row=i // 2, column=(i % 2) * 2 + 1, sticky="w",
                                              padx=(0, 40))

    # ---- FEATURES --------------------------------------------------------------
    ft = section("FEATURES", "Untick (\u2716) anything you don't want the macro to do.")
    feature_rows = [
        ("Megumi combo", "megumi"), ("Mahoraga skill spam", "mahoraga"),
        ("Auto-equip slots 2 & 3", "auto_equip"), ("22:00 time-limit reset", "timer"),
        ("Stats window (Loops / Rejoins / Time)", "stats_window"), ("Coloured console", "color"),
        ("Auto-rejoin after crash / missing hotbar", "auto_rejoin"),
        ("Snap reopened Roblox to left half", "snap_roblox_left"),
    ]
    for i, (text, name) in enumerate(feature_rows):
        toggle_chip(ft, text, feature_vars[name]).grid(row=i // 3, column=i % 3, padx=3, pady=3,
                                                       sticky="w")
    toggle_chip(ft, "Skip this window next time", skip_var).grid(row=3, column=0, padx=3, pady=(10, 3),
                                                                  sticky="w")
    label(ft, "To open it again later, start the macro with  --settings", fg=MUTED, font=FS).grid(
        row=3, column=1, columnspan=2, sticky="w", pady=(10, 3))

    # ---- REJOIN ---------------------------------------------------------------
    rj = section("AUTO REJOIN", "Optional. Rejoin uses the numbered image sequence and the screen areas below.")
    label(rj, "Screen areas (top-right and bottom-left corners, in pixels)", fg=MUTED, font=FS).grid(
        row=0, column=0, columnspan=3, sticky="w", pady=(6, 3))
    label(rj, "Image", fg=MUTED, font=FS).grid(row=1, column=0, sticky="w")
    label(rj, "Top-right X / Y", fg=MUTED, font=FS).grid(row=1, column=1, sticky="w")
    label(rj, "Bottom-left X / Y", fg=MUTED, font=FS).grid(row=1, column=2, sticky="w")
    for row, (key, name) in enumerate(REJOIN_STEP_NAMES.items(), start=2):
        label(rj, f"{key}. {name}", font=FS).grid(row=row, column=0, sticky="w", pady=2)
        variables = rejoin_area_vars[str(key)]
        for column, pair_start in ((1, 0), (2, 2)):
            pair = tk.Frame(rj, bg=BG)
            pair.grid(row=row, column=column, sticky="w", padx=(0, 10))
            entry(pair, variables[pair_start], 6).pack(side="left", padx=(0, 4))
            entry(pair, variables[pair_start + 1], 6).pack(side="left")
    anchor_row = len(REJOIN_STEP_NAMES) + 2
    label(rj, "Player anchor (screen position)", font=FS).grid(row=anchor_row, column=0, sticky="w", pady=4)
    anchor_frame = tk.Frame(rj, bg=BG)
    anchor_frame.grid(row=anchor_row, column=1, sticky="w", pady=4)
    label(anchor_frame, "X", fg=MUTED, font=FS).pack(side="left")
    entry(anchor_frame, portal_anchor_vars[0], 7).pack(side="left", padx=(3, 8))
    label(anchor_frame, "Y", fg=MUTED, font=FS).pack(side="left")
    entry(anchor_frame, portal_anchor_vars[1], 7).pack(side="left", padx=(3, 8))
    button(anchor_frame, "Grab", lambda: grab(
        portal_anchor_vars[0], portal_anchor_vars[1], "your character's screen position"), font=FS).pack(side="left")
    label(rj, "Steering dead zone (pixels)", font=FS).grid(row=anchor_row + 1, column=0, sticky="w", pady=4)
    entry(rj, portal_deadzone_var, 7).grid(row=anchor_row + 1, column=1, sticky="w", pady=4)
    snap_row = anchor_row + 2
    label(rj, "Roblox half-screen drop point", font=FS).grid(row=snap_row, column=0, sticky="w", pady=4)
    snap_frame = tk.Frame(rj, bg=BG)
    snap_frame.grid(row=snap_row, column=1, sticky="w", pady=4)
    label(snap_frame, "X", fg=MUTED, font=FS).pack(side="left")
    entry(snap_frame, roblox_snap_target_vars[0], 7).pack(side="left", padx=(3, 8))
    label(snap_frame, "Y", fg=MUTED, font=FS).pack(side="left")
    entry(snap_frame, roblox_snap_target_vars[1], 7).pack(side="left", padx=(3, 8))
    label(rj, "Titlebar scan bounds are images 17 and 18 above.", fg=MUTED, font=FS).grid(
        row=snap_row + 1, column=0, columnspan=3, sticky="w", pady=4)
    rj.grid_columnconfigure(1, weight=1)
    rj.grid_columnconfigure(2, weight=1)

    # ---- IMAGE FILES -----------------------------------------------------------
    im = section("IMAGE FILES", "These PNGs must sit in the same folder as the macro.")
    for i, name in enumerate(IMAGE_FILES):
        file_chip(im, name).grid(row=i // 4, column=i % 4, padx=3, pady=3, sticky="w")

    fill_form(cfg)
    say("Set everything up, then press Save & Run. Your choices are saved for next time.")
    root.protocol("WM_DELETE_WINDOW", on_quit)
    root.mainloop()
    return result["cfg"]


def main():
    # 1) settings: load the saved ones, show the pop-up (unless told to skip), save, apply
    cfg, have_saved = load_settings()
    if "--settings" in sys.argv or not cfg["skip_settings"] or not have_saved:
        chosen = run_settings_window(cfg)
        if chosen is None:  # window closed / Quit
            return
        cfg = chosen
        save_settings(cfg)
    apply_settings(cfg)

    # 2) fail early, clearly, if an image the chosen features need is missing
    try:
        for name in required_files(cfg):
            load_gray(ROOT / name)
        if ENABLE_AUTO_EQUIP or REJOIN_ENABLED:
            load_slot_templates()
        if REJOIN_ENABLED:
            rejoin_templates.update(load_rejoin_templates())
    except SystemExit as exc:
        log("ERROR", f"Startup image validation failed: {exc}")
        raise
    # Ctrl+C just raises the shutdown flag; every loop (and the stats window) watches it.
    signal.signal(signal.SIGINT, lambda *_: shutdown.set())
    try:
        ctypes.windll.kernel32.SetConsoleTitleW(APP_NAME)  # console window title (Windows)
    except Exception:
        pass
    disable_quickedit()
    while True:
        try:
            _log_queue.get_nowait()
        except queue.Empty:
            break
    os.system("cls")
    print_header()
    log("INFO", "Macro session started")
    heartbeat["scanner"] = heartbeat["equip"] = time.monotonic()
    if REJOIN_ENABLED:
        if game_window_exists():
            game_available.set()
        else:
            REJOIN_REQUESTED.set()
    workers = [threading.Thread(target=supervised, args=("scanner", watcher), daemon=True)]
    if CONSTANT_EQUIP or REJOIN_ENABLED:
        workers.append(threading.Thread(target=supervised, args=("equip scanner", equip_watcher), daemon=True))
    if REJOIN_ENABLED:
        workers.append(threading.Thread(target=rejoin_watcher, daemon=True))
        workers.append(threading.Thread(target=rejoin_runner, daemon=True))
    workers.append(threading.Thread(target=console_cleaner, daemon=True))
    workers.append(threading.Thread(target=diagnostic_logger, daemon=True))
    workers.append(threading.Thread(target=watchdog, daemon=True))
    for worker in workers:
        worker.start()
    try:
        if STATS_WINDOW and not run_stats_window():
            log("WARN", "tkinter not available, stats window disabled")
        elif STATS_WINDOW and not shutdown.is_set():
            log("INFO", "Stats window closed, macro still running (Ctrl+C to exit)")
        while not shutdown.is_set():
            time.sleep(0.25)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown.set()
        for worker in workers:  # let the scan threads finish before Python shuts down
            worker.join(timeout=2.0)
        stop_routine()
        release_keys(ALL_KEYS)
        log("INFO", f"Stopped | Loops: {loop_count} | Rejoins: {rejoin_count} "
            f"| Time: {format_uptime(time.monotonic() - start_time)}")
        _log_queue.put(None)  # let the printer thread flush the last lines
        _printer_thread.join(timeout=1.0)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        log_crash("main", exc)
        raise

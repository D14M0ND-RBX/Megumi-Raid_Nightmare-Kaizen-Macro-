@goto :cc_start
r"""
:cc_start
@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Calamity Cleaver

rem ===========================================================================
rem  CALAMITY CLEAVER - Jujutsu Zero / Nayoa Calamity raid macro.
rem  One file, launcher plus macro. Double-click it.
rem  It finds or installs Python, installs any missing libraries, then runs the macro
rem  code stored further down in this same file.
rem  The PNG images and the saved settings live in the same folder as this file.
rem ===========================================================================

rem --- what to install when no usable Python is found - edit here to change it
set "PY_WINGET_ID=Python.Python.3.12"
set "PY_URL=https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
set "PY_PACKAGES=mss opencv-python numpy pyautogui pydirectinput"

rem --- 1. look for a Python that really works (the Microsoft Store stub does not count)
set "PYEXE="
call :try_python py -3
call :try_python python
if not defined PYEXE call :find_installed
if defined PYEXE goto :have_python

rem --- 2. none found: install one
echo.
echo [INFO] No usable Python 3.9 or newer with tkinter was found. Installing Python...
where winget >nul 2>&1
if not errorlevel 1 (
    echo [INFO] Installing %PY_WINGET_ID% with winget - this can take a minute...
    winget install --id %PY_WINGET_ID% --exact --source winget --silent --accept-source-agreements --accept-package-agreements
)
call :find_installed
if not defined PYEXE call :try_python py -3
if defined PYEXE goto :have_python

echo [INFO] Downloading the Python installer from python.org...
set "PY_SETUP=%TEMP%\cc_python_setup.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%PY_URL%' -OutFile '%PY_SETUP%'"
if exist "%PY_SETUP%" (
    echo [INFO] Installing Python - please wait...
    start /wait "" "%PY_SETUP%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=1 Include_test=0 Shortcuts=0
    del "%PY_SETUP%" >nul 2>&1
)
call :find_installed
if not defined PYEXE call :try_python py -3
if defined PYEXE goto :have_python

echo.
echo [ERROR] Python could not be installed automatically.
echo         Install Python 3.12 from https://www.python.org/downloads/windows/
echo         and tick "Add python.exe to PATH", then run this file again.
pause
exit /b 1

rem --- 3. install any missing libraries (nothing is upgraded), then start the macro
:have_python
echo [INFO] Using Python: %PYEXE%
%PYEXE% -c "import mss, cv2, numpy, pyautogui, pydirectinput" >nul 2>&1
if not errorlevel 1 goto :start_macro
echo [INFO] Installing the required libraries - first run only, this can take a minute...
%PYEXE% -m pip install --disable-pip-version-check --quiet --retries 1 --timeout 15 %PY_PACKAGES%
%PYEXE% -c "import mss, cv2, numpy, pyautogui, pydirectinput" >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] A required library is missing and could not be installed.
    echo         Check your internet connection and run this file again.
    pause
    exit /b 1
)

:start_macro
echo [INFO] Starting Calamity Cleaver...
echo.
%PYEXE% -x "%~f0" %*
set "CC_EXIT=%errorlevel%"
echo.
if not "%CC_EXIT%"=="0" echo [ERROR] The macro stopped with error code %CC_EXIT%.
pause
exit /b %CC_EXIT%

rem ---------------------------------------------------------------------------
rem  subroutine: test one way of starting Python. Keeps it only if it runs, is
rem  version 3.9 or newer, and has tkinter for the settings window.
rem ---------------------------------------------------------------------------
:try_python
if defined PYEXE exit /b 0
%* -c "import sys, tkinter; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=%*"
exit /b 0

rem --- subroutine: look in the usual install folders, because a Python that was
rem     just installed is not on PATH yet in this window
:find_installed
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do call :try_python "%%D\python.exe"
for /d %%D in ("%ProgramFiles%\Python3*") do call :try_python "%%D\python.exe"
for /d %%D in ("%LOCALAPPDATA%\Python\pythoncore-3*") do call :try_python "%%D\python.exe"
exit /b 0
"""
# ============================================================================
#  Everything below is the macro itself (Python). The batch launcher above is
#  wrapped in a string so Python ignores it, and Python's -x flag skips line 1.
# ============================================================================
"""CALAMITY CLEAVER - Jujutsu Zero / Nayoa Calamity raid macro.

Every scan tick (0.05s, non-stop) these images are searched inside their own rectangle:
  Ready              -> raid starting: glide to it and click 3x
  Lv. 13,000 Zen'in  -> raid started: attack rotation begins
  Chase took too long-> phase 2 started
  Raid Summary: Successful -> raid beaten: Loops +1, then Retry is searched
  Raid Summary: Failure    -> you died: Loops unchanged, then Retry is searched
  Retry              -> only searched after a win or a fail: glide to it and click 5x
The stop key pauses the macro; pressing it again restarts it.
Disconnected box (Leave / Reconnect) -> searched non-stop; when seen, all other searches stop and the AUTO REJOIN steps run.
"""

import base64
import gc
import concurrent.futures
import ctypes
import json
import math
import os
import queue
import random
import sys
import threading
import time
import traceback
from ctypes import wintypes
from pathlib import Path

import cv2
import mss
import numpy as np
import pyautogui  # unused directly, but importing it makes the process DPI-aware (correct coordinates)
import pydirectinput

try:
    import tkinter as tk
except Exception:  # pragma: no cover
    tk = None

APP_NAME = "CALAMITY CLEAVER"
ROOT = Path(__file__).resolve().parent
SETTINGS_PATH = ROOT / "calamity_settings.json"
SCAN_DELAY = 0.05
RETRY_TIMEOUT = 180.0     # give up waiting for Retry after this many seconds
RESULT_COOLDOWN = 6.0     # ignore win/fail banners this long after Retry was clicked
READY_COOLDOWN = 4.0      # ignore Ready this long after it was clicked
KEY_GAP = 0.08            # pause between rotation key presses
COARSE_GATE = 0.55        # half-size pass must score this before the full-size check runs

pydirectinput.PAUSE = 0
pydirectinput.FAILSAFE = False
try:
    ctypes.windll.user32.SetProcessDPIAware()
    ctypes.windll.winmm.timeBeginPeriod(1)  # 1 ms timer so the mouse glide is smooth
except Exception:
    pass
user32 = ctypes.windll.user32 if os.name == "nt" else None

# image key -> (file, label used in settings/log, match threshold)
IMAGES = {
    "ready":   ("Ready.png",            "Ready",                   0.70),
    "retry":   ("Retry.png",            "Retry",                   0.70),
    "success": ("RaidSuccessful.png",   "Raid Summary Successful", 0.70),
    "failed":  ("RaidFailed.png",       "Raid Summary Failure",    0.70),
    "chase":   ("ChaseTookTooLong.png", "Chase Took Too Long",     0.70),
    "zenin":   ("ZeninElite.png",       "Lv. 13,000 Zenin Elite",  0.70),
    "disconnect": ("Disconnected.png", "Disconnected box (Leave / Reconnect)", 0.70),
    "rj_search": ("Rejoin_Search.png", "Rejoin: Search", 0.70),
    "rj_play": ("Rejoin_Play.png", "Rejoin: big blue Play button", 0.70),
    "rj_gamemodes": ("Rejoin_Gamemodes.png", "Rejoin: Gamemodes", 0.70),
    "rj_raids": ("Rejoin_Raids.png", "Rejoin: Raids", 0.70),
    "rj_create1": ("Rejoin_Create1.png", "Rejoin: Create (1st)", 0.85),   # strict: the two Create buttons look alike
    "rj_projection": ("Rejoin_Projection.png", "Rejoin: Projection Lv. 9,000+", 0.70),
    "rj_calamity": ("Rejoin_Calamity.png", "Rejoin: Calamity", 0.70),
    "rj_modifiers": ("Rejoin_Modifiers.png", "Rejoin: Modifiers", 0.70),
    "rj_weaken": ("Rejoin_Weaken.png", "Rejoin: Weaken +35%", 0.70),
    "rj_friends": ("Rejoin_FriendsOnly.png", "Rejoin: Friends Only", 0.70),
    "rj_create2": ("Rejoin_Create2.png", "Rejoin: Create (2nd)", 0.85),   # strict: the two Create buttons look alike
    "rj_start": ("Rejoin_Start.png", "Rejoin: Start", 0.70),
}
SCAN_KEYS = ("ready", "zenin", "chase", "success", "failed")

# ---- auto rejoin (the game kicks you now and then) --------------------------
# "disconnect" is searched all the time. When it shows up every other search stops and these steps run in order:
# click LEAVE on the disconnect box, then for each step below: wait for the image, glide the mouse to it, click it.
REJOIN_KEYS = ("disconnect", "rj_search", "rj_play", "rj_gamemodes", "rj_raids", "rj_create1", "rj_projection",
               "rj_calamity", "rj_modifiers", "rj_weaken", "rj_friends", "rj_create2", "rj_start")
REJOIN_STEPS = (   # (step number, image key, clicks, type the game name + Enter after clicking?)   step 1 = Leave (the disconnect box)
    (2,  "rj_search",     1, True),
    (3,  "rj_play",       3, False),
    (4,  "rj_gamemodes",  1, False),
    (5,  "rj_raids",      3, False),
    (6,  "rj_create1",    3, False),
    (7,  "rj_projection", 3, False),
    (8,  "rj_calamity",   3, False),
    (9,  "rj_modifiers",  1, False),
    (10, "rj_weaken",     1, False),
    (11, "rj_friends",    1, False),
    (12, "rj_create2",    3, False),
    (13, "rj_start",      5, False),
)
REJOIN_TOTAL = 13
# look-alike buttons: a step ignores a hit if the rival image fits better at that same spot
RIVALS = {"rj_create1": "rj_create2", "rj_create2": "rj_create1"}
REJOIN_TEXT = "Jujutsu: Zero"
REJOIN_SCALES = [1.0, 0.98, 1.02, 0.96, 1.04, 0.92, 1.08, 0.85, 1.15]   # menu images are drawn at about their saved size
REJOIN_SETTLE = 0.6        # pause after each rejoin click so the next screen can load
# The disconnect image holds both buttons; the click goes on the LEAVE one (fraction of image width/height from its centre).
CLICK_OFFSET = {"disconnect": (-0.253, 0.0)}
# The raid-summary images were saved at a different size than the buttons (measured on a real screen):
# Successful is drawn at 0.70x and Failure at 1.43x of the button size. Both are also cut down to just the
# last word, because the words "Raid Summary:" are identical and made Failure match the Successful banner.
REL_SCALE = {"success": 0.70, "failed": 1.43}
CROPS = {"success": (0.56, 1.0), "failed": (0.68, 1.0)}

ROTATION_KEYS = list("cfxrtvzy")
SHR = "Sorcerer Heavenly Restriction"
PHR = "Physical Heavenly Restriction"
CURSED_TECHNIQUES = ["awk projection", "awk limitless", "awk star-rage", "awk blood-manipulation",
                     "ten shadows", "shrine", "copy", "love train", "beast amber",
                     "projection sorcery", "limitless", "cursed energy discharge", "summer blade"]
WEAPONS = ["Light Katana", "True Inverted Spear of Heaven", "Inverted Spear of Heaven", "Dragon Bone",
           "Festering Life Sword", "Nyoi Staff", "Playful Cloud", "Soul Split Katana", "Kamutoke",
           "Summer Blade", "Autumn Blade", "Zenith Spear", "Celestto Spear", "Honoy Yagi", "Shattered Cloud"]
SLOT_KEYS = ["1", "2"]
SLOT_WHEN = ["At Ready", "At attack start", "Both"]
SLOT_SWAP_DELAY = 0.20    # wait after pressing a slot key so the item can be equipped
SLOT_METHODS = ["Press key", "Click position"]   # how a slot gets equipped
SELECT_CAP = 2
STOP_KEYS = [f"f{i}" for i in range(1, 13)]
LOG_CLEAR_MINUTES = [5, 10, 15, 20, 25, 30]
SCREEN_MODES = ["Half-Screen", "Corner Screen", "Full Screen"]
CORNERS = ["Top Left", "Top Right", "Bottom Left", "Bottom Right"]
RESOLUTIONS = ["640x480", "800x600", "1024x768", "1152x864", "1280x720", "1280x800", "1280x960",
               "1280x1024", "1360x768", "1366x768", "1440x900", "1600x900", "1600x1200", "1680x1050",
               "1768x992", "1920x1080", "1920x1200", "2048x1152", "2560x1080", "2560x1440", "2560x1600",
               "2880x1620", "3000x2000", "3200x1800", "3440x1440", "3840x1080", "3840x1600", "3840x2160",
               "5120x1440", "5120x2160", "5120x2880", "7680x4320"]
# template scales tried for each screen mode (Roblox UI shrinks in smaller windows)
SCALES = {"Full Screen": [1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 0.9, 0.8, 0.7, 0.6],
          "Half-Screen": [1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 0.9, 0.8, 0.7, 0.6],
          "Corner Screen": [1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 1.1, 1.2, 1.3]}
DEBUG_SCORES = False       # log the best match score per image every few seconds (set False when it works)
DEBUG_EVERY = 8.0
BEST = {}                  # key -> best score seen since last debug print

EMBEDDED = {
    "Ready.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAHsAAAAhCAIAAAB2sEO5AAAQlUlEQVR42o1abVBU1Ru/L7vswsLuwu7yuuCMbIBYukIMMg2D5Whg"
        "NZM4jr1I5fRimpNj0dQHqmHSLHJq1KmcLEfHYUowm3IyIyvDkVBzCCkVRkBgYVkW2GUXln279/4/PPyfTufeXTsfGO7Zc+8553ee"
        "53eeN7ayspJlWUmSGIaRJEkURYZhVCoVy7KRSAT6WZaFv/AITZIkSZJYlsXB0M/+vzFEI1/kOI5lWZiI/Djz74ZLgq/BdPgK+Sv5"
        "E64KvymKItUDf/EL5HQcx3EchzjgduQrxBd5nuc4jmEYQRBi7YhcoQqfsfE8zzBMNBoVRZF6TQ43z/Msy0ajUYQmFtwwAOFGFGJt"
        "Rj4d1SP/iRyAJ0Gek/xd8hHghrVRcOP6yRdhO3hCiEAsuOB4VDgr9sInBEEg56AQISVCEAQ4m1iDFeGOjzWeKACHEqeIOPU31iyo"
        "EKSKkJoXB25Svym44RUKbkXphvELiONMarUaBPyOcIOAB4NBn88nSRJoFm6P47iEhASNRgPnB8fLsix5PJT2UdKqCDdJCIpwwwBU"
        "cPL7kUhkdnZ2QbVVquTkZJwI1BqFjNq4ItxAJrAd6njk0gPb53leEAQVYo1iGIlEKJmi6BLpOxgMXrlyhZQUqrEsazAYMjMzLRYL"
        "eZDU+vDUKSIWRRH3I5+Fghu/qQh3OBzu6uoiP5KVlZWbm4u0QM5LXV1yrkfiJY+ZWiGpLiqViuO4cDgsiiJHgYibjKPFSN9+v1+K"
        "0QRBcLlcZ8+era2t7e/v7+vri0ajsWQBeZDkd1gJxcXkFJRAxFEISZLm5ubId+vr6+fm5kBOcSJEWX7NYgNRlSQJ4VakbFw5miEA"
        "tyRJHKkpeAfGMh7IkahQio3juPT09LVr137xxRdXrlxRq9V9fX2KZC0SDZdOPcqvUDn0sV6hyJRq1CvU1UddvHhCwD+xgCaPEI4H"
        "aGPBDkS1xW9R3EqpDIyklBfa8PCw0+mE//V6fUFBAWjf8uXLv//++7KyssnJSbPZrIg7ecyknile/fKeWGevKIYU3NQNqfgFvPZB"
        "zuSwyA8J4aa0YcE6BJYAAxxJU/GjeAHKr9aDBw/u27cPH9PT0w8cOLBp0yaGYZYtW/bcc881NzebTCYSblEUA4FAOBzmOE6r1Wo0"
        "GpK75VeIIAjBYDAajXIcp9Fo1Gq1oqkO787Pz4fDYZZlNRqN4mGIogjECD0ajQavU+gJhUKBQADNkqSkJDQQFO1LCm5BEAAo8ixV"
        "eMiUZCnevOQ5K1oyKSkpRUVFYBi4XK66urrS0lKbzcYwzKZNmz755JNIJKJSqSRJCgaDo6Oj09PTpK5otdqMjAyz2Qy3GXnkHo9n"
        "fHx8dnaWlIDExMT09HQcj/1ut9vpdAaDQSZuGx0dHRsbI3sKCwvT0tLg/2Aw2N3dTWqPwWBYsmSJ3IEi9RWORw73PzYiCricT+Qk"
        "CGoS3zjheV6lUul0uvz8fJZlv/32W/hp2bJlsA1RFD0eT09PT3Z29uHDhwcGBsLhcCAQuHr1an19vdfrvXnzZjgcJsmxv79/cHBw"
        "48aNbW1tk5OTgiB4vd6Ojo6dO3d6vd7e3l70eEVRvH379tjY2Pbt27u6ukBI29vbH3jgAflSBUGorKxEKnjssccmJiZw3qmpqUWL"
        "FuGvr732GvADdfGQjyiUkUgEXEg5eaqQweN7GSR9x0GcbIIgJCQkuN1uZHaQfY/H09fX19DQ0NjYiEqqVqtLSkpKSkpefPHFRx55"
        "pLe3t6ioCH69ffu2SqXq7OwsLS0lxa2ioqKiomLHjh1r1qwZHBy86667GIZxOByCIFy4cKGsrAwHV1ZW/vTTT+vXr6dWmJqaevHi"
        "RafTmZWVxTDMunXrWlpaBEGAeT0ez1NPPYWDW1paUlNT5cSNgALzoLsuvwkWeALENhaOlMuE90ac6wiORxTFSCQSCoWys7Oh3+v1"
        "wsSDg4OvvPLKO++8A+sLh8Pd3d39/f0wLCcnp62tTa/XO51OSZL8fv/U1FRrayvCPTMzc/XqVbyic3JyTp48OTs76/f7A4HAxMTE"
        "sWPHEO5QKNTd3e1wODiOO3z4MLVUg8HAcdzXX38Nj9XV1QzD+Hw+0JXZ2dmamhr46dKlS0NDQ4C43MoiJTISiSBK8rCEJEkLjINn"
        "Inf6kcFJmz9W8/l8Xq93ampqfHy8r69Po9Fs3LgRfvrjjz9YlvV6vVlZWXv27IHOH3/8cdGiRXa73WazVVVVTU5OMgxjNpt37949"
        "MTERjUbdbnd1dXVlZSWM//DDD9PT0++9916r1drU1ASdxcXFlZWVHo9nYmKiqqrq4Ycfhv729vbc3Fy73Z6Xl/fss8+CF0YRS2pq"
        "aktLCzxaLJaSkhKv18uyrMfj0Wg0999/Pwp4UlKSRqMhsSZR4nkehIxkEkU8/4nCUMEaMpQI3AQujKJxRrbe3t7e3t7JycmysrJf"
        "fvkFFJZhmGPHjun1eo/H8/zzz2u1WoZhnE7nhg0bJicnrVZrZmZme3v7yy+/DIOffPJJrVbr8/lYlr106VJVVdWWLVtef/31+vp6"
        "i8VSVFRkMBj27t2Lky5dujQcDnu9XuSBUCj0+OOPC4Jwzz335OfnHz169PPPP5ero8lkAmKBnoceemhmZkYQhOnp6aqqqqSkJOhv"
        "bW2lBJwEB6SWJO44NyJHCrhipFDRnZM7fgzDfPDBB9jv8/nOnTuH2t3W1vbll1+mpaUFg8G1a9dC51dffTU3NxeNRh0Ox/j4OMMw"
        "p0+fRqOlvLx8dnbWarXqdLrr168fPXq0qalJkqSxsbGbN296PJ7i4mLSaIHLqqKiAmd0Op15eXkajcZoNJpMpuPHj8sJMzk5mSKW"
        "+fn5QCAwMzODlPL777+PjIwYjUbKzSFlUa79itFNnuc5ykSRm5loEcZ3teO05ubm2tpak8kEdnFhYSH079q1i5Iav9+Pby1evDgS"
        "iUDswev16nS62tra999/v7W1tbOz0+VyXbx4Ub7m3NxceOzu7tZqteCCsSybnJzc3d2teEsZjUYklvLycrPZ7HQ6o9EoIn7ixImk"
        "pKSEhARyqUDc4ODEioZSEEGEQCUPTlJeLxkho7xQCnGHwzE6Ogr/l5WVAfV3dnZu3rzZaDRarVa4lMBouWPT6/WCIPh8vsHBwVdf"
        "ffWtt96iXpyamgJ/ikQcecDv94PVC6vleR4Dh5SnSlosLMs++OCDzc3N+fn5BQUF8NmTJ0+CgFOwkJZbrNAuOR64XqXo2pLHQhK9"
        "YhwS2/79+9HnPHTo0NatWxmGWbly5erVqy9fvoy5Dr/fD9iNjo46HI5YU7tcLkmSRkdHX3rpJfzs9evXT5061dPTc+PGjRs3bqAZ"
        "ji0QCOh0OrBDotEobk0QBIPBIJdxjuPQYtmxYwfDMDU1Nc3NzevWrYMxHR0do6OjwGDg9yF2ZNInVuqGlG7QBlX8pBfwCTIP6XMr"
        "sopWq7XZbE6ns7Gxsa6uDiRu79695eXlfr8/MTGRYZiBgQG73c4wzJkzZ1544YU4Yp6VleV0Onfu3AmP586dq6mp4Xlep9PNz8/L"
        "Y2cMwwwNDQE6drs9GAxGIhGI+Pv9fpiUghs2aDAYWlpaAPHq6mqO40hKSUxMVKvVCDeZhLmjpsLxQAx8gaXl2T8yxUPGyeRxSHlT"
        "qVQ8z2dnZ7vd7o8++ggZZv369ePj45Cj+Pnnn6F/w4YNqampKSkpNputoKDAbDbzPL9169ZHH33UbrdrtVqwjhYvXgzjf/31V57n"
        "CwoKwM5D0w33plKpOjo64HHNmjW5ubnDw8OhUGh6enpqamrLli3yPAPIndFovHjxInj8JpNp1apV8HGSUjBGLYc7lrxiJJ3MGHOK"
        "gVC06uOY6nFw53k+IyOjqalpamoKevbs2RMKhWZmZoxG42effQZQpqWlnT592mQy3bp1q6+vLxgMHjhw4NChQ998883Vq1fRfAbX"
        "CSIzer2+p6ent7f37rvvPnLkCDWv0Whsbm5GJ7a1tVWtVl+7dm1gYGDbtm11dXUUKLg7sFhOnjwJP+3btw/s1wsXLjidToPBgHki"
        "eUBYEW4kH9K7XMiOxQk642iyhzqVWNpkMpmCweDu3bvhsaio6Omnnx4bG0tLSxsYGEAP6L777hsYGLh+/XpXV9fExMT27dvxGnA4"
        "HBaLheO4trY2jMyMjIx0dXXdunXr8uXL8nCxxWI5f/78Dz/8gIbH8PDwn3/+OTw8/PHHH//1119xskh6vb61tRX6V6xYQTk+mJaj"
        "YiH/BW4yLceyLCcHES1NylulvFvFRCjpSWVkZHz66adDQ0Pw09tvvw32X05OTmNj47vvvosnv2TJErvdDiwP1uSuXbtycnISEhLS"
        "0tLeeOMNjPBpNBq73Z6fnx8Oh5955hlq6sTERIvFUldXd+3aNehMSEhYvny51Wr1+/1PPPGEYgADbcSOjg4ylCiKIlAKGeaOde1R"
        "9Q2QTSMTp/gKJ4cbr0cqlC5nEvnEeBkAObIs++abb8JPeXl527dvd7vdBoPBarU2NDSUlpYeOXKkv78fYhEjIyMnTpxYvXr15s2b"
        "zWaz2WxmWdZqtU5OTpaWlh48eHBoaAgi2mfOnKmoqDh//rx821arVZKkioqKhoaGmzdvRiIRv9//3XffrVy5sqenJ07KQqfTsSyL"
        "xMIwzG+//eZyuVJTU0nbQbF8hbTQ4SaLRqPyVxYgWrFihby0A0LY4IDEWiWEq/7++2/yDCwWS3Z2Nn7K7/ffvn2bMmYKCgpYlg2F"
        "Qi6Xa2ZmhtRTnudTUlIyMzO1Wi2uVRTF8fFxt9uNYQaWZZOSkubm5sgvZ2RkZGdnw17cbrfL5SKLlnQ6HWWPWywWjEBgDqusrAxJ"
        "bNu2bcePH7fZbFSZFJUtQUDABETyobKmOCxmhRAckTzSQiWDCgsL5+fnsWIiOTmZ1NaUlJTCwsJwOIyLTkpKgsEajSYvLw/OFaBR"
        "q9XglJJrBSXNzs7OysoKhUKQLUpMTOR5HqLquFtM30C0xGQyzc/PRyIRnufB+QyHw2hTchwHZjvsNBAI8DwfCATQghQE4dSpUwaD"
        "gXJwFEWQJG55CRgdNYE5SEZTq9VAKXEyjQCEPA1NFd+QKTowfmN9E46ZcoBjVVEpOhqKKRQspMF7Xr6GwcHBQCAgCEJeXl5nZycI"
        "/tmzZ9etW1dUVASJvVh5MRQ1ylWMtdN/8pxU1UesWhkyzQr3J/VpeUDmv8gIWYmouL1YEflY+QEqyIz2GZWlhPiz3+9va2srLi62"
        "WCwJCQnQ/9577+n1eniMtXKMH8hd0DjZbRVpbkuSBJesvEjsXzF1pVy+3FIkSybjFEtiLVmcZEgs0Zb7BIolXWQWhlIdn8+XkpKy"
        "atUqcE3Re2hvb4eIWxzihigbGHVkQJCqUKRKxlQUuFSBABW3QnKgBFyuBPKaizhVCWQ9FKaQ7lj+oBjqiVWOIq+4g3/m5+dtNpvD"
        "4cjLy4O6rf3797e2tkKYNw6tAdzyHFscsQBLRkV1kTqoWBSJJSVyG5EqnKSqUGKRCSWYipEyxfqQOIhT1lccNQcnFgMJYCbabDa8"
        "4eNES+6Y9aX4DdBWUQFfslJU8U2yPiTWmshTiVV8Qxp/ioKMZYjyC1mesZVzt1y9FHFPTk5eunQpWEFgvELRmmJhKRWqjV+/RtVJ"
        "g8EtCML/AOR9K5mBz9H/AAAAAElFTkSuQmCC"
    ),
    "Retry.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAHUAAAAnCAIAAAC+IJAXAAATjUlEQVR42qVbaUxUV/u/986dfYBhFhaHTTZBLaCAQioUlxJpNamh"
        "xsZGU1trqza2lpr4RUlc+FDbGrSttrYmJtioiEnXiNRabcSiKLWgWHEsy7AMDLNvd2buzPvh8T0e770DvP//+TSce9bnPOf3/J7n"
        "PJBlZWU0TZMkSRAEQRDhcJhl2XA4TP63UBQViURQAyiRSIQgCLwS1UBjfhcoqBLaR/5bCIKgKIqmadQSlgFdUOEMzp8L1fBnjLby"
        "aIUzDmd3M+xCg3BhvnA4HA6HI5EIRVFoS2g1aEsgC/5CYXSKovAG+KzRdgW90DFzhI5m56wHiRXV4wLlzAVrgC7Trifa2eA1glLm"
        "1zwjXI7mooXCyoLBoM/no2laKpWCLJAO4rojOBP/GHAVJkkS11xQXiQLvkyjqQ/nZuBTcwTKuXl4G8F7GW0WwZuBy4FGqwfl5dxH"
        "1DkYDFosFr/fHwwGk5OT1Wo1rj6Cl4gzNy56XEPhEiEUgmOeVrjTQpDgXeZ04UiWrzEcUEKVoIX880Y/UIMnty8UCrEsC2hLPlug"
        "tdvtJgji2LFjmZmZXq8XXyhf2TnqwN88LmKxWIzAJBKJwDELCncmysU5RdAYNBcff/ARoDFHTGgctDZ8TISo+IDwAz5RcBlDoRBu"
        "0HDljUQiDocjFArt3r27oqKipKQkHA57PB632+3xeLxer8/nC4VCHMXhiIOzbfSDA/T8O4Ra4r85colEKfwzQBLHh+KMgItP8Lbh"
        "EuerC6exKDU1lWVZCisc4brdboZhVq1a9eabb2o0GpfL1d3d7fF4wI6xLMswjMvlcrlcoVBIcBDcBOGLE4lEIpEI/8SyLLJpglg5"
        "LewKXn++pnOEPoVB41vpmSzjqX0D1RNsEYlEAoGAzWarrKx8++23ExMTCYIoLi7etGkTRVEJCQlSqdTn842Njf3zzz89PT3j4+NW"
        "q1Uul8tkMqlUyt8thxggbgCVoVAoHA7DseHSAbgQhAJBMUWT3RSywC1ttMZI8aPREmH+gNqhjaF1syw7Pj6ekZGxefPmvLw8+JqT"
        "k5OTk8Of2+Px3Lp168KFC21tbU6nMyEhQSKRCNo0WA1oLkzEMIzT6cQV8IlxoCiJRCKVSkUiEd+4RbPgghwjGvGYQq9nzhkEL8GT"
        "pZaVlSHGiq8gFArZ7XaWZY8cOVJZWSmXy6e9F8FgkGGYW7duffXVV7/99ltKSopSqYTBOegGhAGWwjDMzZs3p9gYSZJxcXFJSUka"
        "jSbaVmd4eaeV10zGwYkTshZR+S+6pJzT8Pl8brd7z549xcXFMpkM7+Pz+axW68TERDAYlEqlarVaq9UqlUqJRCKRSBYtWpSQkJCZ"
        "mdnU1MSybExMDNADwFzcZYCJQHMFb184HLZYLH/99dfZs2ebmpomJyczMzNBlzmeW7TLi2+qv7/f5XIhRpiamqpUKvk8ksPVBEWP"
        "qOQUeg0j04IcNhKJMAwjlUrj4uLcbrdSqcT112azffPNN9euXQsEAlKpVKfTZWZmlpSULFq0SK/Xq1Sq3Nzcbdu2RSKRlpaWSCSi"
        "UqlwPw00F5lpsGmCBVC+urq6urp6x44dq1evNhqNOTk5HPeET2A5ZIMgCKfTOTY2Vl9fD3+2tbX19vbCUIKYi6MqZ6gp2CffwRGl"
        "paVFg3Obzdbd3T00NITEIZFIKIpyOBxtbW2//vorTdNOp3NgYOD27dvt7e1mszkxMVGlUimVSpVKNW/evHv37v3777+I4eIoj2ya"
        "3++3Wq1o54ODgw8ePBgeHh4eHna5XBqNBrokJSUtX778888/l0gkcrmcD3xTI6nP55ucnLxy5UpVVVVVVVVvb++tW7f0ev3/hAzR"
        "lD2aMSBJkuavD0aRy+Wpqalut7ulpaWlpSU/P3/FihWrV682GAwKhWLBggVNTU1KpZKmadBBj8fT1NT0999/19XVrVixQiqVGgyG"
        "HTt2mM1mo9Go0+koioKrjQuXv6yjR49++umn6M+EhITGxsZ169YRBFFQUPDWW2+dPn1arVZzvABwLEmSlEqlUqmUY+gCgYDVauVM"
        "5HK5bDabSCSKiYkJBAJerxdBh0qlCoVCwOthgwgK4HRxp45hGJ/Ph0SnUqlEIhESKc3fIRoL5lapVMFgcGho6Isvvvjyyy+XLFlS"
        "U1MjFoslEglsCbRSqVRmZGQ8evTok08+kclky5cvJwiiqKiopqbm8OHDgUAAIQwIF8U6+GqiUqmAogSDwfHx8Y0bNxYXF2dnZxME"
        "sW7dumPHjoVCIdgDwzCjo6M2mw0HGZlMlpiYqNfrQfEZhunu7hbUzb6+PoIgdDrd5OSkINqKxeJgMMjplZ2dHR8fD78Zhunp6cH7"
        "xsTEzJkz52m0K8wrHCJFkqRYLI6Li9Pr9XFxcZ2dnQ0NDQcPHgSvBIcqmqa1Wm1/f39jY+PQ0BDLslKptLKyMisrC7QDUQgUe4x2"
        "DcH1kMvlaWlpJEl+//338KmgoAB2RRCEw+G4f/++wWD4+uuvjUYjwzAej6ezs7Ours5ut/f29gYCgXA4DN488gyhHDp0CGrq6+td"
        "Lhfu+9bV1eXm5v78888+nw8mqqioQF9fe+01i8WCjIfVas3IyEBfP/roIwiePHVQcebEkTL6gaioQqGIiYmhaZplWb1eDzYU707T"
        "tFwuf/DgwcWLFwOBAEmS6enpy5YtczgcIFMQLlrE1IYCBpdIJBMTE1ATGxsLem232/v6+nbv3n379u1NmzbNnj1bLBbL5fKFCxfu"
        "37+/p6cnNzf34cOHUxjPaEWr1V67dm3lypXgIhEEcf369dHRUfhdU1MDhAeKw+GoqalBfZubmxF2PZEvEiXHBeCENlChaVqhUKjV"
        "amAFnBgHIBTLss3NzaA4Go2mvLwcKSwKj00b/UOzMwwza9YsqLfb7aDgAwMDO3fu3L9/P9yhQCBw9+5do9EIzQwGQ2tra2xs7MjI"
        "CEzR0dHR0dGBxjeZTFBjMpk4GLVly5aEhAS73d7V1TU4OAjTtbS0wNeVK1cCG0FWB8m3o6NjYGAA5PuM/iLNwrWYI2uOnuLBeE5L"
        "kUgkFou7u7vNZnMoFBKLxXq9PiEhIRgMQpQOXS5OwAW3PHa73W63W61Wo9EolUrXrl0Lnzo7O0mSdDqdycnJBw8ehMrW1taMjIwF"
        "Cxbk5ORUVVVZLBZA1f3791ssFnDWy8vLy8vL0RSNjY1Qc/LkSUQfoWg0mqNHj86aNau4uDgjI4MkyZiYmObmZviq1+sXLlzodDoB"
        "oKRS6dKlS+HTuXPnIDaAC4QSJBnTxuKQ38LpgqJikUikt7fX7/cjg8MwDEQYpvB2UDEajUajcXJysrS09PLly8nJyVB/6tSp2NhY"
        "u92+efNm8HpGR0dfffVVi8WSkpKSlJR07dq1999/Hxq//vrrMpnM7XbPmzcvPT2dM4VMJps/f35BQQFgDipdXV0ffPCBRqOZP39+"
        "Xl7e3LlztVotDhEvvfSS0+kkSdLhcLzwwgsKhQLqz58/j+ze0zALh6VPHd8TDKkIRj8pipqcnAT4A0gB2J3WQ0WWJxwOA9EuLS2F"
        "T5cuXTpz5kx8fLzf76+urobKM2fOeDyeUChkMpnGxsYIgvjxxx+RBBcvXgwwhTgT/jIGxJxT/9NPP4nF4sTERAB0iUQSGxtLURQO"
        "EX6/3+fzOZ1OgAuCIG7cuDE0NITk+9Sf4kuHE+icOlrKLwhe8aXjbGQm+ssvp0+frq2t1Wq1YHaAAxEEsXPnTo5lhssLZfbs2fwA"
        "4dTF6XRKJBJ+AARBxOLFi3U63djYWCgUQuB79uxZhUIBa3smTMg3KRDc8fv9ED4PBoOIReB2jNMRbQ+9qYAKgLl3u9142IF/ZnzL"
        "09HRgaD5zz//3LBhg1gsNhgMQEg5lzpaiY2NhacD4v9RIpGIWq1GEEGSZHV1tdVqzcrKys3NhQYtLS0c5QW3gOaTapZlnU6n1+tV"
        "KpVer1csFqvVaolEgmMrJ5iNgwxFUWDl8vPzwZXy+Xzj4+PoMuLxJ76IGxsbkf927Nixd955hyCIsrKy5cuX37x5E72EulwuEPHw"
        "8LDJZIomGrPZPO1FiSZ9PH6EIOK9994Dlvbdd98h5W1vbx8eHp4/fz4HP0UiEc2PZYBk6+rq1q5d++DBg7q6uomJCY1Gg79sc14D"
        "kZiAGgcCgdLSUp1OR9N0MBg0m81msxk8Bf5bA397MpksKytrbGxs3759GzZsAAPS0NBQVlbmdrvhDj5+/LioqIggiF9++QXOIFrh"
        "W7aZFH5iglqtbm5uBvmuXLmSoihBcODE0ylOwAlCIXPmzHnxxRcTEhIWLVpUW1srkUh8Pl80WMBtGhyPWCxev349OMQTExNXr16F"
        "wJBgBEQgZkrTYrF41qxZExMThw8fhsrS0tI1a9aMjIyIxWKpVHr58mWor62tjY+Pj4mJyc7OzsnJ0el0IpFoy5Ytr7zySlFREbAl"
        "jvOGlCMQCMzcAQGIGBkZAR+kqqoKmBmAA8SmcVV7EjngvBgCAsCbG0VRCoWitra2pKTE4/GAu8lnGiglhaIoiLOUl5dXVFQA+Pb1"
        "9V29ejUmJobzpMZ5HuYXkUiUmJh46NChyclJqDlw4ADDMA6HQ61WnzhxAgyXRqP54YcftFrto0eP+vr6/H5/Y2Pj8ePHL1y40NnZ"
        "qdfrwd4Cqng8HhiqoqLC5/Pdu3evu7sbSCRffzmLBIg4f/484jlAEP/444/R0VEcfNHrDJefQZHL5f39/b///jvDMJFIJCsra9Om"
        "TampqS6XC4mYg5sAyn6/3+12P/fcc9u3b09KSqIoym63X7lyxWQyKRQKwTylqcFRp9P5/f4DBw7An3l5eRs3bhwdHdXr9Y8fP0b+"
        "xfPPP280Gu/du3fnzh2z2bxt2zaoP378uMlkUqvVFEXJZDKSJK9fvw6fIJTc1dW1ZMkSFHSfOm2Hoii1Wo3ku2DBAuRWwNsCJwvg"
        "ibLyrzy8Wp45c8ZoNLIsS9N0ZWVlQ0NDSkqKw+GAqB16oEMOiNfrnZycLCws3LVrV0lJCXy9c+fOpUuX4L5Hy3CZGv6SkpKOHz8+"
        "MDAA9fX19ZFIxOVypaam7tu3r6GhAY2Zn59fVFSEonSnT5/+8MMPDQYDTE3TtFqt3rVrF2Jv6enphYWFVVVVgvorGO2Nj49vb28H"
        "iEARkpaWFsi2QfTpmfgDP1xPUZRKpTKZTA0NDTabLRwOy2Sy8vLypqam9evXUxQ1MjIyMTFhtVpdLpfT6bRYLACL27dvb2xsLCsr"
        "I0mSZdnh4eHPPvtscHBQkEvx743gDiG+vmfPHqhJS0vbunWr2WxWq9Wpqal79+4tKSk5efKk0WgMBoMsyw4NDZ09e3bFihUbNmzQ"
        "6XRarRZpX3p6+sOHD0tKSk6dOjU8PAxMWaFQ8COQ0VIsVCoVDhEEQVy9etVsNsfHxyPk5ASnSIj48Z/EGYbxer1r1qzZuXNnWloa"
        "RVGhUGhiYmJoaKizs7Ozs9NkMjEMo1Ao0tPTi4uLS0pKDAZDfHy8RCIJBAKjo6P19fVXrlxRKBRwN6MJMRgM3r9/H19cYmIiCugA"
        "FXv06BHeRS6X5+fnQ2x7bGzMbrfj5kskEsXGxiYlJcEDNjLlJEkGg8GRkRGr1YqbNa1Wa7VaOQtISUkRhK/+/v7i4uLW1lb4c+vW"
        "rU1NTdnZ2fyELmC6z8iXI36fzxcMBletWvXGG2/k5+crlUq49W6322azud3uUCgkkUhUKpVarUZKCmHZEydOtLW1KZVKmUzGZw6c"
        "2weZg4jhwUR4M7/fD6FYqFEqlfynEEAtmqbB7OB5QByCBKYiGAyKRCKpVApBdDB9cBj4gyEKrXg8HpFI1N/fv2PHjo8//hhEYTAY"
        "IOqN+nLSaKLKF07A4/H4fL6FCxe+++678+bN0+l0MpmM78ujFAiLxdLR0fHtt9/evXtXp9MhWib4HMvPXp26Da4aeOAJ7DXusEAu"
        "HYeuzMSi4qQeN1OPHz/2eDwsy6alpd24cQPiTRcvXnz55Zfz8vKAnOAOKmIBZGFhIf7Wzc8bYxjGZrOJxeJly5atW7eusLAQYAjl"
        "S0BI1+v1tre3nzt37saNG6FQSKPRSKVSTp6h4OP5FNm4/L6oPT9HGDVGbBcdLV9/Z5JHjSpZlu3p6WltbZ07d65er0fRiaVLl3Z1"
        "daWmpoLm4inPT1NAQX+ntuYsy0I4IhQKJScnFxYWzpkzBzJ0/H4/5Ed1dXVZrVaxWKxSqQAT+MnlgueHpz8JpqHjUuZn5wkKF893"
        "R/kS/GxUfmYUP0sI8hHsdrvFYgEqAuXgwYN79+7Nzs4GlMezc/D4LVlQUCDo+PITPQHjELShYAIi8GKxmKZpeDrju93R0j6mTa7h"
        "tMeVF9F4TkIq33mZOmt26qjpyMhIWlra+fPn09LSAoFAV1fXkSNHmpubU1JSwG9CwuWkURMEQRYWFkZL8uZEeME0A/fivM6BTPH7"
        "KJjTGC0XkZ/YPEXEmf+vAwjyBHNb/6dDFZSyx+MZHBzEKYdCoUhKSgJDyklHepL2i/6toaioKJpV4QsXZwIAu/wwDQc0+ZdRMJU8"
        "Wt5jtMXAejiJvYgk/R+S0qb9zwN4fyFJEo+lIPIngAwk+Ux+ieDpITONMvLQQPgzJUePZpInKhj85Ss+Gg1/q+YYk2jpa4KpM4KT"
        "zsTZQZkrnFwp/OARcqL6/wAuHqk+hsdbtwAAAABJRU5ErkJggg=="
    ),
    "RaidSuccessful.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAmwAAAA+CAIAAAAZLtCnAABMkElEQVR42u29d5wT1fo4PEkmvWd3k+1shaVJEZAuKLCogFLtBVGw"
        "4BWvnWtBpalX7BcVUa9dBKQIggX4AkoTQTq7C9mSZNN7r+8fj46zM5PJpOyC9/2dj3/g7OQ5Z855ztMLq1+/fiwWC0kyEokEksUg"
        "Q6YHSLOSCzvwCyN/AuWysdfwf8X+TbkPzLeL4UZRroH+lDsPGVIChKlTfnI2y6A/uwwgk3c4h7vEENPSvVz0O5zZ+unxubMxJ637"
        "yPyCYw8pP4T+gjOcOuVFTpeEpgstrV8xPOVOJePk3U55KJ3HAuAhSrM12aM+gTpf/ByUsAZYMP3Ckv015a/Iu5FIJJhzx5RvEnAr"
        "2fuEZcCbOad6TCgL/aQ5WRgBAmFPMoCP/aQz9i0tgCnfTLnCjBef8oddvDNkbM+A8hCIJnnGZPyS/Jwe69K66V3PQZnjNrzTlWSc"
        "TLu6jE3gvxRN9tkMF8SEzdATTfht5209pXzNcLqUtyvnC0trP1PyRbyQmCU5ZkhBuuDOZCmbpyUSMdGVsYcMrQtpLTstZpAS0zpP"
        "I0ypxWav5pIlHhqA6SrxOcTtZHw0S5qQmamJCbaTGXy6Am42tJH5GrIR4zpV3UKzRLh0jV0X6lPxkhRzMpoTuY9+XnoRr2uUwosE"
        "Ly/CQYk2zA/lIjSu5PC2UtKNzuPTXazlZHDBmRuKKH/bqRbItP7aZWTnYlhD9gPNWGhiwhiSeQvIOmhmCJQW+6eUZLuACGbg9sjJ"
        "Ggibn3OMzIkI2anaT875KI14wdDcl/PFXECme8EH863oVP6UwaHkSiCgsaAypyrZIFWWX0FefGdTra5golluCsEVn0y2Jf8vk6CS"
        "bFhm9lamLiPZ9JQaYeaCSpf+kjlTuhZvGt6WK+WenoZ2nlCfEjlzYstJGbyGiZ6dpALS0OJkW01jbsGsx9m44pBMXRL038Vc3GFo"
        "m6X0eubcA80w+imDDckyOIgh+iULBEFozdEZeD1ysmzmMFE2m50WaciYk9HE7DDEAybOsMzwg4Z15VbIyJWhg7kxLQNzcbqBD/R7"
        "mH3wTsoZkSThURfqmLLkoCmJcgYkO4dfl4HVN4MNydW3MCEa9HEhhL+mRe5zeChMMOQCKuUM40azid3rymWntUtoWh7pHAbaJLPl"
        "ppWEkNZ6UrJDmtuegS6Vbnw/k5CWlEtN94CSyRO5Qtzc3lgaoTWbAMjOs0dlbItjLv0wN391nnGMYRx49riUAf3NLQ5nEHLfqQLc"
        "3zFwIRs+enH6GtB0LaLZW1CZS1gpzSbpTp1urFrKNXSeY7WTHKX00gwTfTfliaSMdE83ljvlbtNEb2ag2WTg38qVAppsb5njfGbX"
        "h+FWMIwazTi2MyUWpbV+hlHcuY2iyAkidSrJzf5u5upw05q0U9M3spRFOphzc6t8pLVNeJKdTVBZNhvHPM8py2isLIV9hNbvSPMw"
        "rU/D/yS3GgA9YhAslilPhPmRMfmKzJJr02XwzFeVwf5nk8NDg0s5KSuR1m9zm2CWZaZANsmdKbGC5pQ7g7B0klaXVu5ZF+iUOY93"
        "SbZvKB6tOyMco7OtLhmL/zl0LNHf9lyJJgxDCbIkPWlZuXP4LZSmG4YFBBjyZiZXJV0zA0PCnbHZ9n/MLvc3/eouK8HzPzb+vgbn"
        "tO4y2mUVajrJLJDZRJR5Cxc5NndNQRDC5mQcdJfNt+AjhOnjNdJN/6XfQObMO1dEJF3luAvIXDInazL7apaa5cVP0DOIU80sq62L"
        "6XBuiQk9qHg8Hg6Ho9EogiAcDofH46EoerExFJr9pweFIl2VVp9B6RaGsTb0rzmdTpfLFY1GURSVy+UKhQKhLcqTQUB8p9aUYG7o"
        "prdOZFBbKi3/E0PTDRN9mmzsoq/VhzCOR0srWofmRjHJCu08L2xObGsMgzUo0a9ryqXmPE6KPu8uGw6a0riCMLPWprwLncFm0vK1"
        "paW3xWIxh8PhcrkCgQDhCnO5XIlEUlRUxOFwulIOI1TvYuL2TrmwDMWBWCxmNpt9Ph+TRbPZbC6Xy+fzxWKxWCzOiWhDQ4IxhI5E"
        "IufOnfN4PNgumM1mqVRaXV3N5XIzu8wsFstsNrtcLsI7YrFYrVZnL14Fg0Gv1xsMBsPhcDweZ7FYILgJhUKJRJLxsjMo+5IrOS6D"
        "0HwmR59WbAJDnwXB5EtDO3IixV9A80+6zotkTILFYoXDYb/fHwwGo9EoYCx230UiUcY3gkkGQpaqG/O6QtkvFcnOU3Ax2MmY7za8"
        "5vF49Hp9JBJRyXgTxpbXVSqUMn40lnB6Qs16z9EztsZWWyKRKCsrQ9KpMptyH+LxuNVq9fv9hMVLJJL8/Px0ATJZGJrunYcpzWaz"
        "Xq9PN1KOxWKhKJqXl1dQUMDn85OtlYnvKqXlLZFINDY2er1eQnCE2+1ubGysq6ujzK5JiShOp7O5uZn8jsPhQBCkqKgIYVAAk3xs"
        "0WjUbDbbbLZgMEgOyMSWCniQn5+fWbHizjZ/dU3Vnmy+jkzIKBGPuTkupaqUTWGz7PvVJFtnNoGj8FGxWMxutzudzlAolMwSwGKx"
        "hEKhQqFQKBS5DW29qJwvGSyma35yAW+cx+NpbW0VC9nP3jNo2rhKoQDlsP9YfiKBxOKJSDQ+YMZaQJ6cmDOxYbVajUYjebUul4vH"
        "48lkspx/MprZdfJ6vfF4PIPVxGIxo9FosVgKCws1Gk1m6jOTWBKbzeb1ehEEufvuu++5557S0lK9Xr9q1ap33nnH6/Xa7fa8vLx0"
        "iQuLxUr24YlEAqZDGDReIJAkk8lkNBojkUiymizYQ7fb7fV6jUZjWVkZ2KU7VcXJIEskG7GOIZnIbXu+DCyTDA3sTPyvadnZmJe/"
        "yaasK5PlWa1Wq9UajUZpqgjBc5/P5/f7bTabRqORSqU55BYp2yQwB8I8BjtdU2cGO5wuRlF+clq1eBimkDH/kGAwqNPpCpS8j5de"
        "0aNSLuRTqGq/n7V5/dH8fEXOW3v5/f5kJNrv92NImE1XBgLaZKiJwr/tdjtDE6XFYjl79uzBgwe3bNly+vTpeDxuMBh8Pl+3bt0w"
        "mzhz2sekMojb7U4kEk888cRjjz0GTyoqKpYsWSKXy5cvX+52u1UqFcKsigK58Nju3bv79OmDf0elUsFfmfRhwABGo1GtVutyuWKx"
        "GIIgarV60qRJI0eO7NWrV1FRkUQiicfjHo9Hp9MdP3589+7dW7du9Xg8fr+/qalJo9GAJeQitOdkfBW7Utxm6CFLaabLrD0npqem"
        "xRqZNNih+ahkRg7mJxWLxXQ6nc/n+wNjVcJrRpePGFDYs1pZXCASC7nxRMLji+hMvhON9j2H27/b2+rxRYLBYFtbW15enkajYYIk"
        "mdXNyDhUMBusyznGMvQ40HxyxrV4cvUtJpMpFou89vjoPrVKlENdEe+Xo8ZEIiGRSLLhoDTE1rLndvzDk032MbM357akFLZdaLrh"
        "DxlstEAgKCsrKysrGzdu3MKFC/fs2fPss88ePXrU6XQmEonKysqcuJcIQEAYmTdvHuHNefPmLV++PB6PZ5YSTk/y0gruisViTU1N"
        "Ho8nHo9XVVUtXLjw2muvJYgUHA4HrGF9+vS58cYbA4HARx999Morr9jtdqPRGI/Hy8vL05WBLogr7m/dE6ZT6U6WqVBpLYBh1hAN"
        "B21tbfX5fIlEorJU+uRdA6aMreCwO8zOYbEUUp5CyutTo7zhqupAKPrxxoZXPj7mcIVsNls8HgeXR9fgw8Vg9WWYW8X8Jwwzpy/U"
        "jQuHw263++pR5SMGFCbjoAiC7P3NyGKxmIfIXJx0CbYapdR86e1IWU48atSoH374YdGiRW+//bbL5TKZTCnlU4bWM/z/CoVCJHmk"
        "nFAohCAIJgiXVlwrkya68LClpQXU5blz5z733HMEJzHlEAqF995778yZM+fOnbtr1y6z2SwQCMjechpJ7YLUxmNO5rqyTWmuSvim"
        "ZUGhsZiRc0voTc3pmnwRUlptuub69vZ24KB3Te/53P2X8ripbUhCPjpvVq/p46vufWHPrkMGh8MhEAhoPBHZ5J5dtFmJOTT2MmST"
        "aXUsz63YAQ6v666o4PM6oMfxRvvrnxw/r3NzUXZFifTgcbNIJGJohuyMK5wrVEkkEihBf6KXgHK1Ag6H88ILL3A4nDfeeMNkMsnl"
        "ch6Px5AMMZxCoVCYzeZ333330UcfxT9/7733eDyeQqFgkshBtmAztEmmZMMul8vhcCQSiUWLFv3jH/9Ia/fy8/PXrFkze/bsLVu2"
        "GAwGqVRKjtqlZ59I7nqPZKbMkTf2gnT57qQ7xtDnlEFuSUr2mVKDobf00uyDx+NxuVyJROKZey994KY+6WGsUvDFy1fOefr/tu5p"
        "NZvNEomEJmqXvLAM6m1l8FuabyfLedljZs5b3NCcI5PK25Sh6RmMQCCAIMiAnh0k+3gisfC1g8ebHAgLRRCkocUdDMfLyzVdv29M"
        "8CfdwyVqogxzJSmH0+n87rvv8E/YbLZYLK6oqOjVqxe5Xcwzzzyzf//+gwcP2my2wsLC3G4HiqJlZWWvvfaa3W6/++67y8rKDAbD"
        "e++999FHH5WVlaEoStYak31ysrI45PdBu2UCx2g0xmKxW2+9lZKDGgyGEydOOJ1OLpdbXl7et29fgpCBouh77703ZsyYxsZGu92u"
        "VqsZ3jGGFynnlk9KYzKB7mdc7fZiU1LpNaQMOh+kLPpIZrqZmW1pVmK1WuPx+C2Taik5qMHiP9lkd3rCXA67rEjctzaPx+1w31EO"
        "+51nRl1517eNLS6XywVhfV1mm+3UqlsXHMGy35AcrgcqKhTmC/EPjdbAb6ctIrEMKBUwHTAWXiQHmg1jRnO4xTqd7v7775dIJPgw"
        "vFgsFg6H+Xz+nDlzFixYgJdA2Wz24sWLJ0yY4HQ6kzHRbHYqFotxudx333333XffxR4WFBSIRCL6w4hGo36/PxQKAUKgKMrlcsVi"
        "cVppmpRbB9MFAgG/35+Xl7d48WLC+/v27Vu0aNHp06fB1hGPxyFq99Zbb33sscfwKxcKhUuWLJk1a5bD4SAz0ZTGA5ooFYZHn67u"
        "SJm3moFuhOSi30CnmrWzicvN8n0msRiUAlayhBx4HgwG/X6/Ss5/fv5gwgv7fzc9985vp7U+gUAAGBuNRlnx0C2Tqh+Z3U8k+Ou+"
        "CwXoC/MH3/Doj06nMwMm2nmVTOj3qjNaQeTc8kwDkEkqdvYNH4PBoNvtjsfjkKTA7Wjqd3nC4Ugc8fuxDHs+n0/PROkD/TqppHBm"
        "YFEkHecKk2lEIhH+hoB+FolEXn/99V9//fWLL77AQxg0aFCfPn1OnjwZCoXITkFMuIZA+UgkAlH1HA6Hy+WKRCKxWJzMLuT3+41G"
        "I3BB/HC73SKRSKlUUn5pKBSy2+0+nw8yx0FiYrPZkOEqFovJADMQ9sFtcNtttxGC/rdu3TpnzhyNRlNaWoqiKJvNxnbvk08+2b17"
        "97fffovno+PGjSsvL9fpdNFolMPhxGIxq9WKr4ABGyiVSimzjK1WK74SBXZ8BQUF4KuAtGVwg+FFH7lcLpPJOBxOMBj0+XyBQAC2"
        "BTsUHo9HwJNIJOL1euEQE4kEiqICgUAqlQoEAjIViMViFovF7/dTzouiaCAQAJSAeXk8nkgkkkgkhHkTiUQ4HIZ5w+FwIpHgcrkw"
        "L/4CpzTRe71er9eLRz8ofyGVSpOhXyKRgIIkWOIT9plyubygoCAej7tcLq/XC1U1YOej0Wg4HCaA4vP5RUVF5IngS30+n9lshlhZ"
        "/J9kMhn+0D0ej9PpjEQiXC5XoVBAVCRBbSUX+cPfpkQicevk7lJxBznyu71tdz3zfwXqwuLiYg6Hw2KxIGQvEol8vKVt9+H2TW9N"
        "xPPRK4eWlBVK9GZ/LBZjs9nxeNxut4MBED8kEgmEuxPokt1uJ+wnSJN5eXnJ+iJj6BcIBKAiRCwWg+sM5SAwDKQn5fiMiEgkQqgv"
        "gaIoj8cTi8X00CghRyIRn8+HQWOz2bC2DIqrwC0LhUKRSAQr1YLdSiato8mrAlDIn+X6hEIhGVQikTAYDJDjDleSwCQAQjgcttls"
        "8AQojFKppKyNgCCITCajlLRsNpvb7SYznYKCAnocYCK+ZCDQI50RnQtIQEkIfvjhh88///zmm2/G/6m+vv7EiRPBYJDARFksVigU"
        "MplMTqczWU4q1B9Qq9XkFFrAAPJPQqGQx+PBM1Hs6+x2u91uxxRQ8g9DoVDGAfcEqQ1BkPHjxxPw7JFHHoHkdMzfDtPx+XwURY8f"
        "P/7KK688/fTT+F+NGjXqs88+AyZqsVja29spzexcLpewRW63u62tjfwyiIoQ6mWxWCAGmAxQrVYHAgHKrFkURRUKRX5+PhCUQCBg"
        "sViwNB6ytR8yCPHbZTabKed1OBwajcbv9yebV6lUqtVqYJCBQMBoNDqdTsp5oeSYVCqlOdBQKGQwGOx2Ow36SaXSwsJCuVxO/qvJ"
        "ZNLr9eTnDofDbrdjEgB+V2l4QFVVFfl5PB5vbGykRFeHwwFVruLx+Pnz5/HAzWazUqmsrKwEKQ1JVQIQbiKCIOOHlXacPfHYK/uF"
        "IolCocDoF8CB4qjHG8+t+O+xp+YN7ICxlxZ+vqUpGo3yeDybzWY2m8kzut1uFEUJIqbH4zEYDJQvg4WJcus8Hg8ljcYGj8fLy8tT"
        "KpU0JBjbFrfbzQSaSqViQtA9Ho/FYqGp+wZhg0xKVbhcLpA7aciyQqEoKCigZPOEcA2z2ZwWKBBVp15ZMW1cJeVPyoukny6/Av/k"
        "lid2eL1epVIJRIbyi9KlWoWFhZ1a6zs9c25nGFXEYjGfz//qq68ITLRv375AJgjv6/V6q9WaSCSGDBkyadKkQYMGVVVVKZVKFEVd"
        "Lldzc/OxY8d+/PHH7du3nzt3TiqVVlRU4Jk3UBbKhE4yVYWKBw6HIxQKcTicq6++eurUqYMGDYLSjna7/cSJE+vWrVuzZg15nRls"
        "DqytZ8+e+Ifnzp0zGo0qlQofsYaJLKA/rVu3jsBEy8rKoNAaqAsIKXn3xIkTo0eP9vv9BHSElyn3B7s/oH/o9Xq83vbFF18sXbpU"
        "r9eLRKIpU6Zce+21AwcO1Gg08Xhcr9fv379/7dq1Bw4c8Pv9oG+ZTCYulztixIjp06dfdtllZWVlXC7XZrOdOHHi22+/XbdunVar"
        "VavV+AjtbOb1+XzwsL29nX7epqamwsLCwsJCSidlW1ubxWJhgn4NDQ0ymayqqgpFO3TnBeJIeRxut7usrGzevHkTJkzo1q0bKByQ"
        "uEw+kUmTJu3fvx90FDL/iEajixcvvu+++/DP//3vfy9duhR4P3DQadOmPf744zU1NU1NTcuWLduwYQOCINXV1cksTIQncGXqqhT4"
        "d87r3EarH/aErMICxq7/UUtgomWFEsBY8GsgSVL6AoEAMFFsJfDyrg8n965R4d8vGPVfsi4LlF2n0/n9fqEAnT6+cvyw0r7d80o1"
        "YpEADUViZlvgrNa5+3D7Nz81t7e3W63WkpISmrTFcDjc1tbGHFppaSkNtEgk0tbW5vP5+DzOtHGV44aV9uuRV6oRC/loKBwzWv0n"
        "muw7Dxo27WzW6XRms7m8vJxs/MS2Ra/X+/1+kQCdNq5yzODiS7qrSjQSsBm4POEWg+fwKeuW3S0/HzGCGJosGyIQCMCOpQsKzA81"
        "5fL6EdSZ61Ixl/wnQCoaHEhGtShxgIbrp8sU0+VxKHMDcZYRbqArHD9+nPAC5I3hhf14PK7Var1e7/Dhw5csWdKvXz/CTxQKRf/+"
        "/fv373/bbbcZjcYlS5Z8/vnnDQ0N1dXVZEMik2G1Wm02WyQSGTp06Guvvda9e/cOJ1RQMHbs2LFjx86dO/eOO+5obm7OcuvhTQJ+"
        "wCXxer1Wq1WpVJLrMhcUFJhMJgKFDYVCzGv25rA7W58+fV544YVhw4bhI56qq6urq6unTp36+eefv/322y0tLSAkLViwYMqUKXjh"
        "AK7fmDFj5s6du2DBgt9++43FYiXz7KY7r1arZT4vpnbjRZzz58+ni36nT5/u3r07kzwlBEEmT568cuVKvGUeG+vWrSMc8cSJE3/5"
        "5RePx0PWd0G/rK+vJzxfu3YtaHJut9vpdE6fPn3VqlXwp9ra2g8++ABBkA0bNng8HiD0KTNngH/LxB2i2wR8FGQFu90O5hPCbwFj"
        "L5n+TQeMDcfz8/MBY9Mq48wwjRuzcre0tLCQxN0zej5yRz+VvMO58LmcskJJWaFk3LDSp++59KONZ5evOtrc3FxUVEQwIQI0r9eb"
        "LjStVltcXExpkIS1JRLx2df1eOzO/vlKQcdd5VSUSCtKpJMu77b4gcHvfn36lf/+fu7cudLSUnxqECzM7Xa3traiHGTBrX3n39RH"
        "LiHmOKjkfJWcP6Bn/l3T634/a/vnS/uONRjD4TC5Tovb7W5packJqAs1chs9QAmW8lfsLLE2ra8C7ybZ0kvwPTQ3N3u93oceemjz"
        "5s1kEkYYhYWFb7755jvvvBOLxc6fP59BGSefz2exWCKRyM0337x582YCB8WPSy655Ntvv2VC6+kHaB4E0am0tHTEiBHhcNhsNoMa"
        "5PV68ZY6sECKRCIhbiiVSoaldFOmYzIftbW1r7766qhRoygTk0Qi0R133PHggw8WFRUNHTr0ueeemzp1KmVCGIfDqaur+/jjj/v3"
        "728ymaDQMc3xdfa8MECAywD9mpqaQCSn/4oBAwasXr2akoOy2ez169cTHk6YMAFv7MVK0oAVq7a2FlMoYRw/fryhoUGpVLJYLPgV"
        "VrQLG08++STAZHUcGHzC+ANjgx3MMKUa8fD+GsBYnU4Hdk5wxcEQi8VFRUUiaYFQki+U5AvEeQJxnkKlBhdmZ8RzYUSmublZJka/"
        "XjF+6YNDCDyPeBlR9t3Te+78cHJtN3l7ezsUwSZ4nTODZjAY8NAwXaq5uVks4Hzx8pUvPTyUwEGJ7l4BuuDWvj+smlSqEet0Oswf"
        "DAsLBoOtra1yKXfjmxP/NXcgme0RRr8eeVvfueqqkWV2u91kMhF00JaWlpyAyu3AY/uFZcw0K2Fn9mEZcNBoNBoKhch51qDOA7Fj"
        "sVgmk8nj8cyfP//pp59mvn0zZ85ctGhRMBikNK/TL9JsNofD4YkTJ77xxhspk3+Li4vfeeedLA8GlM6GhgbC89WrVw8cODAUCjmd"
        "TrPZbDAY2tra9Hq9zWbz+XzxeFwsFss6DqlUSpNi20lo/cgjj9TV1dF4fVAUra+vv++++6677roxY8bQQ8vPz1+xYgX4dLt+Xjab"
        "bTKZMM5nNBozRr9AIGAwGOiZKJvNfu6555JZDrhcbltb28GDB/EPu3fvXllZSW4c5PP5IpEIpRqKGYfB+1BTU0N4BzysZN8EgVJg"
        "7BBYfmMLMaBj1XOXD+yZj2Fse3u7TqcDRzLY5JNhbEriiOfraY1oNNrW1iYWoutfqx91aRHDX5UXSTa+UV+iFhsMBojtgqkjkUhr"
        "a2vG0PR6PT5SLBqNtrS0CPnsNSvGXTGkhCG0ukrFxjfr1SpBa2trOBzG9kSn07FZiU+XXTGodwFDUHwu5/3nx/TrkWcymfA28CxB"
        "wTcazL5fT1rgP8LLwVAM+xPlC3/rgWLWYeb22wzK44XDYahYPXgwMUS+tbUVPChgJTeZTD179nzmmWfIMBsaGs6cOROJRMrKygYN"
        "GkQgpvfcc8+nn37a0NCg0WiYePUxSuTxePLz899++23y9/p8PkhjzcvLGzx4MNi+xowZwyRGl8bsLpFIOBzO9u3bBwwYgH+uVqt/"
        "+OGHtWvXfvjhhwcPHgTUhMZSPB4PC42jVGKYW7qyHBMnToRk+UAgcPz4cYPBUFRUVFdXRzA2FhUV3XnnneD2CIVCra2tp06d4vF4"
        "vXr16tatG0EvrK6unjRp0saNG8PhcDKZoFPnDYVCPB4ve/RrbGzE0I/y9Hv16oX922QyHTlyxO12y2Qy0CZ5PF4oFFq3bt2QIUMI"
        "375y5UqfzycWizGwoGVOnDiRcMrr16/n8XjgUAQNsqmpqba2Fv9aY2Mj9lcmtxt2fvvPbf3rOtgn1SrhtnevWffD+Y82nj10wkKJ"
        "sRKJBCsfRp8ZTCmsM+x7ig2IyX/9mcv7dlcRnXDxxOGTljajV8BHB/Uu0OR18DIWqIQrnxl17QPbTCYTVk0ze2hGo5EA7a2Foy7t"
        "ReRV/mD00AmLxR6QS3kDe+XnyTtoqGWFkpVPj5r+0PfY2vx+v9/vv3Vy9yF9yTniyLEGm1bnSSCJmjI5YeU8Lvv1J4ZfMedbk8lU"
        "UVGRE1B2u53L5e49YtSZ/jA0fr2iQ9SkyR54cfVRsuko5/J9bhOHyM2LqJkoQlXPPpsKHW63G385IW8MYmJZLNbcuXMJ7//6668Q"
        "0o0gCERCPvnkkwRR/dy5c/fee++vv/6Kt+x9+umneNLAZrNnz579+OOPU3qPkg2Y8eGHHybH6/7nP/95+eWXIR8jFovBa1AbgVKT"
        "SFkACHuBy+UqlcrVq1ffe++9hKWyWKyZM2fOnDnTarXu3r177969e/fubWpqgvBIHo8nEAhAus8ABXPCR8GWsGvXrsWLFx87dgzk"
        "if79+z/55JNjx47F7wyQzjNnzrz55ptr164FvScvL++GG2548skn8evncrkTJkzYsGGDz+dLxkQ7e14ul5sT9HO5XCnRz2azPfbY"
        "Yxs3biTE/YpEonA4vGHDhqVLl+KNIvX19StXrnS5XLB4OESXy6VUKi+77DI8hH379un1eixaCup2vfjii++//z7+tWXLliEIAjjP"
        "5GrzeDylUvnBN2fuub4XwdbHYiEzJlTNmFBldQb3HG7/+Yjx5yOmplYXhrEejwfDWOY1cSD4KF2aGAwGXS5X/YiyKWMrCH/auqf1"
        "yVcPGCx/+FA4bNZtU7oveXAIF/1LGBrWTzN2SMnOgwbIBQoGg06nM3to0WgUoDkcjiuHlkwfX0Vgxq99fOyNz074g3+I5iiHdfOk"
        "2ufnD8ZnB426tGjymIpNO5vVarVAIPB4PAiC3HBVNWFhB4+bH1j683ndXzaDvrWqd54d3b3bXzjZu0Y1dkjxjgOGWCzG4XByAqq4"
        "uNgTDB47F6TsSuL1hXcdMkAjbkxhYEKl0+3AmvI1+l6NNDScpvoVynBNzJm83+/Hh7/G43HgQGw2e9GiRZdffjn+5Xg8vmXLFtDM"
        "QLgWiURDhw7Fv2M2mydNmmQymVQqFaQo+Xy+xsbGefPm7dixA//m8OHDYQEMmSj0SJFKpbfddhvhTytWrFi+fLlGo8GKHvh8vsWL"
        "F/t8PvAnZcCl8HtYUFDQ0tJy//33f/zxx5R6c35+/rRp06ZNm4YgSHt7++7du7/77rvt27e73W5IkYTC9Mx17hzy0aNHjz711FNn"
        "z55VKpVCodDv9588efKNN94QiUQjRozAv6nX6z/77LM1a9aIRCKNRhOLxVwu15o1a6RSKd5Rx+Fw+vTpA0n9TOZVKBRCoTAQCDCZ"
        "V61WQ1Jmynnp0U+pVIpEIjab7ff76dEPQsaS3Re3233NNdc0NDRIJBKFQgEiWjAYZLPZ0BzQaDTu3r177Nixf5HjYcNkMpnL5cKq"
        "t0Mr7KuvvprggPj6669BYoD/lcvlCoUC/KwQndvY2Lh06dLNmzerVCqJRMKcS6nVaq3W98CSvR8tGctmU6BQvkIw9crKqVdWIgjS"
        "bvXvOdy+bW/b97/oIB3W5/OpVCrAWCaaKNmWywRvIQ3xiTn9Cc/XbD83f8leFosNmVexWMzhcHy44Ww0lljx2DD8mzdfU7PjgN7j"
        "8ahUKibQhEJhNBp1Op0poVmtVgRBnrxrAEHVu+f53Rt+aubxeBqNBswhTqfzvxsbzja7vnl9Ar6G+4O39Nm0sxlCf0Hp713TQfT3"
        "BSI3PvqTNxDNz88Hecvn851oss986Pu9n1yHz/G9ZnT5T/v1Xq9XLpeDuJMlKC6XK5fLod1YslsM+WyY5wUSiy+sJZZhNTp6EoqS"
        "SXz2H4a1WgVvSllZ2bBhw+644w7IZiH4b4xGI1gVIH7B6XR2795dLpeXl5eXl5dXVFQ0NDSYTKaysjKMNCiVymg0evToUYPBUFxc"
        "jEEDOPRZKAS5NRKJTJkyhRA+fu7cuRdffFGlUuEjIIRCYSQSWbFixfTp02mCjxgKQQKBoLCwcOfOnbfffvvKlSvpWwIVFRVdf/31"
        "119/vcPh+Oijj9566y3IxonFYgyjinI7PvjgA51OV1xcDNl1eXl5RqPx8OHDp06dGjp0KJ6sHz9+fMeOHVKptKSkBOwTEomkra3t"
        "xx9/XLBgAaZ0slgsYA/k7CPKeTHpwWg0/vrrr8nmlUgkMC/kE9PMixWLcLlclOhXUlICXsbs0W/JkiXgdKCs0iWXy41G4/r16/FM"
        "lMvlXnHFFRs2bAiHw6Alg4uUYMuNRCKbN28WCAQCgQDTcSsrK7Va7fr16/EhS0qlslu3bmnpeUKhsLi4eNdh/eyndr391EiJiK4O"
        "QFG+aFZ99az6aqc79NHGhv98edLhckEGdn5+PkPJj1DogInt1+1296/L61PbwerYbvE/+u/9KMqtqqri8Xjw1SqVSqvVfrK5YfZ1"
        "PfBWyuH9C0ESUiqVTqeTBlp1dTVmcsvLyzt//jw9NJfLdUn3vH49OtjDP9/SuOGnZqlUWl5ejm1Lfn6+Tqfb/7vpww1n757+VyLc"
        "Jd3zarvJtXo3RkwIrToNZr/bF1YqlSUlJdhB83g8Q3v7kvd+61mlNFh8BrO/3eI7r/MgHQNIswcFF43P5ydjonw+Hx++fvG0VU+m"
        "KJJ7QiQ15zL8qpR23T59+jDsMIqJjYsWLZLL5RKJBICXlZWJRKJgMBgKhc6cOYPlw8jlcqVSGQwGw+FwJBIJhULgFSfE+kJjHcoC"
        "tpQDgIwePZpMrIE/4ekym83Oz8+3Wq3vv//+Sy+9lBn7xC8MiuDv2bNn9OjRixcvvvrqq1PCUSqVDz300B133PHoo4+uX7/eZDIB"
        "D2NOkjJrQtvBMuP1Hjt2LBaLgVqGXQ8Wi2WxWNxuN94wbrFYdDodvmIi1Cry+Xx4XxGLxcKc4snODptXKBRi8woEApp5RSIRw3mB"
        "5ZSWlgL6hcNhPPrJZDKlUgmFYJigH83uRaPRL774QiAQaDQaykKMfD5fIBBs3rz5lVdewVu2wezsdDpVKhWE3aIoOm7cODyEn376"
        "yW63FxcXE4Lyq6qqoGIR2BXlcjmWgpns7lOeAmDsz8esY2ZvfuGBwVeNTJ3boJDxF9za9/Zruz++4sA3P2mNRiPcIybUBgbD9Hk2"
        "mw0lOK4aSWwO+P660/5gtLy8HPYTm1etVjc3N7+79tSs+g6WTD6PAzWJmEDDFqDRaLRaLSW0cDgcCARisdhE0o69/eVJwBlCDQHA"
        "oi+3nsMzUQRBRg8qamw5Ew6HgTQZLP5SzV/dxKrLZL1rlCebHNB9GuInCgoKHA7H6vVn8KSMy+Xm5+eDxQ7EspyAYk5b0uWguXJ2"
        "ZpMhmoyEorldRFq0+Oabb/Z4PKWlpRhN5HA4+AQSSJoMBAKBQODYsWMEoeaOO+4ghx2mtd1/mER69yY83759u0AgIOf8AYH74Ycf"
        "cnX8INw5HI65c+fW1tbeeeed1157Lbn6EvlX77//fl1d3dKlS00mEyS9dIZcRvncYrFA+A9enwB9Hez2hB0Oh8OEL4J6b+T6dvQD"
        "5uVyudi8QDrZbHayeaEQEvYhNPPCGRHQz+fzAfoFg8ETJ07kBP1aW1u9Xm9eXh4hmg8f36dQKIxG4/fffz9p0iTsh+PHj+dwOOAH"
        "jcViHo9n5MiRhI2FuFy5XI7tBvbtEokEb+2gtznRkBKlUsnlch0Oxz0v7K8t+332dT0mj+kmS5URoZTx31s0uq5Ssez9I0ajUSwW"
        "M8FYvALKJAoJFKBLSfGlW3a3QhUtwrdDxNNX35376rtzhJ/I5EKQk1JCwwbUkqSEJleIANrgPh2gme2BxhYXWRrDxhmtk6ioVKvA"
        "hCYSiWw22+5fDTddg3fMs755vX7Ff499/f15q9UKBmQoSSiRSCA0msvlElwAYK1lDkosFoMcRgbVSRy0szXOLH+OXpDPOHXq1N13"
        "393W1qbRaMjXKZFIOBwOk8kEZmE+n9+7d++ampry8vLi4uKSkpLy8nKwzGS5DDDiEZKF/X6/Vqslxxlhqk9LS4vX66U0wCarmkZD"
        "s6DepsfjaW9vf+qppxYuXDhgwIDLL7981KhRAwcOpKmi8Mgjj5hMptWrV1ssFuatubOXgWKxGHPHavaKb07mTav3J4Z+wG5zi36Q"
        "HEwuSoXvUyaTycCii2eieXl5gwYNOnToEDjyE4kEIbnF7/d/9913IpEIs1im6xCiaTVKxlixWNzu8D6z8sRTbx3p30Mx+tLCEQML"
        "B/bMp+nD/M/bLzHZ/B98c9ZsNhMipbMnuywWC86rprxjjZtg9LzOLZPJyeEdLBarsrLS4/EQnAhQbQ5KDCaDRrkGPDRsOhRF5XI5"
        "QKsu6wBNrRISKvWkHGVFErDbg0fjrS9OzphQjW+Yo5TxX3hg8PPzB59tdh45bf3tlPXIGeupc45INO71eiE0gSB7yWSydEH5fD5K"
        "UBc/B8257zIFE81AUGUyHnnkkY8//pjL5RYXFxPKYwJjg2ILKpVq7ty5kyZNGjBgAMOKPOkeJAjshCik9vZ2iMil3i8URRDEZDKR"
        "mSh9lATNYjgcjkKhkMlkfr8/EAicPXv2+PHjr776Ko/HGzJkyBVXXDF58mRw3RHG888/v2XLFovFUlRURF+rGm8Zy6Av4993kIPr"
        "UrJqDP1uvvnmTkI/yn3GlgeF0bdv3+73+/GxxPX19QcOHPB6vRBOSWCiW7duDQQCeFsu84ZoBE9Nyt5tbDZbqVTK5fI/MLYtcPzc"
        "+dc+O8tDE4N75429rHjS6G5FBRTR44vuG7R1T5vV6SwuLs6gJxI9egP3IpQvMFr9iQQChhOCVwXceMnEZRpo2MoJ2wsXmXLTAFqB"
        "MluLEUT0xGIxFEXVanVji/GhF395c+EIQqgXi4XUVSrqKhU3Xl2DIEgwFNv3u2nTzub1P2q1Wq1MJisvL8ckOTDA5ATU35EyZK+M"
        "ojkkl263e8uWLQSr19SpUwlT8Pn8aDRK6JiGeQKampqCweDcuXOfeuop+nAbeJ8cpMA8TRsrlo1/COpvMgjwEIucylgDJmeaQm6f"
        "VCqNx+OhUCgYDAaDwcOHD0NztDFjxjz11FP4LEMEQYRC4ezZs5ctWwalnLvMFI/f54uZ6aa7qpygX06GQqEwGAxbt26dMWMG9nDi"
        "xInPP/+8x+Nxu91Q6RD/k6+//hpaxKRsr02pfFMiCfbXWCwWjUYJ+wn9AcETjGHsbw2B/SdOP7/y98sHqRfOHdCrqgNaCgXoHdd2"
        "X776KEOMTff4EAThoR0IejAcAz5BuNF4AwDlRv1BHKig0eQB069NwM+W2fBxmqJarfb7/Wu2n9OZvC89PLRHhSLZrwR8ztghxWOH"
        "FD91z8AX3vnts28bm5qaampqMOaXJaja2tp0+ShzbzdyEbRfpactuRSxW1tb77//fg6HAxZaqL8VDodvuOEG/GsPP/zwJ5984vV6"
        "g8EgoaUA9NNZtGgRZatqsFmdP3++sbHxxIkTu3btev311wmFRtMacBkICf6w+GTlFOB5Nj5I6LZGZsNCoRBqirLZbAiwhLsHzVJ+"
        "+eWXcePGffDBB4SAzPHjxy9btow+M+R/aXQqt+5i9KMZcrm8vb197dq1eCZaV1dXXl4OxUkIaGC323ft2iUWi/EFbMlFNzOz8YbD"
        "YYgGJ/BXgUCQl5cHahkEXoI7FhrV7TvumnD31tXPjyZUHh83rHT56qMQsJpbxPjjOkdjfFwzSxEfRaiCDQkm9KTEgQoaZrBNN44m"
        "HIkTepVnNrAjrqio0Ov1vxw1jb590xWXlVw7tmLUpYUlanGyH+bJBa89Pry6TPb8ysMGgwHzZGUJSq/XM/co/e8NNAPiRY86UDAT"
        "EFen0y1btmzq1Kn4IB2VSnXfffe99NJLNputuLgYgxyLxWw22/Dhw8kkbN++fZ9++umePXt0Ol0uPx5FkT8be2EPi4qK2Gx2Ml0T"
        "SEmyNgg0tkTsocPhoGxYBpQIKAt2P6FZGHjym5ub58+ff/r0abwdDGJbIpFIxs2B/x8fxdDPbrd3JfrRY6ZYLN65c6fD4cAzm4kT"
        "J7733ntkJrphw4ZIJEJT1ZlGPaVUxfCo63A4klXT5PF4BAMmZLWJRCKpVNrS0vLAsp9PbpiFL0EAfkFoK5vb04frbHOGinGW5MIC"
        "EZvNoowmY7FY0WiU3KQPAphpoEWjUTAOE6giBHxRelhBUbM5g3gr97k299CbvslgEzAjP4vFKi0tValUJpPpp/36H/fpEATR5AkH"
        "9swf0DO/f13+oN4FhBawCII8cFOfvb8ZdxzQQ2ZqTkAVFhZ2Uv3RlEVsLgommu6a6N+HK/QHzhUWtrS0vP/++/fffz/+nfnz569a"
        "tcrhcGBdJ4GZJRIJckmjV155ZcmSJRiPAZnX6XS6XC7KlaSsAI4ZduDUdTodnvoIBILa2tqmpiaoWoL/FbT2raqqYlItKFnVJ9Aa"
        "N27ciLcEtre3z5071+l0YhSTYMeAUA6LxdLc3IwvlAPGNBpnJ9Zem1KlprdYXrQsFh9rTk+LGRqcWSyWy+VKiX4KhYLH4/H5fJfL"
        "5Xa7M94fsmmR0qKr0+k2bdp0++1/xZ7U19e/9957CoWCUBFi3bp1LBYL33gy3T7BNAY0wNhvXq9ns5E/2y0n2i3+e57f43Q6IbSE"
        "rJZBp3Sr1dqs99TiatyIhVzkz+ZZNCpgMowVJ89PBUn9fJsbz/YEPE73bvLGVg/lNzY1NVFGxhYVFdFDo0y/0Wq1lA251Go1kJpm"
        "gwfPREvUYg6bFYsnkoXnhMPhYDCIoiiXywVaBEHFmCMMeozHYjGFQiEQCMLhMJvNdvn8237Wfbe3DUEQlMOqH1H23PzB3Yo63PR5"
        "s3ruOKB3uVzQhxWaaecEVMaskRIHyAXYaXAgg3q0ORHj0HQbeKW1DrlcLhaLV6xYccstt+DjdyQSyUMPPfTMM89YLJbS0lK8o5FQ"
        "xsxut7/44osCgaCqqgpv+8X3js54gFX25MmTAwd2aHk4ceLE119/3W63q9VqfAaC3W6PxWLQVYPJXlHGa4CE26dPH7yGEYvFHn30"
        "Ua/X6/f7hUIh+VAg1QwhhUFBR2KsfD+QPPxGga5PVqy9Xq9UKi0tLf1fUlKzEf7o0a9bt254awpse5boRzAtEh7KZDIWi7Vu3To8"
        "Ex0xYoREIhk3bhzeBaXT6fbv3w8xlsmm8Pl80HwURVGZTAayFxNzLoZdvWuUStlfOxCLJx5fccDn8/l8PkqMjUajf2CstIOC4vaF"
        "Ma3xD4wNxwS8vz6nWC1isRBqjBVz8bmMlNf50AnzyIEdqlhcNar8zMfHMJ0eWyosflZ99fUdK97d9NhPPp8PzGnJoIG8i7/gUIGW"
        "Ehr01kUQ5Mhp67B+f+GMgM8Z0le9/5gZK0VC8B2cO3cO+TOEAuOmgC16vd5ut5PRpqSkpKysLB6PQ8yX2+3esrv1WIP9wBdT8fYA"
        "KN4bDAYZgvL7/R6PhwYUZUtX5r6DXOFAFwyy8Sbt6pTp9mxTq9Uul+vVV18l/Omuu+4qLCwEXws8gVIvkIiNDYvFEo1G5XI5njG4"
        "3W6XyzV8+HDCyxlYRTgczs8//0x4fuedd/L5fLPZ7Ha7obxDOBz2eDxms5nH482ZMyebSYEWnz17lqAv3nXXXdBG2OPxQCmlaDQK"
        "qf0+n89sNnu93mHDhhFMdgAHyAcQJkK9C7lcfskll7hcLjxGWq3WYDA4ffr0v2NYXcZsnh51adBPKpVCVQfsJrvd7uzRj35hHA5H"
        "KpX+8ssv+FZTPB5v7NixhLjcdevWQXYpJfB4PN7a2qrVam02m8vlstlsWq22ra2NpigEYT2AsQ3NHdrIcNisO6fVRSIRo9EI8Q1w"
        "UwBj/X6/xWLx+XxD+2nUqg4BBGebnQATC8uyuzrQSrmE17c2z+VyAYmHYTabA4HAtHGVHHbSQ5dIJGw2+4d9RJP7XdPrJCKuTqeD"
        "KwBfB73cEQSZM71u9KVF2H89KhShcAwSK2mgQXsWfEUISGKhgcZiscjQ7r+xdyKRaG1tJRiBY7FYW1sbh428/sTwZ++9dM70uqtG"
        "lvWqkqGsqE6nczqdNpvtku6qmyfVLri179IFQ1Ytunzjm/VFBSKz2QwbK5FICgoKampqVCpVm9Gr1XfQxaWiP+wBXq+XCSi1Wl1d"
        "XU0PKgMlj8ViAQmixAG3202mWvQ4cMHMuSn9ItkowjKZTCKRvPfee/PmzcPnaQgEgscee+yf//yn2WwuKyvD5opGo3jKXlFRkZeX"
        "Z7VaWSyWUCiMx+PQZ1gikbz88stZfjyHwxGLxdu2bQsEAvhYobKysmeffXbhwoUtLS0KhYLL5UJ5zEgk8uyzz0IbqbSII17VgOv0"
        "008/ESxyjz766JEjR3bs2AElQvh8PtTsDYfDPp8vFAoVFxe/9dZbhCl++ukn8Jvi2TO+Fh2CIE888cRNN90EpeZQFHW73Xa7vbS0"
        "9F//+hcTY+OF5Xxp2UWzF/4o0c9ms2Ho5/V6maAf/aoY5tvI5XK3271u3br77rsPezhz5syRI0fiX1u7di1wXEqLpU6nc7vd06ZN"
        "g9q5TU1Ny5cv/+abbxKJBE0wCH55UDj+pwP6yy7pIMA9cke/o2esOw8aIPefz+eDpxDK/YTD4eIC0ZtPjiBA3nHAgG3mn+zZWdwx"
        "H+bxOf1veeKnhoYGaDjv8XjsdnupRvzk3QPo91yhUBw6YTmjddZV/iVSqFXClx4eev/iPadPny4oKBAKhbFYzGKxBAKBWfXVA3t2"
        "kIR+PmIELwkTaFALngk0Docjk8l+OWpqaffizaH1I8runNrjg2/OQiVqUBWCwSAYvf55+yX4AggIgix48ZfPvm0EFJ0wvPSxO/vj"
        "//rATX0Wvn6woaFBpVJBGV6/3+9wOIoKRBXFHdDD5gwCAcwhqJS3jPK2wicnw4GmpibAAbfb7XA4UuJAxrSIeSo5uRI9mxJErppy"
        "w9BoNJFIZOnSpYTnt9xyS2VlpcPhAKcLGDRaWloIUvCHH35YVFRkNBq1Wm1LS4vD4Rg8ePC2bdt69uyZ/dry8vI8Hs+XX35JeH7P"
        "Pfe8/PLLQqHQarW2t7dbLBY+n7906dIHH3wwXZJNqPwpFApFItEnn3xCMIDweLyvvvpq+fLlJSUlTqfTZDIZDAaj0QhthubMmbNr"
        "167Kykr8TwKBwMcffwzduZE//aN79+4lLKa+vn7FihUoiup0uubmZrvdPmrUqC1btjCsF9j1DK8zLDAp36FBv+LiYrPZ3NLS0tbW"
        "xgT9mNR6ZSiAktt0T5o0Ca90njlz5uTJk2D7TWbFnTFjxvvvv19bW8tisWpra1evXj1t2jToZMBkGRAr/tm3jcFQB22Jx2V/8fK4"
        "pQuGFBcIPR6P1Wo1m80Wi8XpdPLQxJ1Te+z4YHJFSQeCGwzFPt3cIBQK+Xx+IpEAArr3N2LU0oThpf9+ZBjKSej1+paWFrvdPnJg"
        "4aa3JhIahFF6HxEEeemDo4TnMydUfbRkrFrFBzLS2toaCQfnTK977YnhhDe/2NoEmUJMoLW3tzOBBoUR1Gp1PJ545aPfCe+8+M+h"
        "Lz08NF/Bs1gsbW1tbW1tFotFLkGXLhhCqFbvC0Q272wRCARSqZTD4Wzb20YAdfeMnk/eNYDNirW3t7e0tOh0Orvdfkl31Vf/Hk+I"
        "Ct73uwlokVAozBWojM2BTHDA4XAwxIHMpHnm2fNktyZKVj0ZNlFjPqDi1Jdffjl//vwePXr8pQWj6BNPPDFv3jyz2VxeXg48YMeO"
        "HYTy7iNHjjxy5MihQ4daW1sFAkHv3r0hQw5k3ixDwsBQ/NJLL82YMYMgy8+ZM+fGG2/cv3+/1WotKCgYMmQIrBAi/ZjPS95DtVrd"
        "0tKyZMmSxYsXEzTjuXPnzp07t6mpqbGx0ePxCASC0tLS3r17k2sQIgiybNkyi8WCFX+BUrFr1qxZuHAhwU57++23T5kyZf/+/X6/"
        "v3fv3nV1deAFjEajNO6xzvYlXDwcFLvMXYx+9IPNZstkst9++02r1RLkJ7wtF/mzTxx5gO8W37jmDzH/8cfXr1/vdrsZnn5+fr5e"
        "r1+66rfn5w8mGHXvnt7z7uk9m1rdTa0ujz8i4HFKNOLeNUp8Zgg2lq8+YnGESkpK4FAEAgGKomu/P//k3QMINrrbpnSfPKbbgWNm"
        "fzDaq1oJumAoEotG4xCaRHnKIpFIoVBs3tWy/ec2QmrN1aPKJwwvPXzSqjN5RULukD4FeQoiOf75iHHXIQOUNgTClRNogCTQk/zL"
        "75pm1VcT/Kyzr+tx+5TuxxrsWr07Hk+UFUkG1OXj/Y4wXv34uNsXhiAShUJxvNG2+3D76I6twv95+yXzZvX89aTVbA8IeJwelQp8"
        "5zJsrFp3hsVigeyVK1AZM9Fc4cCFch6xU1qZcqKPQgjGc889R3g+Y8aMuro6UEYhEPydd94h+6g5HM7QoUNnzZo1ZcoULMd87dq1"
        "DQ0N2dOpwsJCq9W6YMECygO+4oorZs2aNXbsWIzcvPDCC0zmJcgi+P9VKpUymeydd9759NNPKX9bU1Nz1VVXwfcOHDiQkoN+9dVX"
        "//nPf6A0P3bMQOw+/PBD8vtKpfKqq66aPn06cFAEQVatWqXVai9CfnZBZswh+uXQkAMqEUEZxY+vv/4a8mGSWacRBCGUZUAQBFwS"
        "THrLY8uQSCTvfn368y2N1BhbLps4smzmhKrJY7oN7JlPyUHXbD+38qtTIFJjGKtUKvVm30cbzlJgrIw/cWTZtHGVmDX1/bVnmjs6"
        "5LANj/85SkpKOBzO/Yv3kgvPohz2ZZeop4+vumpkGZnnWR3B+17Yw2azS0pKMIpZXl6OomiW0PB+IhaLffei/yN/BZvN6l+XN/XK"
        "yunjq4b0UZM56M6Dhrc+PyEQCOC+FxQUsFisR/69z+0lZu+IhdzLBxXBWVCyvXfXnNr/u0mlUoGsAOGTOQGVGXPKz8/PHgeypAwM"
        "g/wpVVI2w/nwI933wW6jUCi2bdu2b98+wmqefvrpRCIB0ROFhYWtra0PPfRQylnOnTv3xBNP0JgNmSs9SqVSqVRu3LjxX//6V8p5"
        "t23btnLlSubnlAxgeXm5UChcsGDBsmXLmNMyGLFYbPny5fPnzxcKhYTCv2q1msvlLlq06NSpU/RADh8+DJkb9Mf3P8BHmYtTGo0m"
        "e/RjeCcZttIEwx1UliePgwcPtra2UjbQgOODWLOmpibCD+EJE8KHYUJRURGfL3jopX3LVx+NxuLpYWw88dIHR/+x7BeBQEgoYAkF"
        "Rp5fefjUeUcKjD1lWfb+kWSLBA4Kn9ytWze3L3LtA9sOHDMzXKHe7Jv64HaDxV9eXo6PYeTxeJWVlVlCwyiSUCisrKy0OoKT7v/u"
        "15MW5hu4dU/r7f/aibDYFRUV0OyBz+eXlJRodZ7rH/kRvJIMx6p1p595+1cej4cdBI/HyxWozAZQrSxxIDNalFaaXLKH7C4jUmq1"
        "msPhkJXRq6666tJLL3U6ncFgUK1WK5XKNWvW3HbbbRZLUiTbs2fPNddc43A4crW20tJSmUz27rvvXn/99TQJ9V9++eXs2bPpe10x"
        "JKwoilZVVUkkkhUrVowePXrjxo1MWGk8Hv/2228vv/zyV155RSwWV1VVEcq6cjicioqKQCAwZcoUQsto/Ni0adPUqVOzLF54UfHI"
        "nMxbUFCgUCi6Hv3oZV6ZTHb27FlKqYjelgs8GEEQcgwUBCikNMERMLa8vFwkEr/68fGxszdv2tnMhJXG44ktu1vHzt78yn+PCwTC"
        "srIyAsaCrhYIxa77x/YdB/XJ4Gze1TLjoR9C4RjN1cBYqUQiqaiocHoi1/1j23P/Oez0hOkZ/CebG8bO3nxG6ywtLSVHXMvl8urq"
        "6pxAY7FYKpWqpqbGbA9Ovv+7Z946ZHOlYFptRu/8JXvv+NfOaIxVU1ODN0rl5eVpNJpfT1ouv2PT+h+18XiKK3DqnOOGR39c+NpB"
        "aIaK9/jkEFRm8mu3bt2yx4EutuL+dTUyI1gZFFvn8/kqlergwYObN2+ePHky/k9PP/30ddddZ7fbhUIhePi2bNmya9euWbNm1dfX"
        "9+3bF1pPm83mQ4cOffXVV9u3b09JNNNyv7HZ7IqKCoPBsHPnziFDhkydOnXy5Mn9+vVTq9XxeNxoNB46dOiDDz7Yv39/Bl69ZNvF"
        "5XKrq6tNJtP58+fnzJmTl5c3bty4YcOG9erVq7S0FPL6I5GI2+02GAynT58+cODAtm3bTCYTiqIajUaj0VCClUqlVVVVWq125syZ"
        "9fX1N9544+DBg9VqdSwW0+v1+/fv//zzz8nBR/9vYBYCFouVPfplxvWTdfF0OBzr1q0jVE6OxWIbNmzg8XhYTAc5rAES89euXZtI"
        "JB577LGamprGxsZly5Zt3rxZLpfT1wwhrxD4qM1mO6ez371oj0rOv3Jo8fB+mp5VylKNWC7l87jsSDTu9oXbzf7TWufBY+btv+hM"
        "tgCHw8nPz4cW9+SJJBJJaWmpXq+/4ZEfJwwvu+Gq6kG9C9QqYSyeMJh9+4+Zv9jaBGGuTLYU4iclEkltbW1ra+tbX5z44Jszky7v"
        "duXQkr61qhKNWCRAw5G4zRk8o3X+fMS49vvzerMPhFqFQkHZjVgul/fs2VOr1TKHVlNTk0y4USgUvXr10mq1K7869cE3ZyeOLLvy"
        "spJ+dXmlarFUzIvG4m5fuNXgPXLG+v0vuv87ZIjGEnK5vKysjGA5APOAQCDQ6/Xzntu9+N3fpoztNrx/Yfduck2eUMBHw9GYwxXS"
        "6j2/nbJ+t7f14HFzIoEoFIrS0lIy2yssLOTz+QaDIXtQCIIEgh1UAqg5TEM8JRJJZWVlc3NzljiAZNEIJHNG279//2Tz0VAKs9ls"
        "NBopCzJVVlaSK8tjHpqzZ88mU7k0Gk1h4R/+do/HYzAYkiXwKhQKsVgMaV7kUVxcrNFo3G63VqulXGFRUVGyAmler9doNPr9foKO"
        "D5U5lUqlRCJpaWlJBjaz7PtIJAI5fJAYhyQpIgM2HIVCgXULp8lBCoVCer0eSlKQlwofAlVYyQP7EJPJZDKZKDXv4uLivLw8TKsI"
        "BAIGgwHCWAgDWiZhNSKi0ajNZqMsfAgGVY1GQzNvUVGRSqXCz9ve3g5dTcjzqtVqLGwV5qUsXwfz4lEC0C9ZRWKFQiESiSAvkDwK"
        "CwsBFNwRyncqKirIdyTZacbj8ZMnT44cOXLTpk34F3bs2DFjxgy1Wk1T7Q/5s+EzYYvkcnlJSQm+kDqTfDaMJsRiMYfDgaXx0QgE"
        "PB5PLpcrFIqUnXBCoZDJZKI8SgiXFQqFyeplqtVqrFwO4UNcLhc0hU02L5fLzcvLKygowK8wWeim3W43m800Uc08Hq+goACsbuSf"
        "EzYKOu55vV4a4V4mkxUWFuJ93uQef7FYzGw22+12mh69YNJQq9UikYimRQ+k69jtdkibTgmKzCySoT09a8BwwGAw0FAtsVhM6F5O"
        "plr0vEkmk6Vb6iDlC9RMNGVxong8brVaCTWuoCQVfeKE3++32Wxk+sjj8QoLCwml8kKhEFbuAARhoVAok8lAIrNardBYkUA6CwoK"
        "/qhUabOR76RIJMrPz6dvvhEKhaDiQSwWY7FYXC4XimtDLwiYl/AToVCIzZuxRhKNRiElNBKJQKNpYN5Qak4sFkOYH+UdoDypcDgM"
        "vBlacKAoCkVN/6gLarMl20Cs7BacMvkdrPI4Xv5wOp2Ea4yiqFQqBU6GLTUSidjtdkAefCqtWCzOy8uD7Nhk82KRk/h5XS4X4c7D"
        "vFKpFB8CEIlEHA4HuTAbzEtGiXA4TEY/6EVMs3sYdsXjcUgfJJsKVCpVyruKQbbb7Xq9funSpffccw/+hfvuu+/LL7/s3r07kwhh"
        "aKBGrlhEaNjCREvG/zUSiQSDQQjzxhq+stlsLpcLKnJa8SYQ8OzxeEKhEFw9FEUFAoFEIoGb5XA4yCxHKBTC8SWTBqCGPjRXx64V"
        "h8OBO4Uvt0Qu1YmQokiALnm93kAgEIlEoBwBh8OBdZI3NuUlhU/GoMFXQ7AY9uE0HBT/D5/P5/f7sc8E/w6fz4eiocmaz1DyCSh4"
        "BAeBgYIzxUBRfh1cXkq0Z5hTB/cuEAhgOICnWpTkl5JqkXkTZl1Pt3MA/V+TaqIXxMpM38Uwh9Ol26WZIb1Dsiijk3KdlFeRYaug"
        "ZC9k02mIRndJazqyuTuDApOdh0s0cDLe9pQoajabw+GwUChks9nt7e0ikej333/HV3wMBAI9evSIxWI1NTVZ2pYZaqL0qJKTI0tL"
        "Labh/UwaIScrqsyEj9L8OyeUih516cNKk0WGkzluugvL4OgvwtKh6VI8Jpoo2mWrxztsMuA0GZ8H5W8ZtjGifIf+h8wbXzO/Kvgy"
        "GZmR6bTWwLxnVsbTkZtWdjbupZTe0j0yhi8kA0sDymq14g1iPB7v9ddfJ9RM3rRpk9frhdJUadEFMtdJFnyYVg5ArgLKUkZC5oQE"
        "IR0dqEzeoWxUnpKgUVIehuwwsx0jN0lN9qXMT5ChTHzxsEwaUpbzyMdEIoEm24JkbrnMOqli8lEGfJTw207io9mI0uTfJsPjzDgo"
        "kmbzwnTRmlIY77w4W7Jcn9lc6X4mPapnXwsiLUmcfKDYtjscDrlcvnPnztOnT/t8vssuu4yQyBSPx9966y1w0qeFz5QEl4YmXrT5"
        "SGlhF6UexhzJKduO0iQpMVeOc7LDNHwaT3bwTcgpjUY0zzNT0XJr92IIkB7DO2mFaLpSScpl4W0g9NLNBddHO+MC0xtS/vdao2SG"
        "JJ1BTbJHhiwRLCcLg3Z7V199dUVFRUVFBeVrq1atOnnypFqtTubaz0af+5vyznQ/ilLMzUBaJWsFzBXTzFIMKK04KWs1pzx9hp+Q"
        "scpx8ZM+hpyLgomS1X8aqRZJv4sLwSTC/P2/EQOgN6dkMEu6xrSUC0v3o3IiIDPP4sjYkJUZ28u5Vz4n6wcgEOFM6LmNH3v37l20"
        "aBGfzycH5VLuOc0uZYlUyEVWOgP/+WnRNPpdot+6ZHyU3sjEvFIrwxdSph3i5yWwYcKSKOu/Up54F5MUJsJBMtmok8j4X5poBqiT"
        "GR/NocCS0nRGYyNliJ0pHelZfgK+szSS3KaaPaVLi/ylvP/Z8NHsYebKpsQcx1IK3Wm5kOmxNJFIuN1uLpc7fvx4SiCfffbZo48+"
        "GovFKisrmV/bnGx7utptBhQ2g5tFg2A0AWsMgadknwRqS747zFUImqYFTO5Ryj2kid1LZtUnCCVMaGP2d5n+S5PZ+fCfk3E0X8aE"
        "oisCi7rGQIRH05wossnk+i62MV48h5LlTy4Ge05Kq1cn6aApTfrYC9A9d9u2bQMGDCgpKREKhYFAQKvV7tu379NPPz127BiXy62s"
        "rMSXprtQe5jSrdN5EWoXajDUw2jMeAxZNZm5Mt/MtGQFeg6KhTR2TZxESopxcfoaOiXFhaHkm4HSyTCcmrmkRi++5YqJ0sySknB3"
        "HtLQ5wjmVslg/oHZBxyldXbM/VKZaaLpytcOhyNZ4UkOh6NSqWhcoVna1ii/lIC66Z5OzqNIMtj8zqZjCIMqOWmloqbUTXNoSEuJ"
        "1eScGZpsmYyZHMOgcSb3mnnoa64G2hmsnrwLKQWZdPWwXNnxmEhtnRFBx1zvSbYG5rHymW0szYxphRVQxgp2jXKfGUHMEjITZzbN"
        "1EqlUiqVejyecDgMFQw4HA6XyxWJRBKJhCGvoncUIckTdsl/zSAhMpkykS7N7VRbfUqDU/aGwWQBsWQ6iX+HPronJbdOuWwmUiM9"
        "wlAuNYc0M12rO3PCmK6RiWEFQTQb00GuTIi5yjHoPPrbGdlF2awhrUju3G4s5XVK68O7/pSZz5gTEpDlz7lcrkqlYp5/RekoIvwk"
        "g2xpepTLwPxIk2pJY3PqAsE62cKyUXPx257MCEz2PiaTP1LGzeZW506m/xDYJ2VI80Uba4ak76ZhuNsocjGNzErbdwGlzjgQ9CJR"
        "qv7/k11Dvj/pctAuFo8uwtF5uWT0h5LZkWUcz8/QQd55FIOJJIpXZ2nsCp2n+ZH5fZZI0sUXJOcqEPmr/z9cU6m9Xz6DcgAAAABJ"
        "RU5ErkJggg=="
    ),
    "RaidFailed.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAQoAAAAoCAIAAACJuiMXAAAbcUlEQVR42sU9aXQUVbq3u6u70+l9SWcBkiZRTEQMHjcOw2N4LuPz"
        "IWpwZQkTCSOCPmGQjB4jRpDjAg4DA4zGCXrCw4gwhoNGjowyLiAKCh7hkQwBkk7TSeh0eku6O73U8n7coSxquXW7k5mpHznVlbvV"
        "d7/9++5XisrKSsC5FAoFGKMLDsUwjHBkhmHgT6k27BOpJbEjcJ8IG3PHQVzcvrzFoEfgrVOqsej4OMOiXyejBWMuFd1Rao94s7Ob"
        "C3+yD3k4gEA8qVlEcUzqX6KvnBGGE2NLG8IR4LKkXl4W6RGUIAo42V1HNOD9CweBeECXQjv4HB8jMdeAv2Dhv/AphNcSH19FuR4+"
        "JmSBbLKvnCn8iSw6i7bkkQGC/YuSUEacWJa1SM2eBYLKzoVgezyGioAJJodG4zeaO2YKZFmUyBRhWKbGVRyELEaK63GnE4U5D+AZ"
        "LVVqDYRKpWJbcOGFlqE4OCS7VlFZgdY0hPeiyIfDdDFVHeGwmGghSg/oV0YrS7L8nodAovDBWYYoSGV3XFR5FiUDfEHBWy0a99Dq"
        "k+jsXCiJQu8K8hDdG0zej0MeWStvonuA4M1oDiTkoAgJI7p+NOpIqYgZYTZvLkydBB+YOIQ6VnIjO70ODQEpMYKvIMi+I8MwBEJm"
        "iaKjrGDCGQHzNURNOhykFDVOcLQ1YV/hDUK0ouflvogUu0JIHkz7lWUBokKSx0RERajUdPgKGILZi8KHp7ngKORSa8A0a6WcH7xJ"
        "CUzKw0dQTB199PSNz4AzmoXbl2EYpVLJQ3pZIhxzEzxTDwFa0o6VJyYLhMHUjrKA3hh6XK8wzdHGNM8tI6t+CFm41M+soS/UqjGx"
        "TdSyQnAglqth+gB4BMP+i6Zp2eVlhBZCkIpqX0L4Z201IVie6C7g6FRoks4U4xEQQKC0rKFFiHI7fN1d+IaymMR6OWma7u3tjUaj"
        "ZrO5sLAQoWxk7fKT5ZejcQTj8Egof2Q1PVG6QtzjU1qm/Bg9oBRLQttvPKbm8/ni8bjRaHQ4HMKNFsVjWUUOYhSmDSn7kx2HoGka"
        "x3UAAPD5fIFAgEchSqVSrVbr9Xq73a5WqxEMg2dIMAzj9XqffPLJ2traDRs2tLa25ufnI5hBf39/IBCA9wUFBQ6HA2FiptPpUCg0"
        "PDycSqUYhoErtNlsWq0W4TPNImwka31JeTiktoe5fOFzbhxPd0auOeG7DA4ORiIRxCBKpXLChAkEQchy94GBgSW5ufNdrm29vR8H"
        "g3a7fXBwMBwOw2Z2u91ms2FaiaL+8bHVsgiKojDDKIFAwOv18tpQFDUwMPDdd9/9+c9/vnjxIkRxnjEqJeOGh4eXLFmi0Whqamqa"
        "m5tZjBcadgzDDA4Owtn9fv8tt9xitVqlLLlLly7Z7fYVK1bMmDFj/PjxKpXK5/MdO3Zs586dHR0dxcXFPNOTNZmyjpBkxLB5AUTR"
        "mICUVwARD+VxUBwLEO1z5y4mEon8dP31iJfa2tv70ciI0WjkoalwMbFYbIHLpVEo5uXnf9Ddbbfbw+EwHHwwnb7r3Dmr1YrwMot6"
        "vRH7OMpLyUhcXE6GMDdVKlVhYWFVVdWBAwceeuihS5cu8UaA0kn00uv177zzTjKZbG5u1uv1vP/SnEs4Oy1xud3u+fPnHzp0aNGi"
        "RaWlpRqNRqVSFRUVVVVV7du3b82aNV1dXWxjiqIoioI37E/2IW8BUqDgPcxUW+PJCvbi/YSXUnCpVCqVSsV7CFsKu4+hMyBrL0tu"
        "bu77Pl+Spnf7fLm5uVe0ycpPw2N2Y5v5QeCYVryf4XD44YcfhvcWi2XWrFmPP/44QRAvvvjiDz/8EAqFhFqWKIoUFBRs2bLllVde"
        "MRqNBQUFsg5HKYxkW0aj0TvvvPO5556DMuSPf/zj6dOnNRrNjBkzli9frtVqFyxYcOHChf3795vNZrQmKQV0fE9ARvoMfgRASi0U"
        "AkTooZYKtKN9Fdx/RUjyN2fPClc4QJL6CRO4C5ayGfLz89/2+Ta3txsMhry8vKyV2DEMBCHGIRCJg1JXOp3u7OycOHEiNAm2bt3q"
        "8Xhee+01AMDixYtfeOEFp9MJW6ZSqVAoFIvFSJJUqVQajcZoNFosFlajHR4ehrJbo9HY7XZ2imQyGQwG4/E4SZJqtdpisYg6y3l7"
        "HAwGn3rqKShb7rvvPpIkoVDasWPHqVOn3n33XbjCxsZGn88HuzgcDqvVyqrFoVAIjgyf+/1+Vi222WwAgOHhYZIktVqt3W43GAwk"
        "SQYCAfiCWq3WZrOZTCY4wsDAQDAYZGcBAAwNDcFmDofDaDSSJDk4OBiNRtm+QqJNpVLBYBC2YQEIF8wwzMDAALTHFAqF1WqlaToa"
        "jUIOHYvFoNqsVCqLi4u1Wi2E0vDwcH9/P7zXaDTjx4/3+/2xWMxoNHLhL0W3JMNcUCiKi4t5z20cLTqdTkciEbh3SqVSo9EYDAaT"
        "yQRd5IFAAC5yaGhIrVbzVCkWMXjWCLznbkdeXh7coFAoBCFgNpsZhonFYgxFGUwmqOdTFAUxMJ1OK5XK3Nxcm82m0WhwApEAAOVo"
        "6EyhUKjV6sLCwn379sGHlZWViUQC3vf19VkslldeeeXbb7/t6enp6OjYu3fv3LlzvV7vyMgIACAUCnm9Xq/X++OPP7KvDaGQm5u7"
        "cePGH3/80e12f/HFFw888EA6nZbV5lOp1KRJkwAAIyMj/f39ZrOZIAi1Wu10Or/66qsVK1asWLFiw4YNqVRKdN5gMOj1ent7e+Fz"
        "hmHYFZ48eTIQCDz55JPHjx93u91tbW1Tpkzp6uoaHh5eu3btyZMn3W73J598csstt3g8HqinwdFgX7/fv2zZsmPHjnV3d3/88ceT"
        "J08+f/58JBJpaGg4ceJEd3d3W1vbzTff3NPTw+X9vb29RqNx/fr1R48edbvd7e3te/bsqaqq8ng8EIDQGvR6vSdOnEgmk+vWrTtz"
        "5ozb7Q6FQjNnzoT/eueddwKBAFTDlEql3+8/cuRIb29vb29vQUGB3+9/+umnz50798gjj4RCIVF9TNRE4ep7XKzy+Xzm/v7njcYD"
        "V111csqUbyoqmoqKZlNU34ULEDGgpfHT9dcfqqgQNfcVCgW3zdDQEAsT7nO4caFQCD75vLw8NTj4rMFwuLz85JQpkGYikUiiq2tF"
        "Tk5baekPkycfmjSpwWzWeb0DAwOYyhuBE22QNXeSySS80Wg0sHtfX19NTQ3Uc+Cl0+kqKysrKyurq6vnzJmj1WpFl+j3+2fNmrVl"
        "yxZ2xpKSkvr6eiHHEgpupVIZCAScTqder1+1atXmzZuNRqPBYNDpdMXFxcePH2cXmZFSC69t27ZVVVXB+/Ly8qampieeeGLt2rWs"
        "w+2aa67Ztm3bb3/72y+//BJysiz6Hj58GErX3t7eX//611IAvPfee7lvoVKpmpubp02bxsLh8OHDwWDQZrPNnDmTJEn4LhRFlZSU"
        "uFwuAMCJEyf8fn8qlYLekccee6y5uRmKfa6qJhuq4/730qVLj2g0T5eW/rxmpfI6vf46vf7hvLyFnZ2Ey8W1NGTzIRQSGKgQTK1S"
        "KLZdffWNl30DCoUiEomURSJbrrtOc7mjhSDusFpvt1rXut1fDQ5CkS7qe2TvlTx+kEW0IRqN3njjjfDe7XZrNJp0Ol1WVga3NhqN"
        "vvTSS3PmzJk3b94333wDACguLv7d737HKh5XyG6SNBqNmzZtgqt89913q6qqHnzwwT179lRXV8t6YEwm065du+D9ypUrjx8//uyz"
        "z1ZWVkJGTtO0TqfT6XRZ6KlOp/OGG26oqal58MEHjxw5Ah++9dZb0Wi0pqamqqrq008/hQ9XrVoFWVd2fQOBAEVRIyMjpaWlCADW"
        "1dUNDg6yU9jt9smTJzc0NMyePXvevHlardZisezduxfyglmzZsXjcchN77nnHtilpaXF4XAYDIampqZEIvH2228bjUaexc9e3NeJ"
        "x+MXrry6u7tJkkylUiWJxNPjxwMAYhS10eNZ2NGx9OzZ40NDAIBxWu1TBQVcWZ2d/S310EoQ1+TmbvB45re3Lz17Vq1WUwMDm666"
        "SqNQpBhm08WL89vb67u7QySpAGBNSYkpEmF9tgibnpASGujs4qGhoc7OTqjm3nrrra+//jr81969e81mcyqVikQiq1evnjBhwt/+"
        "9reenh6r1RoKhZYsWdLR0QEAmD59eiwWE44cCoVWr14N3efbt2/fvHlzUVERAOC5556jafrRRx/lWX48GeJwOLZu3Zqfn79gwQKI"
        "lwsXLly4cCEA4NSpU42NjQcPHhw3bhymT5337osWLUomkyqVqra29syZM3CRS5cuhTr0448/fvr0abPZPGHChJycHN7gixYtSiQS"
        "BEEI+xIEwe2r1Wopikomk1wAut1ui8USCAQQAKytrT137pzFYonH46WlpTRNv//++0uXLgUAzJkz5+jRozqdLhwOQ/JIpVJtbW3F"
        "xcUGg2Hbtm2vvfaa2WxmvSOIYIJdre646SZRr65KpRqiqJfc7iKN5kgk4jWZzBMmDFHUqq6uI1OnAgBuNpniYjwxC4tZ9OHK8+e7"
        "jUaLyzVC0+ZIZJFKpVMqAQD1XV3HCMJRUnJ8ePh/zp3bVVGhUigWOp1/CoVgXBIRRSEQGSVSy3I6naK8/7PPPvv444+hyU6S5JEj"
        "RwKBwMjIiEajCYfDFotl5syZsKXBYGBplztXLBZj27z99ttsjKKkpKSxsZElDy5J81brcrnWr1+/a9euxYsX33HHHazld/3112/f"
        "vv3QoUNPPPEE5gZwn4RCIbfbXVZWBjXJcDgMRXNnZ2dZWRmMPHq9Xmhb8xx3oVCou7sb9k0kEmzfs2fPlpaWwvbcvgqFwmAwpNPp"
        "L7/8MhQKJRIJtVodDoetVisXgCRJsrs2PDz83XfflZWVcSMAHo+no6OjoqLizjvvXLlyJU3TDoejoqICAHDgwAFIogqFguUXmFmx"
        "UmFBo9FI6nTHEolgMJhIp9VDQ+Fg0AzAtMsKj16pFG561rTBQ9ooRZ0kyTKbDS4mFov9R3Ex9CVcTCYLEgkQjVoBSAGQoOkcpXKa"
        "ybTR7ebqV6ImBoHpQ5SF0bp165qbm1kLIRqNptPpxx577Be/+MWkSZPy8/NhboWsTwyKi0gkEg6HoeNPoVCoVKrz58/LpvFA0BQV"
        "FcVisZdffrmurs7lcs2YMeOee+6Bevntt9++YsWK9evX4/seWK2Pu352Uq6AltI/odNJ2IybiyXsG4/HaZqura2VAiC3SyKRUCgU"
        "cEBWVbBare+///66det0Ot2MGTNOnjzJuuNbWlrsdjv+SZKfHbsU9Zu//13o1bWUliqVypGRkeSlS/Os1lsLCkpzcvI0GuXYEQP6"
        "StI0Fz7pdLpYq4We2d3XXitsX6DRkCQpHzXPQudj4x4qlaqxsRGSRCgUslqtkCdFo9Hi4uL33ntPp9MBADwez1//+teurq7Tp0+/"
        "+eabmcIIMzJAUZTf74coQhCE0+l0Op00TX/66ae7d+/+5S9/uWPHDgDAI488snbt2jEU8bKSB58IuaHliRMnZgpAXtxDr9e3trY2"
        "NDSoVKrZs2e3tbXNmTMHOga///77iRMnsvSJeWQAAEDSdLdKBSUh27dIoWAYJhqNFgYCb06enKNUAgB6U6kvQ6GeZLI9Ftt4ub1Q"
        "e8HM90Pkp2a3lerL3ERUcv58WjCLOWDco6ysLBwOr1mzprm5GQBQX18/ffp0i8UCvU/Nzc1waxcsWPDNN9/o9fqcnJyLFy+iyUOt"
        "Vvf19ZWUlJhMJsje4NpIkrz66qvRq4rH49OmTZs/fz4AYNeuXWfOnIG2ptlsNpvNn332WSQSMZvNrBMdTseFkagz7d9yBQIBljYW"
        "LFhw5MgRnU6n1Wr7+/tx+Au7u8lk8tChQ7/61a/uuuuuiRMn3nDDDQCAPXv2QOVWGPrEOTghxQ78fv/mkhJIG8s6O3+gab1er9Vq"
        "PYHAxivJCc0auG3USuUVG4Sd6axWq/uSyeKcHJJhpv7wg+ryztI0Db2sKpWKm+MnqTTKHnlBMG+j0Xj48OHDhw9Ds3j58uXQo5xK"
        "pSCDiUajX3/9tcvlysvLS6fTd999N3o1BoPh66+/hvfLly/3eDwkSZIk6fF4li1bhl6nWq2mKOq222677bbbVq1aNTAwAMNwqVRq"
        "cHCwvLwcKvcXLlxQKpXQdrJYLKWlpTCC5vP57rvvvn9BVgUOhLkA/Oqrr8aPH2+z2UiSlAUgD2OsVmtLSwt80w0bNsCHu3fvNplM"
        "MDhDkmRfX9/58+cvXboEQc1LtME5vgLbpFIpV04OACBG08eSSZfL5XA4SJK8nQ38iYW6eW6xf/BsggiRJADApFKVXFbUfT7ff5lM"
        "mNDW6/VHh4agcvVgXp7ZbC4rK3O5XFqt9vGiopqCgulGo5BBiJCH1Cbx8oikYDRu3Lj6+nqogi9btowgiHQ6TRAETB80GAybNm2C"
        "8eDq6uq33noLDWWLxdLU1ARHW7JkyYsvvmi1Wh0OxxtvvDF37lw0Kmi1WhjwAgBcd911n3zyyfTp03Nzc/Py8hYuXNja2gqbNTU1"
        "GY1Glgh37tw5depUo9G4ePHiV199dWxRH0dnEO0LjXUIwD/84Q/5+fl5eXk1NTVoAAq3T6vVQvse2l0AgJ9++snr9bJq+sDAwMqV"
        "K8+fPz9v3rxAICCafkZRFE9t46Wi/cywUylogr9UWGhwu3Pd7rkM8wZHdPBeHtqKPAioVCq9Xv/t5YjhtquvnhyJ5Ho88wjihZIS"
        "zNe3WCw7BwbSDAMAWFNSskCt1ns8ef3965zO1RMmPF9S8p8Wi2zqEz9qnkWamkajCQQCMF9Dq9XW19fDhNnf//73sMFDDz3U2tq6"
        "f//+uro6qP2jLCGCCIVC9fX18Gd1dfW+ffv+8pe/zJ079/nnn5dFOIfDMX/+/L6+PgDAtddeu3nz5gMHDrS2ttbV1RkMBkgbra2t"
        "hYWFr7/+OkxtKC4ubmxsbGtre+aZZ7Zu3Zodlo+5nLFYLNkBULjI3NzcDz/8kP3Z0tICw44Qs0dGRmpra7VabU1NTSwWEyaDQmrh"
        "jc/SDDdZ02azvdXbCxvc63C8W16+s6LiyXHj3rucvyP6plf4Gy6H4R0Ox7b+/hhNAwDGaTRvlJW9d+21y8aNa+rvxwQgQRBJm+25"
        "CxcohlEpFEuLiv63oqLpmmv+224HAPxfLPYnv5+rZksuDzMsiEgrcDqdGzduhCzqgQceKCkpyc3N/fzzz6urq48ePQpVl87Ozrq6"
        "uoaGBtlNdTqdbW1t999//xdffBGNRimKOnv27FNPPcVlnLycYm5cOZlMzpo164UXXjh69GgoFKJpOpVK9fT0fPDBB7Nnz964cSM8"
        "lpBKpe6+++6DBw9Cwd3e3v7MM8/wpIeoRBWFQ9an/6TEsslkOnjwYKYAFPXRm83mDz74gNXZ9u/fDzkFXLlOp9uxY0cikWhqatLr"
        "9TxhyFLLz4Nflh5cHQxeRqPxa6VyeWfn98PDcZqmGObCyMhat3uDx8M1f3mDi5610mq1iqKiR9vbvwiHYxRFMkxnPN7Q3b3l8nkK"
        "IcgYAVTtdvuPOt39Z87sHxz0pVI0AAmaPh2LvdrTU9vdne9yybpSGYZRQHMNkanxs/9uYICNB+fl5bEZbNBr0dfXB/uqVCqXy6VW"
        "q2OxWDAYTCQSNE1rtVoYLuSOQJIk96fNZmPnTSQSMGZCURRM1xsZGeE1Rhz4HBoaGh4eTiaTUL+Ex6HMZjOUp7BlKpWCU9A0rdFo"
        "rFZrIpGAeUfgciYcN+ONzY0LBoNsxNpqtULv89DQkM/ngyPDBGQ2fw72hRGYUCjE9rVYLGyqIpsFBPvCcUZGRsLhMASgRqMxmUww"
        "3gpb2mw2iqK4P+EUXKczNL1uuummpqYmAMBHH320evVq3rEzNiURnrcRPVkVDAYjkQj8r81mY5NKufFm+BduUyKRYBgGQjWZTLIw"
        "zMvLoyiKTaPMy8tzOBzwmB184nQ6IV4pFIpkMgnXxg6VSCTYgBtMSWRxkrtBXJSAOBaPx9PpNCQ8k8kkmq8tLgamTp0KpI/eYhZ0"
        "wakcJVp3R/QwHTqhXba+RqYnLnDeAn1YSvRgtyxfF44vPAAoVegNcY6fZckXL16cPXs2wzANDQ2QJKqqqvr6+qTyVTHlEst00UUQ"
        "uYKCNTCEpwNwiqHxOgoPIwHBaWSpygGYeSH8uAfaysQ8YYxwUcu6CISVnWRpMuvCFjjV7vCNb8wQDc746MOAALvEjkKhSKfTU6ZM"
        "2b59O/vwww8/PHXqFIy6jsYDwT0JiD7Kz5Vj3DNePP1c1OGLdiILC8MhPEmjKVpAZMQ8RNeEphAcrw5bnCHTCIwQuXG4OMiw0g8+"
        "2QjP08sy49EcE0d0jMfj5eXl0Wg0Nze3p6enpaVlx44dRUVF+IU6EZSPLlsIxGodCYMqvHORQKLKI2KFQkuGfTv2hCm6uBRCuxFR"
        "rhBleLIIVeJXNpDCVFEEkq1aCeRKvsvOO3rMRhzrw5RsskVhEBWNGYaBOQTQblGr1azCLVpOEieBSLaAL1rBFm6WKKKzf1kVDrN+"
        "jZQQFh6ZzKgOGyGrT495IGyseOQ/r/hX1m8nVVQmI6iKylLemVjZEWANAJydxVfYMhKhiAailI8QIwgPIUIf45Xz40kS0foswnck"
        "EMJFqsweJrOXUk8RRZBESw4LK3sLcQW/chnmvqLrn+OUdsVxCsuadghvhOgry2YZol0vODUBZW1I0Y6iWCFau1X4Ilx5IkVFstas"
        "EKRSp/O5XYiMivjiF4kBY1G1QLbee0ZfMhi9Qp91zWZ8V0EWemAWlkx2haQyKoGOrsQnZW2K4jF71JFHG6JeMnyGKPSDCQmVyMhs"
        "xfkgU3akhUNmaO6F9oRmrZWhP9Q0ylrl+GTJMz1lv4qE+fWsjLzPWShgiKInmFY+V1nlrY1LJ8LkFNmlihoqcCKapv9RoR1dSRZH"
        "F5LlZwh/JWIodGl0HI9npud7pPApI0mSqXhEIIeoeoDpLxkTq4xn/eN/qUyWGMDoCk5zR+MiNMIVJssI4DiwnApLDgQ+MWCCI9N3"
        "Hr0P4F9ghWf0jcJ/4zXmC+CZs6OnuqwHQRc+F/qLRQ+Tyoo+ntFLIHR6KcsGXbB9lNQiq7zi+B+z46D4tjjaMYqvtGCWbcZXIxEV"
        "wbMov41TcRzhPEAYiohAB6IyHXrTef5invYFBIFInG0ixlBXzqI2eKYmtdTHEv55zBvtpsOcGp2ikoUoQCetSCHrKD+ziF4/+qsS"
        "WX99Bce2QSOksCIrvjubyA46CKgJTUNRlobgDbwvGyHchfg6T6ZuNMwvB2RtgWTnWcKnTCmCzOjbYvhfUJFyvvEkBq9WNI5PEtPo"
        "R7SRUr2AXAADAPD/xcsmP25PCU4AAAAASUVORK5CYII="
    ),
    "ChaseTookTooLong.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAsoAAABQCAIAAACPlsQbAAAfkElEQVR42u2deVhTx/r4kwABRBZRAWVHRAi4gUXFpaK4lGoRL9QF"
        "N6xFXFqtcsVr7SPVa7VXq+JVtNQqdbve607rAoqIUBQRURCogShLEAgo+xJIwvePPA8/fnJmcnJyssH7+TPnzLxn5n3PmTcz77zD"
        "YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACA6mHSWJeJiQmHw3F0dLSwsDAyMtLV1RUK"
        "hbW1tW/fvuVyuUVFRRKJBHocAAAAAABZ7gmTOWnSpJ9++ik3N1cikXSiaWxsTEhI+Prrr4cOHUpZHKryO3fugC4AAN4jAAwD0HrY"
        "bHZYWNhff/3VKSdisfjGjRsTJ04E6wcAGEUAMAwA+H/Mnz//9evXnYpx9epVe3t7sH4AgFEEAMMAehm68hYwMTE5ceLE4sWLFZcd"
        "GBjo5+e3bt26c+fOgSYACkRFRRH+XlRUBEYFWgYAQGtwcnJ69epVJ93s2bOHySQVZArONQD20Nf6DbQMXQ1oIyzyt7q4uKSlpbm4"
        "uND+ENu3bz9y5AgoAwAAAAD6lnthY2Nz//79IUOGKOk5NmzYEBkZCfoAAAAAgF4AqdgLfX3969evW1tby7xTKBRmZ2fn5+cLBIKO"
        "jg5jY2NbW9sxY8YMGzZMZtkffvjh8ePHKSkpoBUAAAAA6P3uxb59+7y8vPD3ZGRkREdHx8fHNzc397zq4OCwYsWKr776auDAgaga"
        "WCzW6dOn3d3dW1tbQTEAAAAA0JuZMGECPl+WQCAIDg4mU5WpqemJEyfwYZ6oKHEpEHkEgD30tX4DLUNXA9qIjNgLJpMZHR2N2dbx"
        "/PnzsWPHXrp0iYyw+vr68PDwNWvWdHZ2ou7ZvHmzqakpKAYAAAAAeq17ERAQ4O3tjbqal5c3ffr08vJyuUTGxsZu2bIFddXY2Hjl"
        "ypWgGAAAAADQXmTEXmzduhV1qb6+ft68ebW1tRSkHjp0aObMmZ988gnh1eXLl0dHRyvYMCsrq+DgYF9fXw8Pj6FDh/br16+jo6Om"
        "pobL5aalpV29ejU7O5uuTrSyspo1a9akSZM4HI69vf2gQYMMDAxEIlFjY2NVVVVhYeHz58/T0tJSU1Pb2toUF2dvbz9z5kxvb28O"
        "h2NnZycVJ5FIWlpaBALBmzdvpOISExNpjGJxcnLy9/efOHEih8OxsbExNTXV09NrbW0VCAQ8Hu/Zs2cpKSlJSUnKjpvBzHt1Z/bs"
        "2YR3kkyv0oWDg8Ps2bN9fHw4HI6tra2ZmRmbzW5vb6+trS0rK8vPz09PT09ISCgpKaG9pWoULRM7O7vHjx+j9pEJBIKJEye+fv0a"
        "tKzVWtb8BqLsJDg4+PLly91/cXV1/dvf/ib9RFtYWBgYGLS3t1dWVubn56empl6+fLmwsJCW9urp6c2cOdPf33/cuHFOTk7m5uYs"
        "FquxsbGkpOTZs2fx8fHx8fEikah7kaamJiMjo55VJSQkzJkzp9e6HiNHjsQESaxevVqRyl1dXTEhHTY2Nih7krk0aGZmFhMT097e"
        "jg/ySE1NpXbuSfevWGBg4L179/CxKV00NDT8/PPPlBOH6OrqLlu27PHjxySTlTU2NsbExMibdv3D2S0WKzg4OD09nWQDT5w44ezs"
        "rFT3QhHkanVaWhrJalNTU4ODg1ksluINVI1oRZbYzczMXr58iaqhubkZM98JWla7aOUZhuaYcVBQUNc97u7ut27dkvkAv//+u5ub"
        "myJdZ2houHXr1srKSrygoqKigICAD9yLvhjvsnfvXlQfPX/+XHFbx2g9JCSEmvWPHj26pKSEpE1LJJKoqCh5/+tI8fLyyszMpPDt"
        "E4vFR48eNTExkUvcrFmzuFwuBXGtra0RERHUlOXp6fn06VN5JXZ0dBw8eLBfv35a6l54e3tnZ2dTqDwrK2vcuHGKtE5loimPImw2"
        "+/79+6jiIpFo7ty5oGWNFa0a90LtZtzlXqxZs0YoFJKULhQKw8PDqfXblClTeDwe+ZbGxMTo6ur2afciPz8f1TuLFi1SvH5pjCch"
        "qMURvPVzOJz379/La9P//ve/5X3yr7/+uqOjQ5EvYFFREcl/+Uwmc8+ePQp+cC9duqSvry9XGzdu3KhIG/Py8oYPH6517sW2bdtE"
        "IhHl+kUiUUREBLWmqVI0tVGEyWSePXsW8wxr1qwBLWusaNW4F5pgxlL3YsuWLRQeYMeOHfJ2WlhYGIUm//bbb33XvRgyZAiqX969"
        "e6enp6e4CCcnpzgE33zzjbzWb2BgUFBQQM2mw8LCyD+24oO9FD6fj1oD6s6RI0doEXft2jXycxgHDx5UXKJAIBg5cqS2uBcsFuuX"
        "X36hpauPHTsm15SY6kVTG0V2796NPzkItKyZolXjXmiOGQcFBc2YMYPkmjV+bUWRP8ky2bRpUx91Lz7//HNUp8TFxanrqTDWv337"
        "dspqbmxsJJOTlMFghIeH03iWW2pqKn7IX7lyJY3ivvvuOzJt/P777+mSWFFRYWtrqxXuRXR0NI1dfeDAAfKNUr1oCqPI6tWrMULP"
        "nj1L44AHWqZXtGrcC80x40WLFily9GZNTQ0m/WN3pk2bpshUTVtbm4uLS190L3bt2oXqlGXLlmmae1FTU1NfX99zbCssLKypqSHp"
        "L8uUPnz48La2NplV1dbWFhUVvX79uqWlRebNq1atQokzMTEh8/BNTU08Ho/H46HMtHtUxIgRI/BtnD9/PpkJzJKSEi6XS2YpKi0t"
        "TUdHhy4D+Ov/ByW0paXlLyJQ1S5dupSMkVRVVXG53PLycjI3L1myhEyL1CJa3lFkzpw5mJWypKQkNptN42sOWqZRtGrcC40y4+Li"
        "4g9+kUgk5eXlRUVFdXV1ZET/61//ktlXxsbGZWVlMquSSCR8Pp/L5VZVVfW8yuVyxWJxn3MvLl++jOovZRyaSuPfmuzs7CVLlpiZ"
        "mXWVcnR03LFjR0NDA36Q7t+/P1769evXMTUUFhaGhYUNHTq0+2zhuHHj8MvVXC4X9bdv/fr1eCdm586drq6uXcWZTCaHw9m/fz/G"
        "Bzp//jymgYMGDaqursYIjY+Pnz17toGBQVcROzu7LVu28Pl8TKl169Zp7FIxg8EYOnRoT9/0gziS0NDQQYMGdRUZMGDA0qVLc3Jy"
        "MKXq6uqsrKw0U7Rc/TZmzJjGxkZUkZycHGXnwQMtUxatmq7WNDPuTkZGRlBQkLGxcVcpZ2fn3bt3Nzc340V3/8oRsn//frzoBw8e"
        "BAYGdhc9ePDgL774guTMSm92L1DbItrb22n8M0q7exEVFYV6PCcnJ3xwL37Jzc3NDVP2119/xcROrlq1ClN27NixhKUSExNRRTIz"
        "My0tLVHiPDw8UON9e3u7ubk5qmBMTAzmfZs/fz5mouXixYuYIAzCjd0aMvD89ttvGO0cPnwYFWmkq6uL/8ScOnVKM0WT7zdbW1uM"
        "70gyfgi0rC7RqulqTTPjLr799lvU6rObm1tpaSmm7GeffYYRbWlp2draipnfXb9+Paosm80+evRon3YvUNs7FcmWo2z3YteuXfji"
        "I0aMwNgEfgvJvn37UAXPnTsnc+H5woUL+ACfnqC2UAuFQpnfdE9PT9RsNmrTr7W1NSpZSENDg6enJ14ik8k8d+4cqo1r167VzIHH"
        "2dkZNTnZ2dn5008/yawB830Ui8VOTk4aKJpkv5mammJSXNTV1Xl4eKjxrQct40Wrpqs10IxJhpqNHj0akx7p0KFDmLI7d+7EiCaT"
        "ePr48eN9171ALSU8efJEM92LnJycrp3E1Ez54cOHmIKjRo1avnx5VFRUXFzcw4cP+Xy+NDL53bt3ZCaHp02bhpJ74sQJwiKooKHU"
        "1FQyfdXdfEUiUVlZ2aNHjy5duhQYGEh4P2ZHDMlQaiMjI5RX+uzZM80ceDB7ZB4/fkxmok5HR+fRo0cUItTUKJpMv+np6d29exd1"
        "Z3t7+4wZM9T71oOWaY/xpNDVGmjGnZ2dL168ICMaE46akpKCKYiZCO/acYqHzWZjUj/0cvcC5dYlJSVppntBMuDU3d0dVUNZWZlc"
        "D8Nms11dXUnuvTQxMUHJvXr1KmERVEKYR48ekZFob28fFBQ0YcIEGxsbmY4Xk8lETRUmJCSQ75O1a9eimung4KBpAw+LxcJk2SOf"
        "1NXHxwdVSWVlJeH0rBpFk+k3JpOJn/FWZXw3aJmallXQ1Zppxp2dnUuXLiUjd/To0RSGA8xCeVtbGypZfk8CAwP7qHuhmW3GzKF1"
        "j+XEg4pebGlpUd6T6+rqoh7+9u3bhEXevHmD2gDi6OhI7+NhXjPU0TCEmJubo2ZKMXtk1GWl3t7emD9ecj0JJlk7YZJsNYom029R"
        "UVGYD9/27du16FvUZ7Wsgq7WTDMWi8Ukw42ZTCZq+xtmOMDkurh48SL5JrNYLMwmml7gXiDd3o6ODsLfaUmoRTs8Hq+uro78zYS/"
        "ywwVVoQJEyZgTJzw96dPn6I8lRs3bgwbNozGx5s2bRrh721tbXLNV71//x51OJCy8xlT4OOPP0Zd+uBIJJlg7ieUokbRMgkNDd25"
        "cyfqamxs7A8//KBF3zjQcq/sW/wXvr6+nqQ7hfpeYYYDLy8v1KUrV66Qf06JRBIfH8/ovSDdC9TZnt232WgOFRUV5G9uaGiQa5hX"
        "ECsrq/DwcLnMTqaljhw5Mi8v79SpU9OnT6cl5QDqhSkoKGhvb5erqrdv3xL+zuFwNM1sUHt2GAzGvXv35KoKcz+hFDWKxjNz5szY"
        "2FjU1Zs3b2JC4jUT0HKv7Fu6hgOUI4IZDjCpGUgGxnWRlpbWi90L5JJ8bW0toSdBMp2ZipHrHHCJRKKMZzAzM3N2dra2tra2trax"
        "sbGzs3NwcHB0dOyeCUNe94LH46FmKfT19UNDQ0NDQ1tbW7OysjIyMjIzMzMyMoqLiynIQr0wY8eO7SR9BCUeetN30gKq1UKhMC8v"
        "T66q8vLyhEIh4eZkQilqFI1h9uzZs2fPRl3NzMz8/PPPPzhOWvMBLffKvlXjcGBnZ0f4e3V1dWVlpbyt7ovuhUAgIOxEGxsbFoul"
        "pBFauzAwMJg6deqUKVO8vb1Hjx6NSURBjY6Oji+++OLevXv4wExDQ8PJkydPnjy5S3GZmZnp6enJyckZGRkkNaWCsb97Uh0NAeX5"
        "8fl81OIgRll8Pp/QFySUokbRlMnPz1dqfBJoWRO0rC19q0ZQnzJ5NwdQK6JFIBdHSkpKCH9ns9m0xxVqHWPGjDl9+rRAIEhISNix"
        "Y8esWbNo9y2kpKSkrFixQiwWky9iYWHx6aef7tmzJz09vby8/ODBg2SiNAYMGKDsTlPSEe2KgMowJu9fEHwpQilqFE2ZFStWBAcH"
        "a93bClrulX2rRgwNDQl/Ry27Y2hqauqL7kVBQQHqEo2BylrH4MGDz58/n52dvXLlStWEoVy4cGHGjBlv3ryhUNbKyuqbb7559epV"
        "bGws/hVValirFDJZSVQMKmxFrslVmaUIpahRtCLExsaiZoY1FtByr+xbNYL6lFFYN5Trr2PvcS9yc3NRl1SWTkfTGD169IsXLyic"
        "JFRfX3/8+HFF5jDc3d23bNlCbSZNR0fnyy+/zMnJwURI9c3VLlSrqXlCqFKEXxA1ilYEMzOzs2fPqvFYANCyRg1Rvb6BhKDWfSgc"
        "fYCaCOkdII0AEwH72Wef6erqKh7hZWZmNmfOHMJLlZWVDx480Kiesre3v3v37uDBg8k4pKWlpVwu96+//srPz8/Kynr+/LlYLFYk"
        "MXZra+vBgwejo6OnTZs2b9686dOne3h4yLXVxdraOikpycfHh/BIyZaWFs3cE6RUmpubTUxMev5OrStQpQjjFdQoWkGmTp26ffv2"
        "3bt3g5Z7sZY1v2/VSGNjI+FkMIUYESWtqmu6e1FRUcHlcglDdgcPHjxv3rxr164pKNvf3x91gOcvv/yiae7F6dOnMb5FW1vbjRs3"
        "bt26lZGRwePxlBRdLxaLk5KSpIkoTExMvLy8vL29P/roI29vbzKxmQMGDDh//ry3t3fPfwPv3r0jfLcfPHjg6+vbW61fIBAQfhyp"
        "HdOFKiUQCDRKNBnOnTvn5+eHOq9y586dd+/elTdvEmhZ07Ss1X2rXosidC9sbGwMDQ3lWhgaPnx4L3YvcNlkr1+/jroUGRmpeJaI"
        "gIAA1CX1nmzSE19fX8woe/r0aTs7u0WLFp05c+bVq1eq2bnX0NCQnJz8448/BgUF2dnZDRkyJCAgIDo6GpV2Qoqnpydht6MiecnM"
        "1mgvqFZbWlrKuwF74MCBqD8ihFLUKFomly5dWrlyZWhoKOoGHR2dCxcuEI4roGVt0bK2960aQW3+19HR+eijj+SqCpNusZe7F6ip"
        "BQaDMX78+EWLFiki2M7ObsGCBair8qZkUTaYeItDhw6tWrWquroaX4OScnZ1UVlZGR8fv2nTJnt7+/Xr16OyojEYDELF5efno5xr"
        "TYurohHMpnMfHx+5qsLcTyhFjaLxJCQkLF26VCwW37lz58iRI6jbHB0djx07BlrWUi33gr5VIy9fvkRdQh0YiWLevHl91L3IycnB"
        "zH8eOXJEke3IBw4cQAXyZGVlUcsNpTxQPmZjY6PMY39VPA0gEoliYmIwzh+hf52VlUV4M5vN7sX+Nca8586dS9dnglCKGkVjKCws"
        "XLBgQVee1sjISMyXdOnSpRTCnEHLatdy7+hbNZKRkYG6FBISQn4Hvqenpxozrqof/JFuGRkZFGJlGQxGWFgYptrw8HBUQVpOf7lz"
        "5w6qHlSRxsZGwvvJp3RdsGCB4g/fv39/8ie3FRQUEIoTCoWEf0ZRj3fy5EmNtU8Fu9TS0lIikRDW8P79e/K2bWRkhDoYSSwWE075"
        "qlG0XP02cuTItrY21P319fUqyIIDWqamZRV0tbaYMb3Dgbm5uUgkQpWKiooiP1PYR09MlcJkMp8+fYrpgj///FPe/+UrV67E6EYg"
        "EGC8P3XZE+r+5ORkkkITExPlevjVq1dHRUXFxMRcvXo1PT2dx+M1NTV1dnbeunWLpMSkpCRCcajQkOfPnxPe397eLlf80Y8//lhY"
        "WHj//v24uLh//vOfa9as+eSTTzw8PJSxVI/q0sTERJI1PHz4EFVJZGQkyUoiIyMpWIgaRctlihs3bsR/AZSd0QS0TE20ajw5bTFj"
        "GocDfKmOjg4yuRs2b97ciaX3uxcMBmPSpEko/1RKWVkZyTO7TU1NY2Ji8H2KPzBJXfYkFAoJ76+pqSFzhGxISIi8ZvTy5UuUL+/q"
        "6ipTIpvNFggEhDWgYj8xo8jjx49J5t1ycXFpbW0lrOTbb7+l3ThRlola6+nJsmXLUK1ubm52c3OTWYObm1tzczOqEszygRpFy2WK"
        "TCYT88rI9XcNtKxK0apxL7TFjOl1L+bNm4d5I5qbm4OCglBlWSzWP/7xj05ZyGwFi8Xy8/OLjIyMjIz08/NjsVgkm6z6gjiOHj0q"
        "sy9SUlKCgoJQSUKcnJx27txZU1ODr+TZs2f4jD3qsqeSkhJUkU2bNuHFffrpp5jpZdTDR0dHo+7PzMzs378/Xui+fftQxW/fvk1Y"
        "xNjYGDU/KS0lU6itrS2Xy0XVMGLECNoHnoaGBtQCEMlVJD09veLiYtQzv3nzxsHBAVPc3t7+zZs3mOIY71ONouV9j4YMGVJdXY0q"
        "JRaLJ02apDz3ArRMTbRq3AstMmMa3QuZ8/rSmWZ/f//uk/Hm5uYhISFZWVmdJMC3wtnZOTs7+4PRk8z5D6ovKAMDA4MXL16Q6ZG2"
        "tra0tLSTJ0/u3bt3165dhw4dunz5Mo/HI1O2ublZ5v9yddnT77//jioiEom2bdtGuL3CwsLiyJEj+Lkf1MNPnDgRUyQnJwcVcWlp"
        "aXnq1Clq80P4+bqioqIFCxYQeqx6enrS7TOostJcHbSTk5ODCRkhuVtnyZIlmFYLBIKFCxf2rIrJZAYFBaGmiKTI3F2lLtEU3qOA"
        "gACMuOLiYlNTUyW5F6BlyqJV4F5olxnT5V4wGAwfHx+Z33ap811WVsblcisrKwmjlyi0wtLSks/n9yzC5/PxsQoqLkh2t6Sdnd2T"
        "J0+Ul2JMakn/+9//ZN5G+HtCQgIqASihPaFOnUZ9qtauXRsTE4Ops6qqKj4+Picn5/379wYGBra2thMmTPD19SU8X5jkw6empnad"
        "g0rIs2fPkpKSioqKGhsbDQwMbGxsxo8fP3PmTMxW0traWgcHB9TRO3p6ek+ePBkzZgxGKJ/PT0xMzM3NrampkZrdqFGj5syZY2Fh"
        "gdHa5MmT09PTaTeb2NjYL7/8EnU1MzPzypUr5eXl+vr6w4YN+89//kOY6p7JZN6+fRtzEDmDweDxeDdv3iwoKGhoaDAyMuJwOP7+"
        "/vhzom/evCkzeF5doqm9Rz///HNYWBjq6sWLFxcvXqyMjwNombJoCt9hCoahXWas+HDQxd69e7dt26ZIb/v4+Dx69EjeVhw7dmzd"
        "unWoSxs2bEBJVH1Bsri7u2P+nioIPuRC7e7qgAEDUDO0JKmoqEhNTZXr4T09PTs6Oujt5zVr1uA7x8XFpa6ujl6hhw8fVpJXOmvW"
        "LPKP8fe//x1Vj4WFBaFvTpnS0lKMv6V20dTeIyMjo1evXmFEL1++HLSsaaJVMHuhXWZM1+wFg8HQ0dG5du0a5TYePHiQWivKy8tR"
        "pcrLyzEPrPqCcjB8+PDCwkJ6xx6RSLR69WplW7/i9hQREaFIM5csWXLx4kV5H37Lli00dvXZs2fJzCT7+vq2tLTQJfTevXv0Lg9/"
        "8PciMzOT5JPcuHEDU9XIkSPfvXtHS5Orq6vd3d3Jt0L1oim/R15eXu3t7ajiDQ0NNKzFgpbpFq0C90K7zJgu94LBYLDZbNSHHU9C"
        "QoL0w0ihFZhFGXzOaNUXlA8zM7MrV67QNfa8fft22rRpqrF+Be2JxWL98ccf1JopTR1Bwb1gMBi7du2ipasvXrxIfpifMmUKLV+K"
        "27dvU8uMQp5Ro0ah9qr0/GbhvSsPD4/S0lIFm1xcXMzhcORthYpFK/Iebdu2DfMMGRkZyvAmQcsKilbNB1aLzJgu90Lq/n711VeY"
        "zS89uXz5ctc2CAqtwEwU4ROoq74gFYKCgjCbKcggFotPnDhBeDCMxtqToaEhJsYTxX//+19pYgBq7gWDwQgJCcFEAMmktbV18+bN"
        "8mYlt7Ozu3//PmWhHR0d33//vWpO7p47dy5+b04XMnevDBw48Pr165RbffXqVXlNWi2iFXmPWCxWcnIy5kn27NkDWtZA0ar5wGqL"
        "GdPoXkixtrY+duyYTCejrKxs+fLl3b/GFFpx/Phx/IKL5hSkiL6+/vr16ymslQiFwjNnzlBzwNVuTywWa+PGjSQH+5aWloiIiK6t"
        "FpTdC6ntnjx5Ut5QjI6Ojri4OMp5FZlM5qJFi1DZP1FIJJIrV66Q2e9OI15eXqhMId1ZtWoVmdoCAgLI1Nad3NxcWo4PUI1oBd8j"
        "W1vb2tpazD8HuaYkQcuqFK2CD6y2mDG97oUUY2PjxYsXnzx58unTpzU1NSKRSCKR1NfX5+bmnjlzZuHChT2D/Sm0wtLSkjAYorS0"
        "FH+SnOoLKros+vHHHx8+fDgvLw+/S6e+vv6PP/4IDw9X5Gk0xJ7Mzc23bt2KSnMpXfTZv3//B2eyKOJeSLGysoqIiHj48CEqzVeX"
        "A5eSkrJ582bUgdryqtjPz+/kyZP40C2xWJyZmfndd9/ht7krD11d3cWLF9+7dw8VHNDW1rZ161a5Wn369OmKigr86t6vv/46Y8YM"
        "Go+sU4Foxd+jhQsX4v+iKelPNmhZK9wLbTFj2t0LCr1ErRUuLi4fDECZmZlOTk4yJaqyIJ0ma2pq6ubm5uTkZGlpaWhoqKenJxQK"
        "a2tr+Xw+l8vl8XgSiYTRu7CwsPD09HR0dDQ3N9fR0Wlubi4vL8/NzS0oKFBqY/X19V1dXZ2dnYcMGWJsbMxms0UiUUNDQ0VFRVFR"
        "UUFBAeHBIopjY2Pj7u5ua2s7cOBAfX19iUTS1NQkEAh4PF5eXl5TU5MmKMXIyMjT03P48OGDBg0yNDRsb2+vrq5+9epVZmYm5iBZ"
        "DI6OjhwOx9bWdsCAAXp6eu3t7XV1daWlpfn5+co+e0+NojUc0LIWAWaMol+/fs3NzYSXbt++7e/vj59Knz59upeXF4PBePr0aXJy"
        "MslBR/UFAQAAAABQHa6urpigPW1vHQsUDAAAAACKwGQyXV1d5T2GY+rUqahLfD4fehUAAAAA+hxsNnv8+PERERHXr1+X5pyUK38l"
        "/uCS0NBQ6GEAAAAA6EOsWLEiOTm5Z/pBoVDo6+tLshLMMfSdnZ2Ud/wBAAAAAKCVrF27FpNnKDw8HL9KYmhoeODAAYxvoYwTmgAA"
        "AAAA0GiMjIwIT0DtIi8vb8OGDc7Ozt033Orq6o4ZMyYqKurt27f4LCCBgYHQyQAAAADQ5wgJCSGZNLmkpITL5ZaVlWHO6+lOYmKi"
        "atKcAAAAAACgccTFxXXSTWlpqaWlJfQtAAAAAPRR2Gw2hVOoMJSXl8s8MQcAAAAAgF6Orq7u4cOHafEt/vzzT2tra+hSAAAAAAAY"
        "DAZjxowZ8h7h1h2BQLBhwwbVnC8NAAAAAIDWwGKx5s+ff/fuXbFYTP5w6bS0tLCwMCMjo17ZJxCeCgAAAAD0MHjwYD8/vwkTJnA4"
        "HHt7+0GDBhkbG+vq6opEosbGxqqqquLi4oKCgoyMjAcPHlRVVUGPAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAAACt/B8+Gbolj4zezQAAAABJRU5ErkJggg=="
    ),
    "ZeninElite.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAVcAAAAnCAIAAAA0Bpw6AAApdUlEQVR42rV9fXQV1bX43mdmbnJvcvNJCBDQJCQkoShasKhYRe1T"
        "sKjFn78uFyoLf8/Kz74u2/oTWF2+StF+iG39erLs8+OJ1YItasWPipQHKFBQQUURAgSIfEO+yE1yk9yZOfv3x9yZe2bmzNyb1Dfr"
        "rqybuWfvc84+5+yzv84+ePv5+QAASABAkHlQ+MvdL52HZC+9D9m/D7eKLPj9FcqqIOH9kKqggF5nqrBLEFC6s+gq0jmYYgoCJ6tY"
        "iRYRoZGAUIBAcNCIvfBQydOLnAYivBf/w1X8TwyEvwq0Xwa1lr5uKqF/slMOVQjzJHxFDLML7nlIMvwilVh4/0noPPrI4Xkvfs8M"
        "NtKwq/BTQV5FtlEkARv6Zom03hzxO2Up0z4SeB8iIDK0VzwiovXSKeNiARBYpb/BuXQhh15QyKL1VMGCqURh60dShacLuQwEZlui"
        "0i54vmefrrnNqMDpSnIqSarwsQD/UkfZzB9qF8jHIMgHrgov5TzGw7wplDHLt01PFYSAJBbmssk3tCp87MnDSrmbuBQ6AFk3BN/s"
        "ttY1AgGgTaT0IicfCm8nyNdPkUrgoxIELw/PSFH4nkboqZrnTA3MhUrpLmA4NpKSNLdtGQm5e5vh2aD8NKFsO7+HyNw3V7POU5Kt"
        "CHRzQ/+Kwxy6IJen7JmD/pGScR811zVGBACECAE7RtAooq8A2iSQ4Le2z6FUgQG/on9HyqxNDMGfy26AAnPLLCRyFryHiRMBcgJG"
        "hIiZpgiqko2EMkqGTSVhMXu6YBVAlC1OCl1NZEHZTCBThc12CF3Shr8KkjGdoXchbBSCq8iMAmXpAuQ+0NLViFLY9FrIdMGtjNDQ"
        "uhCw1iRdQDd2mUCdMyclh2EAAEPPsguXg4i8HAuzaykYvpEGEyrHxYmyfwPxU+7ScjB+QvLs4UTWLsE9ShAB58A5cQKTgAQCiqWQ"
        "XNNJ3gXydCGtfgyxC5hmtOSBJXDtHxmZdIijYHeBMIcuDG2gs48yDdl8EaJEyPidvIphzKLgVg7DAhNYI4awALcsYEmxJGdLzmxA"
        "h0W5JAYi+dhgMH3dlLX7bM0ZTh6+QsHDj4I8iRnJnCQj51SRBnB3AbJ3wd78MS3hO3YXZ6ojAgAjMkkmOyACEQKY3OHp1jLMmAbQ"
        "TS8fiWw4Tn6+nXsXMiTKmI7sbQHTRk4OxIaOX9QCQBBKvaNMxIEY5NoFCJ1FnODsAJmcymPI0CGRQ2McRhecUXYvB38XQpqKGDx7"
        "0W551wAZnMpjjKHH4OCzIfjWmiMOksz2EaAfUYC1DVTKmDblDCWp865+B57Koiyq5cpZ3RpOiJrj8BoSlyjmUEu/Tp39jraFZTHI"
        "1zBYkCcToG8QBgzOifJVFlUhX80yIylYpXTa0JsinYPGIB4BRWUBXBkxPb0yVOk3qHeQdA4aQlEey1elFh1h5AUSWbAGB5VBUR46"
        "HQlT5oX5ndSpq5/czbHFPUSpVa4sijEN/ftEFn3EYTgWrxR4knSQ/bPRbioAYVkMYhoSQFc/ffCV3jNIAFCg4YwatTTqzCIM306l"
        "RgHbVuJtflKnrn7BGpC2dcgXjabAyAKrEZAUJmeaeiojgK4B/sFXesJqeQRnVGulUaEV7umPARs9UaCVPbts4t4IVf+OSu7+v7FX"
        "58IrBWHOxEhUDVTqEL1My8ZPAZRD93aXTcK3i3OC3WfM3acN09c898JGAOKEh7rMI2f56V7u2a5L8vGcYtYwQvGzAwilqcFhX7vZ"
        "0mlaE9F5ivKwrkyZUK6oSrrLKoKByOx1QIAGp31t5sEuM+GGLc7D8WVKwwhFYUITXMoDWvUe7AyE1ZiEHQuGTEKAPp3e2JviQ5TF"
        "GcKcpkiBi88iBvsX7Gkt7MyuIcZc6NzvbqrVhjwVP/hKv/La65955hkAuOuuuza999b1DRHLCYOh44gyb2WQ9p4cOqEaRijfqlKT"
        "Ov3VDaggzGnKy1fhg6/0GdKWi/wOCAHKohjVJIsCKExuCrB/o19aSZPU878HsqufOAHZj2EYJkFXP7mrdxnESBDJ0acFUqAyGaL7"
        "SfCf6uVv7Uu19hc88R9PmaYpbZ4DdaKH3mpO7emO3XDrXX9d82Zra+vAwIBpmu3t7du2bVv0wK/6i2rXNKf2d5gQ7L/1tLytj7/Z"
        "nDpJI366+OcffvhhIpHgnCcSie3bt/940b8f0Uve3JfqSBIAMntUFCQNidKw+kkY8RMf7D2L/v2IXrKm2YKVjJ9TbxDsm82ptmR2"
        "v49nZHN8OEFnPwWRSGZtwaFqy/4h6HQ31WpDVz/1DNKzzz5bWVlZWVn5zDPPJAapa4CGij/oVwpYAlmfX/ziF+19HHzNTk/OAd7Z"
        "T4mAllscZ+Nh3fpsOKz/dW+q36BA6SrAD0rB1gFwyeZpkUmFAFdteHCCm9kgeCVKz9xAdHPYIMYvjWrwuE/7Ddp5wjzUZd5yyy2P"
        "PfbYqFGjwjfwlk7zw2PG3Xf/8Ne//nVxcbFYrLy8vLy8/OKLL160aNHy5csXLlyYMsxJlYq8YYTOXnq6l284pN96+7ynnnoqHo87"
        "xeLx+LRp06ZNm3bffffdfffdf1618urxmqqizoFz0gE0BYYEW1nARELlDvud8drIAiZpP9LXY3qSyJiSjR2zcVXKWfLK5TE5YbBO"
        "7hdUg9qfKw/7+h6TEwA6HCf90jRVVe3qp1iceQiEPqMGC/YaBLDsjJ7G0G3qxmA3ZtCKRYnR1xXk4B8Uf+RDwMil+4KYZgrHe/ia"
        "5hSUnrt27dpVq1ZJWYD4nOrl248aTz21fPny5R4WID6Kotxzzz2vvfba5210tJvLZ4Dd0KQO77fqC+7+4YsvviguRZdSUFT0pz/9"
        "6V9/cNf7rcaATiYQIOgEidQQYQ2yq8WkTrnDbmo1Bg3ZABICDXNu79u3DwDylGwrhFBGtjB3AwabgYOe0igWRnDBggVnzpw5c+bM"
        "XXfdFdOwPMak1qDMrkZhO+TXuPJD8JfJWj4ixnJabLJ3QTZUzC4TIQAgEt4+Od+zS4ty3fEE33hY9zCnq2u1qjgjt7mSCNr6eIpn"
        "TCfl+ZiveaWKjiT1C7OzNB8LIlm0cUcvQMC1Lfr0a25cuXJlfn6+9WsqlYpEIp7mjYkrlurw7oHUrJtufemllxzMH3zwwfPPP79r"
        "166BgYHa2tp58+bdcsstzq933333Kyv+84aGSMCURQD4oFUvrTnv448/VtW0JLVp06Zly5a1trbW19ffd999l19+ufVe1/UpU6Z0"
        "HPni/DGgAhgEnx6H0eMvyB2279ie6eekS37QqpfWnD88WO/6ROoepDebU3V1dSFzr7Gxcc2aNYwxAOCcT58+/dAXH11TpzEfyyaC"
        "xCD16wAAeSoW5QNDyeQTrWWO0osASZ36dDI5xDQsjKSDLR38x9yTEBGvrNGqipg1OR3kV9ZoY4uYZUfo8NUCAAMG9aVI51CgYTyC"
        "kuhfJL893VM757yhoSGEaJ2dnSV09rJztGMJvkG2dsbE2TFfy6uK2Jk+3trF93eYHpCGEcqYOCuPYiyCmWbZprHEYHpB5atYlIcK"
        "ZpGw0MMCgABBhUzwM3ocf5hFdxKEDoK9beaOE4ZYJk+B7zVGImqm5S2d5rajrjIqgzlNkaxWeqcik9PkyZMdFvDee+/927/9W0tL"
        "i7SBSZ06knTPPfc4b3/3u98tXLhwVCEbWYAFDPduOzB37bt79ux58MEHrQILFiz4wx/+0JOieCQTAyi45qh7kL7qNp/77W+dpfjq"
        "q6/ecsstYwppRJTt3LT/qr/9bfXq1XPmzAEATdN++9vfzpo5s34EFEUgqcPpHnh5SLCzZp4/SolHsHuQvurm/nqrCqk8FgZbGEGv"
        "D882JV5bp3UkW6Xje6KHn07iyy+/bLEAAHj00Ud3fLR99oSIh6939tOeNuNYN9cFr5TCYHQha6pQKgsZCizAYy1jCJNHqR4zZ1TF"
        "ujJ2XqVq2UcDTYYGfdCqi2/eb9XnNEUAIPdaJlWqiuO0RJLKEd6XRC0tLRPKlaI8BIlDnioK8NxibagtrylhB7u4XARrN/e1mwxh"
        "TlNeTLNiiaizn75sM491m36yT6xQKguZXy2wjzhY2zRlJHgr6hnJZaWj0PMYErIAEIDBoa6uzrGF6LoejZccTXCRRC2d5g9/+EOn"
        "zMaNGw0OoXIlCQYCEmMdjh8//v3vf3/mzJkHDx70D55VrneQACAajR60n4ceemjKGPVfxmuTR6kTRyrfPlebOkZ94oknMtbdhgYA"
        "6E0RZfSrjJmCAA51mg0NDd/5znes8olEYsGCBQ1lMKNa+0alclWtWlcCCxYs6O3ttQpce+21dfX1x7uBAI53gx92QhlcUa1NqmRX"
        "12rjS32wdfWHOk0AOBxQ7xXV2qSRytW1Wl0wrDPLSRxcwpEFrKlC8X+qS1hHkt97773Tpk2zQJubm3/+859fOFotzEMSyLHjhPHO"
        "/lT1BVc898KLBw8eHBwcNAzj6NGjf1n92sXX3PTfh82tR3STZ/iFx1rGCfZ0KgvuuW/Hjh19fX26rh86dOj3Ty7viY1750CqJ0Uh"
        "OunZfjIJDMPwWA2HVMvfDqR6UyROm5zO2ACMK06TrrFCaaxgjRWsMf1drStTIkrY9tkla/mZJP3iF7+w/hUVVXfvuLUOdpww3t6f"
        "qr7gcinZ1x82txzRObd8M+hRHGQB7cgwEzJCmLNphgAIUYxwPKeEtbS0fPzxx+lNXlVnzZp1tJvbPggcNKi9j773ve85IKtWrRpZ"
        "wCyno8cW6AnwsxciEoBhGE888URTU9Pf33r1GyOVkBaWRVm+iuedd16d/aSSPXVlioh/wCBHsgAAaxVpDN0KXsY6eaKHW/ut9axc"
        "ubKnu/P8UapNXJw8Wu3qaPvLX/7ilJkzZ057HwBAey/4YSdXqo6cd8EoCeyJHm4ZRKT1Om8mB8BimMdYInkRwLZjRn3TpF/+8peO"
        "XDpv3rxiNdUwQhEjWN7/Sj+px19//fUNGzbMmzevtrY2EokoijJ27Nibbrpp9erV27dvN+Nj//uQbgZMq5KSkq1btz7yyCNTpkyJ"
        "xWKqqtbU1Nx99927d++ecumVmw7rnL4GLT1rLSb9k3YBO+YLM/Yxgv+Rhwg2faWfyIHs6w/pnKxQR3FLk/oaMhFQVlEUrIOUpTOU"
        "PhNklS/Jw7Iorly50vn9+uuvP9nLeXoroGMJXhiPX3HFFY7u+uqrr9aUMi53bGSiTVGwjcQ0fOSRR+679yf1hf2zJ0QqC5g0nsJq"
        "v6bAnImRGxrFj3Y0YTa3mc1txuenjHUH9d1n+K9+9SsH9s0331QZlET9HloCO97r0ksvdd6uW7euKs6sKCGrnXkMRsfZ2rVrnTKX"
        "XXZZYgBMDolB8MNqSoZH5ykS2M5+Mri8Xi0zehgJgOUkN/16hD6n1MFO83SSrVixwrG2LFu27NOdH18yThUtUrtOGWd5wfvvvy/y"
        "Js9z0UUXbd68mRVVfuJWFR31fvny5VOmTPH/VFBQ8Nprr+UVj9zbZmYN+wn/Jfda0HdEjwfX0p6k4wlufY7ZX453m6f7KJyV/HNM"
        "DYdE9h0nDJIEpKO4wK33DFwLnhxZCHNrsFioplT585//7Kz7WbNmAVNP9nKLYxxN8FmzZjlza+3atV1dnecWM5C7mtEf24AAF49T"
        "LxzJb2iMTBqpsOBtzrFMKQhFeeh8Pjtl7kkUno1Vn43VKGPOn/m/bt+8efOdd95pgR06dOj+++9vGKEo6PFpWToTJVNEBI2NjU5N"
        "X3zxRVmUOWwUCQipPMZ27drllJkwYQIn6OoHKayNPD1aI2SwbX08qF4UIgKl9famKOgwrH/lJHXaecJYvHixs2x279794IMPfnO0"
        "WhjJyJY9g/Rlm/nUU0+df/756VXR3r5w4cIpU6ZMmjTpjjvuOHDgQFpCPOecp59+el+H2ZPyLijG2Ny5c7du3TpnzpympqYrr7xS"
        "3EJKSkp+9KMfHeoyCaAsigzT57IRkSGURTHHEIQca7HnPOS4k+86ZWw4rFufjZmPsa5F/+i4MQxZIKbhk08+WV9fX19f77zknNfb"
        "DwCoOGSy96bIE5rlDt5JzzpG7vXmhPtgtngB/zyqLmEnT57ctGmTQ+LLL7/8aIIjACc42cNnz54tyrRjClmeGryUZQcuoypOKGdO"
        "7FrWoANPQxMDNH/+/AMHDhw4cOCTTz5ZsWLF9OnTLUfDH//4x0suuQT72iaPUvwBC5bQbhljRffkiRMnRB+HFXwa0+DEiRPOyzFj"
        "xgBAXwqksJ5MEAUyWMusFVSvs8ilsP0GSZ2y0mfbUaPxG+cvWbLE+tcwjPnz55dquqULOM+edvP8yRfMmzfPsdFMnTr1D0/+3ji+"
        "K9Kx780/vzh16tTdu3dbv954440XXvjNZtmuvn79+hkzZnz0329Gu1uO7Np82623rlixwvn1uuuu6x6gAZ1iGt7UFLm6RruqRruq"
        "RpvTFIlqQ9hTnVpi3S1HA2rp13NdtqKuHhIyFMIHpD9MKFcmFCR6Tx0STd2WJTJ5+lBJsnVWnXYkwQPJ3iknuyXmkCxhAQmuA2Yf"
        "/ySX057CrIOZg2GI4hmraARHFjKR186ePftYggPAqR4OTP3ud79rve/r63vrrbdqSlmAxSGN3OOzILRO8tnvMQcq5zC4uq4//vjj"
        "DzzwwJkzZ86rVBR57AMCkGWPLSwsdAYpmUzahwYy8RMRBn19fQ64VT4VAEvoks81hn7Y0HqzwFrGOUe+DTgKgQBwoMNsG1BWrFih"
        "aemDIg8//PDnn+68ZJzqMRwc6ebz58933ixatOirr766YJQ6IsZKozi5Uk0kEgsXLnQK3HrrrSd6JHbgBx54YGwhv6pW+8ZI5dJz"
        "1fpy5fe//73zq+XFTBpAAFENq4rY2CI2tojFtKGJ1VYtV9dq3xipTD8nrJYgp9qQtXfhxHeOj8qgrlxpqpDYuZoqlKYKtaKQhZE9"
        "X072kw7Z0SsPEJKzP7Bh6C3pdDnpUGEk+4QAA6gpYa+99loqlXIYUr9O7Uk6luCXXnppWVmZo34P9PedU6ygf48SDthR+uSsfZCe"
        "ANNH4BBch3SzCCzhe6CmaYsWLdq/f/8dd9yx6bDek7LMpJ4oaa96AnbuIMvx4trS0dU46zvnclgROQbAAgTCiiEbQbAYnMbHed+X"
        "op0njfvvv//CCy9MC727dlkuFUcXsBh0X4r6dZoxY4ZoTAGALUdsCblVt+IynALTp09PDJLfSLhjxw5nDgBBZSHbv39/RkiOxQBg"
        "0CAcwrFcybNjx45xxRnrS1AtHsHqn1HgMVsSoSGZOqw50jsIwyN7pmuC5o8ISOgktmBBMUm5dBaJEEicj9UlLNF99t1337X+ra2t"
        "nThx4tGEeSzBRe/An/70p3FFjlHNbbiyvfPW8kLnlFWau7p8GVn5rVPYKlgRw8cffxwRGWPl5eWzZ8/evHmzVTISiTz33HMXTv3W"
        "ZyeNtNUTvTmerAY73jhrDumcRI88Ihg8PbdEv4NlxZDCip2QwkYC6vUwZSmsxiTDSm7WgADbjxnnTf7m/fff78hH8+fPH5FnTChX"
        "UMwcQNCrEwCMHz/ewdbT0+OXjUWpxCqccusEpmnquq4pNusHUhk5+wfIzwQNmQVYtUQU50wnaAz8tZDLQ00QkATNo6v7nyeffLI4"
        "H0Otg0EBzGEGRQTo0/nwyN5vOG4M9J+0tIxS3jmSewI2dDYgzIxXnopj4i6l4MYbb/zitJnUyTEKdHZ2rlu3rqZE8RCehIiF9IIn"
        "L+tETwq/XMQzRIdtXDhanVmnXVWrzahWJ8QSn37w7owZM15//XXHkrRo0aIj3dzgKLNZkuXU9OjeSd17nqIvBVVVVU6ZkydPAkBU"
        "hSBYEqy1fSnyw5bky+t1z1OUwkY1lEbsk60mAMD+DrNjUH3xxRedkKSHHnroyy8+u2Sc6j/vZakYBQUFue+NVryzzkNcbSQ4g7Jr"
        "eEP3wyEiIFKOE8YJTpH4iohaWlpY1+HS/taSZGtJsrU02Vran/40FiS+VaVRWBbAQD02TABBMIZL9kEjsPvpcAIMiIyg4KySTgki"
        "13ey39SUKm+//bazcV1//fUAMHHiRMf4uXr1auTGmCLFMY+jL1WlRxAWgymc9U+hziLrc6qXf3na+PK0sfuM+eUZ81QvH1nAquJs"
        "bBGrL7cCdfBnP/uZA3jFFVdwgu5B8m86BFgQAYawd+/ejJd+8uSOJHdFOhB09vNJkyZlbGl79jCEshigDNYz06WwViIKKazjC0aE"
        "LhlsTEPykUXkHr0p2nnCWLJkiQP7ySefPPzww1PHqDENMwKkrelaEry452RXelXV8rMGbSfWmIanyqJ/SmMnyhYNk6GMe2JJp5kV"
        "NTRxpDJxpNI0UmkakQ64ckKGgs5qYJYGBP5uRVIOg+ymEyogWgLcq071azNOpCll8yxJjx+MK2bbjibfeOON2267DQCmTZtWUVHh"
        "8Q6cU8KQZciLhL2DvDdFBRGM54l7F2a0XgKw8/aFqwNkx0QnBunvBw1xYazbvft7jRG7CgSAMUVss2CVLS8vB4CUKVPfEBCxNIpb"
        "tmxxtJtrrrlmzeuvWnk+rMoNjid7+DXXXOPAbd26NZ4PeREsyiM/rM4hYksrBocTPXyxG7YsylQGZbJ6Uzwt8GMwLAbEfjgS7z+O"
        "Ghd8c+rixYut96lUav78+SOj5vgyTWohtnwTra2tDmG//e1vnzp1KnwJAkBIcpqsxravx9+OWViAO3tseu0MtcpM3sUhto0wDMzy"
        "iw2D7PE8ILSy5NtJ5nw9YjJt31ECA1UV4WSaJ+EiKAzGFmeUAsbY7Nmzb7zxRuvfY8eObdmypbaEOf3VTdh4OPXX5tTfD+lvNKe2"
        "HjFSXIYchzDWFju33D/bt2//wn4qKipaukwhAQYd63YdDuno6AAAjSEiJHU6ZseEnO7lBIBEVXG2Zs0ap/wtt9wSLyn7/JQTFYOf"
        "nzIKikrnzp3rlFmzZs3IQmQMK+IghSWb10lhrRMyo7PUC5/JYKuKmJMrTZpUr7nd7DYif/zjHxUlraA9+OCD+/Z8MW2sKpP+EBEK"
        "IiyiwJYtW5xfJk2a1NLSEu05bEnIJclW6DzcIjwHDx4cE2dRNWS+OmpgUPTHP8sIELOLAyDE26YbhTiEpIKU0XCH3M5stRTmoZzs"
        "vYfTWkkA2Qsj2cnHfCYKEnRzkvKmI91W+J3Z3G42t/HmNt7cZjS3mc1nzLY+DoQ1Jcrf//739vZ2q/yCBQsuvvhi6/srr7ySp5B1"
        "yAQJGcGHRw2t/NzNmzenUqktW7bw4nH/OKILIgDKsrPmZLWw1OkdO3Y4b3/9619/eYavP6TvOmV8cdp8r8U40sMeffRRp8DGjRsV"
        "hNJ8ltTp9T2pDYfSBth1B/XtRwwArC1VDra0OCF68Xj86aefbu6gTYf1L8+Y77fqzR30zDPPFBUVWQXefffdgwdbqkoAgKpKmR92"
        "nw27KQC2upQRgLReC3b3GXPTYb25XQJbW8qEfQnRTnlizbrEIH160njooYeampqsEjt37ly2bFl5jB05y60h3mt/9rSZe9uMtj7O"
        "kMYWKeIxzQcffHD8+PEtnTypk6VPfdVtzpw5s7Oz8/PPP3/nnXd++tOfnuzlRMNfBUEhj0NlBIBh+MFWbTlmkQGOdvO9AnHET0un"
        "aRgwZFcAZu4ycOLuFEUpKChoPct3nTI7+uRkP9jBkzqYBGcDyY5Crkx5qwLsAphh0B4bS11dHZXWnI1Wpz8x61NjfV/boicGeVUR"
        "U8hYvXq1BTVt2jTnaNqqVavOLWEOLRKD1HrWfOmlly677DJN06ZPn/7yyy8f7eY9gyQEOqBotsldIoiqWFnAHnvsMeflnXfeuXHj"
        "xstn3cxHNPKKid/93/M+/vjjmTNnOubfZcuWnVuqqIr3UMrSpUu7+jkhxPPw3BK2aNEix878/e9/f8OGDedfNrO/uO4bl1yzbt26"
        "m2++2ZGuFy9ePLoYYxoAx0KVRhfDkGCrS9KHAsPrnSiDrSlR4pG064J8yYoJYNtRY+q3Lr733nsdAXLp0qXV1dUFlbX2sFafjVV3"
        "Rau77IF+94CeGKTGEco//vGPt99+2wKsqKjYuXPn/1t8f9H4i5LFdVXnffvhR37/xhtvlJaWnnfeedddd11fX9+IGAs354bbel2x"
        "vThMsT+XLddzOsYvP1tLgJfWWGRxfWLVXbHqfX1FHx7XgzasMEMbghUKcfz4cef1L3/5y7xRDanS+o2H9QYZ2e9dfH/R+KlhZGeC"
        "eBKgceC8C/Ik3kmb7XoOV+diir2yJjKuGLcdNSqbLnH8cNazb9++xsbG6+oj5TG0rA8ne/j6Q3oqlXIiVXRdj0QiV4/XRscZElHG"
        "M47+6XIswTcckhzhHl3ELL7fluRrW/THH39CPF8c9PzoRz969g/Lr2+IFETwSDd/v9VwuPKdd9657tUXZlRrhDCQojf3pebdceez"
        "zz4bjvAHP/jBSyueu6yG5amcOCKjAQO2HIKcYZ+/vkFzjl336/TWEOp9/sYGLV8VTIOWi9g2EbT18bUtenNzc/hpef/4XlWrVcWV"
        "7Uf1s0rZtm3bRN+V9Fm/fv3MmTO/fQ5DhI2ywaoqYiGjeVWtVhVn6DP6nOjhGw7phmE4uoyVdwAA5BkxitIHlUOO/VuWJ3H9I9Gx"
        "HhKbnfVZunTpfyxbOqshcrxbkpvjqloNAGQtj4wtYkT06p7Uw7977Mc//rGIs6Wlpb6+/vqGvL1tRveQyD6OjStWMk7KACcMk7JS"
        "280+HBXMmmc1pWzr1q1HjhwRf1q5cmU8D0fE0DE6WBudKLR/+OGH1tZnMWakzN0bOefHz9x7UhFj08dpP/3JT+67774Q++rp06dv"
        "vvnm/3x6+VW1mmX9GjBI9L3v37+/yEpsSRDVcEa19sLzz82dOzeRSEgRJhKJuXPnvvD8c1dUaxEFOIHByTAhosAVQ4BV89VMx6Ma"
        "5gr7X8/NqFYt9pFJf0wuZ/UgB7BPUg9jiL81VmXJjksvvfS9994LKfnCCy/ccMMN9aUwtpgN75yd/wC/GAYSIjIMTxBAy5Ju36hE"
        "ISnKhqV8BLXQ6hFj0FShLF269MsvvxR/raurKy8vb0+a04ZI9nOKrWRiFK7isKxmy+FZdSsLWVSFV155RXy9atWqmhImIi/Kw6o4"
        "u+2227Zu3WoYxpYtW26//fZzillc8+QsHFr14qmJ2lJ2RbX2h/94tKamZuHChevXrz99+rRhGLquHzt27J133rnrrrvq6uo2/u31"
        "a8dHnFx9AzqMHj3a0RQ+++yzUuH0zqhCds14bc2rr9TX1y9ZsuSjjz6yQjh6eno++uijJUuW1NXVvfnaK/8yXhsZY5yTJVJYF5Mw"
        "Vf9ODrDX1mneE5MIlXH2LznCFrKvZygDZoaCcM14rQI6Zs6cefXVV69YsWL//v0DAwNElEgkPv3008cee+yCCy6481//T2OpPnWs"
        "iv/EGWGULLBhRfdljTEjb7g9EuFwGh5C7SzYJo1UCnj3xRdfvGTJkt27dw8ODuq6vm/fvtGjR/cMUu5kbyrRv1Wl5litTyNwc82k"
        "Tq8PJQ0zQ7ipKRLTEBA+P21+dtKbWej6hkjcnWIsZcLmI/pxOx/JuGJ22TjNCikLdA6g0Lw93mTPN7kTpYOd+ftAh3mkm7f1uXrD"
        "EEbHWXUJqy1RxMiqfxwxGi6ZaelgO3funDp16k1NkUJ3yw0Oe2WZyON5WFfGGspVy314un+QMpeiACBURvMMDs3t5kE5rNJoZxMn"
        "33FXADA4Nrcb0nrry5TGCvs+hNBR69P5X9055nMd34kRJ44AANqTtLfNONbDdXdoYGEExxWxiRVKQSStlfT75lJ6sGyOn3U0xXiB"
        "foNe35MyyTv3ACCsFpJMaatAvooArjVveaf6dXh96JnIp1WpQRUBgLTl1qqxDHL7O8wvz5i9wkHMmIZX1WjOYcpwsjdVqLm4BjIO"
        "+RAuYBXo17l4s4JwFEniRXFurbD24rY+LsaNprMM2gcBxIYlBqk3BYWRtC6QhXkJv7kufiCwL03xts35RzcxqfMBgxAhqmKBhors"
        "ltm396X+709/ZqUe+M1vfvPw0vtvbMzzXELoxDX069STsm8HiWC+5qr8dP+gyYHbp7gZwKiCDM1F2HgEQ47K+H+wYHUOmgLxCHpP"
        "2nkvNvIQhBzShW13GDC+BELiKiCCnhRZPgJNwZgGdkdc9Xpv6Yh5+5vUqTNJjlUuU52MrfX77/zQMI1kQPLeaXZS5539GWnRKiAm"
        "0QtJlxiynCyCaAwrC9MYLEBntpdFWUyT0cFqoQ9zTyp9mD2qYTzPittyX81K2JNKu2byXGTPWf4gIEDV879bf0AAimkWjTJ3OmFw"
        "EJd9b06aJCMLGLgOzJA7i5CldSEAxfNQWP8kay1mahd+j6qsKi6mTMhcI0a+E2IIFFEooqDsnrkMZpPD2QG66KKL0hzh7beriphH"
        "QRS/R7V0Fk3/TOUAnBCAOAARMABOwAmYbXaxYCVhJ9kGkQDzNcjXGLquAkXfGAlhYG6CxDQs0EIEwQBO6o65t68lwniew8HFrNQu"
        "DLF0ZxHd18c5zY6pECtCCLx+05Xv2pqZ/rknvrcPnol9Ibvj6BCEXNdneZ+ohlUaBlzTjOLcc4hvfY9qWKUxv4nN00L05QGzlltc"
        "g3j6JijP/Z3pihhScR4W52HAAhcwO2yQMklHnYan5U4izGQmpCBlUjKuJGQttBELl1WTWIDcFkSBfJjJMuhaz17MEo7jqRGBkLxr"
        "gBBCMJNvXbcliRNccsklAHDixInt27ePS9ux0ZNL3xON61knHAiATLLkDlAzsaXEZezEfwmaz0mO7o5LqeH5CQWCkEANb75pCI1+"
        "l6dyEEzqIp39pKaAi1XFZqOn2YJTIJM8OWwQQwgCMswoNht81AgliDR1umiQoqCVKTYvnCBSzAGdAvcN8ejnK3YEsXe+o/vmcgo9"
        "zkBCB4IMr0GaguSKChTvryWUdcad6lpwdMnGlTxNteYiCS5SD2abU1L6slABXVuS19fXV1ZWAsDq1asjjBxDHQk3u6JszXHr+CAB"
        "d5qBEFGRMVAV4CbYurjcKY3B17QLOYTJ/h5IEDELBInXwxCFYhZuGw28ET4cs+tQCKFztzgEtDnoZjCPxycTzOZZhoL0F4g5wKHg"
        "TA95cj0Kc1U4L0my94qObReV/BkeECWbPGCYXQf9DNF30zcFYEYpZlVoq0QaFxV4hlYQLUlFFJRcACtiRinmzElh9HI5O+VoVsyS"
        "NhOSBejHLKTkF3mTC39UxU8PHHCiXM6rzJyutUKyg+6Edp8NSovHeSqoSjr0QdEQTW5dWwY+3YEFXAkjWCPEK+SDJrd3aorU8HAu"
        "ChJzJSOVI2byYRY3n5wmfY6YkQJ3ghBq2KnlKc1gZLPOwxMxBzMNufijFbAMsq1bzAUu3S8xZA2mo3u9+h3JClP4ZiluQKogy6J3"
        "ClCak5G4dTv9C3HFerdzN2ZyreGMupfOIWTPDBLuBQ88Z4EuycbZxDzWAKTAq1JlmOvKWHks0psiBIgoUCHcG4P+y1h8z/5uBBAN"
        "ItFMeUvWECSgCSWW+RSZyDyyuKlpSFd5CW22dj4KgcfAbVnGiIeAmTDwdP2wMWeugA/aY8LIhE465SDMEhYQihnd+WjCD0kKYTwk"
        "LmCSXdSFQpZAuW4uaCLoEXwzrAH95kwAINUzrVyukjQ2O6cQucR4CvIquDVdIo8ELuT0dMYgADOSD7MoR4uYUYpZchxEZPOCJEhu"
        "8wmV5GNJPjp3jTs8UdQo/NIsA799kzJ3Y6FnUQg3zpFbCiffJTnuG+Y9V4UTge/WSFeb005H8hLZRw0vHyeSEz93zK6dVqCnvM0C"
        "GSid0DUEM0lvZc0NMyKFbAnZMCP5eAP5NzgZf8kckc8gQRGzu14Bs3DpvASzh236xDD0b3fO0maiBcnCTARE3uQSsmitzJ2ntpQA"
        "KJzJcBiunY+EXJghBDOIeYTtfDAYgDm9U0g5M0osEZgJqc60LYPZDiRHB3POnpd0Pjd0ie9C1BNlMsMP7YikMEcdihNafgcUSWHZ"
        "QgKIHLLz24lo0imTSEbkIWEOGD435qxERon1K4M5qG25YaYwOnswg6/NIikoHLN8jXjahuhnbOF3P5OI2ckX4l0jIK8u02EERPr/"
        "b3UYaJTugucAAAAASUVORK5CYII="
    ),
    "Disconnected.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAcoAAAA1CAYAAADBL6ukAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAABAzSURBVHhe7Z0JeBXVFcdPEkWSkBACH0kgIRDWAEFEkASMoLWIIrFVqxbEaoNYl7qyWD9ECO7WfS3uCyp+2pbV"
        "1qIoAUWpAQQJYgx7whogIQsGks7/vnnJmzfzkvdeZgwp/9/3vcy7953MvGX+c+4999w7IRnDM2uFEEIIIZaE6ltCCCGEWEBHSQgh"
        "hDRAo6HX2tpaiY2NldTUPpLSrZvExXWUyMhICQsL0y3sJyQkRH/WfDTve3Ad24m3oP2cOs0Xccc51dw4+R6OHz8u5eXlsmfPXinc"
        "skXy8zdJSUmJ7ecUPkPnzp3knMxMGTToDElJSZHYdu2M2tSO6cSZbLs+PPbXEt6vE9cHu89JJ85xwx5byvv12C+0WXLwoBQWFkpe"
        "3hpZnpsru3YVNfp7NugoIyLCJSEhQYmwoqJSDh06pC4AFeUV2sFKdCsNbQ+1nl+h/tSfOisbQ63+xGxntgH27d+jzvCSt52hxlxn"
        "MDcU1B+zXZB1+u/s2hgKgdfpZWC4zDZop/811JkM6uus7AwbH3beZTcGcx923jYeG+Bz//7UeZRj28VKRGSEalDGxMQoHUGUxcXF"
        "Skd2gP2m9uktWVljJSkpSWLattWOEyGnnnqqhIYyUOSEI2vpONk4bCnU1NRIdXW1psMKOXT4sOzYsUMWLFgo+Zt+UP7NFz4dZTtN"
        "iP3T+kt8fJyUlZYpoWPHx48f0w6mXaT5pRNiCS7SoaEhWs/uFOXA0NCMio6S3bv3yIb1G+RgA4L0h06dOslFF46WzLOHS9euXZVz"
        "JIQEDpzm1q1bJXfFSlny8b+kqKhIf8VIWFKX5Jn68zrQAh44cKAkdu6suqWrvv5Gc5KHNCdZQwdJiB9AJyoEW1EuRcW7JapNlCQl"
        "Jkrr8HDZv3+fJtBjumVgoCd5idaLvHD0BZKcnOzoEAgh/+9AP+3bt1cdQjRwMVRSVVWlv1qPKUYDgSPcin/csWOnrFi5UnVTDbEl"
        "QoifhCj9QEfQE3QFfQXT4MT/INyKniT2QQixB+gJuoK+rLRpcpRI3EGoSIVb16zRawkhTQV6gq6gL+gsUJC4gzFJhFsJIfYCXUFf"
        "0Jk3JkeJ7FYkHGBMsqKiXK8lhDQV6Mmlq0qls0BBdisSdzgmSYj9QFfQF3TmjclRYgoIsn+QuMNwKyF2EqJ0BX1BZ4GCniiSgwgh"
        "zuBOvvPG5CgxTxJTQJDdSgixF+gK+oLOAgXzJDEFhBDiDNAXdOaNyVFi7hfmSWIKCCHEXqAr6As6CxQsJsCwKyHOAX1BZ96YHCXS"
        "ZbGKSDBZeYSQhoGuoK9gpnWEnXIKFxMgxEGgL+jMG0vV1dTW6M8IIXYTrL6YMUCI81jpzNpR1tBREuIU1BchLQuTo8TqBLUUMiGO"
        "AX0FsxYp1y8lxHmsdOajR8nxSUKcgvoipGXBMUpCfmGoL0JaFpaOkqFXe4mOjpb7Z8+S311+mV5DTmaC1RdDry52794tPXr1MTz6"
        "pZ0u550/Sm75862y7rvvdEviD9dlT5Qrrxqnl4hfoVcYMTREiHNAX3R6TQd3USnYvEk9vlqZK4889IAcOFCiLvqrVn2tW5HGOHLk"
        "iP6M+IKhV0J+YZqiLzpYaxC1GTJkiLz04gty2mmnyWOPP6G/QhqDjrIeX/ryEXplj5IQpwhWX3SSjdO2bbT06NFDvt+wgYum+AmW"
        "VCT1WOmMPcoTDKwMkZl5ttx+260ya+YMmTrlLhl78RgJDw/XLVzrEWZkpMu1f7hG7vnLNMmZdZ9M0ezO/9V5dT/ymDEXqXFR3A3f"
        "G9y5Aq95Lv7rz3GJPVBfznK0qkpObdXKcMHDTbTnvPyK/PqC0ZLaL02GZ46QmbNy5PDhUt3CBea4vvve+/LbSy+X/gMGyoDTz5Bx"
        "V0+Qz5Z9rlu49vXKq6/JhWMulr79B0j6sOEy7e6/yM6dO3ULF8uX56rx0/Wa01766ady2eVXqH2OGHmePP3Ms2o/bgKxBXZ8nr/N"
        "eVm9/6KiYvk2L69uvPeJJ5/S/5u4sRyjZDJP8wBnNX7cVTJk8GBZvHiJPPDgw/LO3HclObmLTJgwvk74kZERMnxYhmzMz5dnnn1e"
        "Zt//oKxds1ZGjhwhw7R6sHbtWrVNS+uvtp6grrq6Wr7/fqMq+3tcYg+cR+kc27dvl58KCw23MYNTufGmm+W99+fJjOnT5dvVX8uc"
        "l16Ub7/Nk4mTJtX1PGF38y23Sk7ObLlYayRi3HPJ4oXSp3dv+fnnn+tssq+fpJzXjTfcIHn//Ubmvv2WFBT8JFm/uVTyN21Sdp7c"
        "c890WbbsC3n66Sdl1ZcrZOzYsfLsc8/LR3//u25Rjz+2dn2eGyZdLxs3fKeWUzxz0KC68d4777hd/f/JipXOrHuUDL02C0OGDJae"
        "PXvK3HfflR8LCtTJjNbehx/9Q7okJUnfvqnKbt++/fL4E0/JN9+sVuMLcHpLP/1Ma00elvShQ5XNrl1FsnfvPknr30+V3WDRXwgF"
        "gj569Kiq8/e4xB6oL/vBrcu+WL5cJv3pJtUQQWTEzXvvv6+9lit/e/EFFTVBRKZfv77y6KMPyxqtgfnvT/6j7NDz+s/SpTJ58l2S"
        "/cfrJCoqShITE2XGvdNl9AWjlM3b78yVFStWyn0z7lU3+W3durV0795d3nzjNeWgpkyZZgr5ZmRkyAP350hi587Spk0bue3WWyQi"
        "PFwWLVqiW9Tjj62dn4f4h6WjDA1ly7U5GHzmmbJz1y7Zs2evXuMC6fBwXl2Tk/UarVfiJUaUYRcT01ZO0Rf1XbtunVaOkaSkRFUG"
        "vXv3klatWmk9znV6TWDHJU2H+rKH+QsW1oULB5+VLtkTJ0m45rhef/1VGaY5HDfzPvhQBgxIk169euo1LlL79FFOaPXq1ao8b94H"
        "yvFNuHq8Klvx4YcfqTu//OaSLL3GBZwahio2/fCDCp96kpAQrz9zgcZqx7iOUlRcpNfU44+tnZ+H+IfJUeKCGxJq6T+Jg6C7j3sU"
        "ogeH8UPvB5yb5y2WYN89JUVGj75AsrOvk6lTJ2vC6aXqIQ4AZ4jfMy0tTZUBwq5HystVqAgEelzSdKAv74aOPwTzP//PeE4PufKK"
        "K9S5nJMzUzLS03UL13f24+bNqqfldqqej4rKSqmqOqrsCgoK1HADsmatcNtAK+7GqCfdunZV2x9/LFDbhoCmKiur9FLDeNra+XmI"
        "NfjuvLHuUYbQUTYXW7dtk+n33mf5+Of8BcoGvcSbbrxBrr56nLTWRPDll1/JnDmv1I05uiktLZXCwi3Sv38/dRGB0+utOdP1361X"
        "g/ye+HNcYg/Ul/3ccfttKvEsZ/b9pgsdShh/dztV7wdCnW67EH/u0aJpyQp3B8PqQmsntn8e0iiWig1haOgXB+Lav/+AxMfFNXqv"
        "wqyxY6Rjx47y4ktzlBPLz9+kxmisBIqknmh9bAKhGrSEEZJ1E8hxiT0Eqy+nL8AtmQ4d2sv1E7NVT+uf8+frtfBpIdKtWzcVEj12"
        "7JheawZ2GGLYtn27GvO3AjYp3VNUdisSZbxBYxP07NFdbZ3Azs/jBrakHiudsUd5ApG3Zo0Kmw496yy9xpoOHTpozm2/7N1bP6aI"
        "kx2D+t58vzFfjTMiIadvaqpKBEKijyf+HpfYQ1P0RWfpm4nZ2aoB+dhjjxvmBl526W+lrKxMJeI0xCWXZEllZaXM++ADvcbM5Zdd"
        "qva1cNEivcYFjrdo4SLVGPUc6nACOz8PiI2NlbIjZXrp5MaXvkyKhSGTDZqHr75aJT/9VCijRp0vQ4eepUJJePTq2VMuHnNRXctv"
        "27btylkiMQc9xDitNzh+3O+lXbsY9boncJIbNWeJ7FeI2LM36cbf4xJ7gL7o8OwnPLy1CsHu3bdPnnv+Bb1W5Lpr/6CSex776+Py"
        "zty5aq4hHsiSnZVTH6pFZijmFj/40CMqY7SiokJKSkrkmWefk6nT7lY210yYoPY1475ZsnjJEpU5Xrhli1z7x2w5XlMjf330ETXd"
        "ykns/Dxg5Ihz1LjqipVfqrFQfH/EiOUvymQeZzj99AGWCTNXXvE79TrCOW++9bZ88slSlYk6bepkufOO2+RX55+nWobupJrFSz5W"
        "Cz+jZYkFBy4cPUo+/2K5Shm3AuEojGtiUH/dOvOC0f4el9hDsPqic20caALZn2+8+ZZs2bpV1aEx+fprr8iUyXepjNFhZ2dq5/av"
        "5cmnnlZZ4lVVrkQZ6OPtN9+Qm2+6UenhzCFDZczYLDU/8dyRI5UN9vXaqy8rG8xhHjhosFz1+/HSpUsXmf+Pj6Rv377Kzkns/Dxg"
        "2tSpKikQczOHpmfI8x6NjJMRK52FZAzPNNRilReELsq4/h8hjhDVpo1aSQm9kkDI/WKZ6q2wh0+IM8BJItExc8S5eo0Ly6YtQ6+E"
        "OAf1RUjLwuQo4VEZeiXEOTiPkpATFyud+ehR0lES4hTUFyEtC2tHyekhhDhGsPpif5IQ57HSmUmxyIDEvBomDBBiP9AV9GU1Yb0x"
        "jh87ZlpRiRBiH9AXdOaNyVFi4mxEZAQTDghxAOgK+grmZrklBw82usoKISR4oC/ozBuTo8QdJLA6fliYedFfQkjTgK6gL+87tfhD"
        "YWGhmjROCHEG6As688bkKLHKBCanx7Rtq5U4KkKIfdQqXUFf0Fmg5OWtkUOHD+slQojdQF/QmTcmR4kFtiMiwtXSRxERkXotIaSp"
        "QE8uXYUrnQXK8txc2bFjB8OvhDgAdAV9QWfemBwl1gKER42KjpJBZ5yh1xJCmgqcZHR0tNIXdBYoWMx+wYKFslVfmo0QYh/QFfTl"
        "fdMIEJbUJXmm/lyBrLyjR6uUoJMSEyWmbYzsP3BA87Y/41WXESHET2pVTxJ3ZklKSpSi4mLZvHlzg7dI8gW0eeRIubqbfnx8nERF"
        "RemvEEKaQrGmy08/W6b1Jleohe69MTlKUF19TMpKS6V1eLgkJMRLQny8lJaWSbUSN8ctCWkIOLSwsFC1mHz72PaSnj5U2ndor5zk"
        "hvUbpKws+HWUseD17j171DHatIlUDVreR5SQ4EC4Fck7cJJLPv6X7PNx5xTTouieYCwlISFBhYwqKirVzYGR1l5RXiElBz1CR9oe"
        "aj0dqP7UnzorG0Ot/sRsZ7YB9u3fo87wkredocZcZzA3FNQfs12QdXpn37UxFAKv08vAcIf0Bu30v4Y6k0F9nZWdYePDzrvsxmDu"
        "w87bxmMDfO7fnzqPcmy7WDUFBNmtSNyBjhBuRasVOrID7De1T2/Jyhqr9VSTVJIQ7kcK58yVf7SfQ2tIECNcAtE1TxLOEdmtSNzB"
        "mCTCrfmbflD+zRcNOkqALxcTpFNT+0hKt24SF9dRnz7iXCv2RDjJm/c9uI7txFuo10rzieZEEKyT7wGLCaBBiSkgyG5F4g7GJO0+"
        "p/AZOnfuJOdkZqrGbEpKiuak2xm1qR3TiTPZdn147K8lvF8nrg92n5NOnOOGPbaU9+uxX2gT8yTRi0TjFYk7GJNs7Pds1FESQggh"
        "JzOM0RBCCCENQEdJCCGENAAdJSGEENIAdJSEEEKIT0T+B1uw+1S9jvOfAAAAAElFTkSuQmCC"
    ),
    "Rejoin_Search.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAE8AAAAZCAYAAABw43NsAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAZLSURBVFhH7ZkJTJRHFMf/gCheUUAIGI0ciYgFRZGipiK0igdWzgKxKoq2IG0tKJe1xaMF1IqIwOIFgoAHIEZt"
        "QVEQFKyKKKcNolQOAbmLIt5fv5n9gK2yy+pKauP+ksn75s1j5vvezLx5w8o0Nf/NQMpbIctJKW+B1HkSIHWeBEidJwFiHRh1dXU4"
        "l56BqspKyPfvD20tLZiZmWL48OGcxfvPufR0ZGVdwNo1Hu/svXt13pGjCQgJ2YWnT59yGj5Dhw6Fr68P5s4x5zTvNxERu7E/Mgq/"
        "nToBdXV1TisZIrdtQUEBgoJ2YOTIkeCFhyIrMwNJiQn4cf0PkJOTQ4B/AGpraznrDw+Rzstkl/nLly/x8+ZNMDY2xpAhQ6CpqQFr"
        "ayscPhQPHi/snc3i/xGRzqu/X0+lqqoKlYIQnZ6eHlfjwzAMjiYkwMVlFUzNPsPceRb43t0DubnXOItuSktL4eO7DrPN58B46nRY"
        "WtkgOHgn2traOAs+SUnHsGSpExobG3Hp0h+wt3ek9ikpqZwFkJx8HC6ubnRMExNTrFj5Nc6fz+RaXycvLw9LnZZj2vRPMH/+Avj5"
        "bURDQwPXKj4inaerO47K3Xv20hUoCtLu7r4G27ZtR01tDUxmzMDEiRNQWFgIt2++RUJCImfJ/1inZc7IzMyCupo6jZvDhg1DXPwh"
        "fLfaHS9evOAsQT/q5s0/UVRUDC9vH7Q/egRtbW3I9ZOjk0V0/gGBqKiogJHRFOjr66Ps1i14enkjeGcI10s3xcUl8PBYi4EDB2LB"
        "AguMHj0av6ekwHnFSjx+/JizEhNyYAgrNbX1zOw5FoyGlg4z08ycCQoOZXKv5fdouz8yhtqtdvdk6u43dunLbt9lPp01l9H9yIC5"
        "fecu1V3MvsxY2zowBYUlXXak+Af+SvtIPn6yS/eL/1aqGztOnzmW3K0nJTomnra5rlrN1NY1dOnJOHb2XzLhvL1dus5+xutNYtIz"
        "srr0pGwPCqFt4RH7/qXvrYhceQMGDMCBqEg4Otijvr4eoaFh+MLeAYsWLaazJUjMwVgoKytjHXsCy8vLc1pASUkRazw80NHRgRMn"
        "T1Hd+PG62L9vL0aNGkXrnVjMn0dlaektKgVxdXWBqelMrsbnQHQMXbHr169DfzaF6kRRURF7dvPg6OjAabrZsiUABgYGXI2PnZ0t"
        "lWVlZVSKSz9OCoUsby8vT/ry6RnnkXYmDVdzc2mcIFvJ18ebpjHV1dX0MIlk04FXefbsGZWVFZVUEh4+fIgMtr8KNnfseNRBdU+e"
        "8LfNA7btVcxnz+Ke+JAxq6qqMGvWZxg0aBCn7R0tTU3uqRuSdikoKKCpqYnTiEevzuuEDGBluZAWEuxJ3EhMTIK1lSUUWAeT+FNe"
        "/hctwiCxkJCfn4+1nt5obW2lH04miMAwouOqILVs4k7irKqqKqeRDFlZkZuwR978L1h0dHTYAOtMn0tKbkJZSYk+29naIPfqZaGF"
        "Fx5G7X7y20BlTHQULl7IZFdzKi0khxQXlREjqGxtaaHyv0Ck89rb2+mK6glZGRkqSe5HCnHg9Rs3IMPqySwKK+SqV1NTC8uFn7+W"
        "6rwJZMWqqKggv6Cw10ygrxDqPJJvOa/4Cp7s9iJOFITUybWNOGPCBH2qs7Gxpls2NjaO1gUpLCzCaTZWEjrjU13dfSo7ef78OXbs"
        "COZq4mHLjklibTR7cAhCUp2QXaE95pfvEqExj1y/NMaMoRfqhZbWMJw8GWN1xqKluRlpZ8+iubkFbm6roKamRu2dnJYiLe0sfekr"
        "V67C0HAyyJotYfOqi9nZ1GlGUwzpiUzysTNpaZCVk8WkSQZs4K9GTk4OezIr077EZcmSxXRSwnkRyLt+g/ZP8sCc7ByUsrle+Z1y"
        "OlZfIXTlDR48GFu3BsLH24s+p2dk0Ms1WXHkZNq4wQ/Oy5dx1vxTOS7uIL26FRUX0w/isYWczCYmM3DkcDx1HGHzpk2YNm0qUlNP"
        "IyBgC5KPJeNjIyMEBvjTdnEh7xF7MBpW7KFVxCbjoWHhiIo6gOp797Ccfbfg4CDOsm8Q+zcMkuk3s8FZlY0zJI/qDRLXyOlJ/qlA"
        "4mBPtLU9oNcuDY0xNARIAonNZAuT+EfGFMw1+wrpD0ASINl0f+BInScBUue9NcA/g8M7W0osjigAAAAASUVORK5CYII="
    ),
    "Rejoin_Play.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAGgAAAAoCAYAAAASRL/NAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAH/SURBVHhe7Zs7S8NQGIbfXmxrvYG6qItWVAQHL9Q/YOsf8IqLoo5eUEcvVXFxElRcFC9L3QRXwX9Qd93cHAQR"
        "BaVpTM1pEynl7J7vO3kgJCeZTp7kIQSOb2A6n4eHsvidvYeieIIUh4yg6kogEnYGGkFCUE/Mwu1+trCND/0goNF7T2Kq8W4L4RBQ"
        "FQGWxkycrxvo7bCcq7whIcjncw4c2lvyOF7LYWs2h/pa3h+hpGMxPGjhetfABOPskZ+WyN6inb2LDZ7ZY/PcxZqL2UvZ2Wuo45M9"
        "dmFIiuztGJhM8Mgey3JH7ewtjJq4FNnrpJ09loJc2kT2Vmlnj7Ugl7/sJellTwtBgkL2RorZ6yOUPW0EuYjsHdnZ257LoZFA9rQT"
        "5JKIW0gTyJ62ggRu9q42DfR3qZk9rQW5tDblcbhSzJ5q//Y8QSWI7O3Om85IDTxB5ZT9Of9vPEEl3Gf82DoNOiM18ATZPL/4sHxQ"
        "gdRZBd4+1HqFtBb0nQVOboKY2Qvh4UnNW6GtIJGzqVQI6bsAzB/npIJoJ6g0Z6/vin0RSNBGEIWcydBCEJWcyWAtiFrOZLAURDVn"
        "MtgJopwzGWwEcciZDPKCOOVMBukZccuZDBKCytcAcs2ZDBKCMo9+GCb/nMkgs0a1JopCxoQknSDzGH5+6SdHoEcnCOMJUhrgF33T"
        "wMqvWQqqAAAAAElFTkSuQmCC"
    ),
    "Rejoin_Gamemodes.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAGcAAAASCAYAAABGrsCLAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAncSURBVFhHnZhliJZNF8fPrt1d2N3Yit0dKCoiYmJigKL4QUVFFBVUUFQMVAQVsRWx+4Nd2I3d3bXzzO+871nm"
        "ubh399E/zF7XNXHmP6fm3BvXsGFDJ//Hjx8/5N27d/Lhwwd9T5UqlWTMmFGyZs0qmTJl0u/UqVOLc05+//6tz/j4eImLi9P1fIPo"
        "dywkNwai4ynNT0hI0Dnwodm3cfkTsBZwXmRw1pcvX8rbt2/1O0eOHFKgQAGdA2LtY/ujL8Z+/fql/XCLhVg8E43z+vVryZ49u3Ts"
        "2FGaNGmim3/+/FkuXrwoO3bskJMnT0r+/PklTZo0ujENgaFQyAD67D2KlPpNXjgvqTUhogq1b5SRnOwoGKOZkc0Jr1+/rg1UrVpV"
        "SpQooe9R2B6s4z10Zr5tHITvsaDGefPmjZQtW1ZGjRollStXVg958eKFRky+fPmEcQy0ZMkSyZs3b6JhQi8IDxy+x0JK44Y/mQcn"
        "Uyjv9EWVYQjlRsdtLUZmDKWCK1euyKdPn/QdHZQsWVLfge0FeIZ8MA4y7NsQi1cIlVm3bl3HpnPmzJE6derIhg0b1BBEElHSuHFj"
        "6devn3z9+lXmz58vBw8e1LBOyjAgJBsdiyKc+18QS15SCg05RmFyonsjC5DWcdLv37+rHp4+fZqYmqLGMZgs44Nh4JBSSgOxeMRV"
        "rFjRtWzZUsaPH69hO2/ePLlz544elENmy5ZN01y1atXkxIkTsnbtWilatKjeS+Thb9++KQnm5cmTRwkQdRiX9RyMcQgyRurkHvv4"
        "8aO8f/9eD5E5c2Y9cNq0aZUYikEGTgPJDBky6Djr6CeSTTY8TXbOnDklXbp0KptmsuFlslE2Mr58+aLj3KXIZh1gP9aSwnv06CGF"
        "CxeWJ0+eyNy5cxPTGvLMOD9//kzkCic4Glf4we3Zs2d6Vt7ZB565c+fW9YZYxomnAGjatKmmsCNHjiiRUEl8E02Q279/v2746NEj"
        "TX8HDhxQRd26dUsmTZokDx48ULL03bhxQwlzQCIOg58+fVrvNCJvzJgxetjbt2/LtGnTVCEoDj7su2jRInn48KE6wObNm1VZZphQ"
        "9oIFC+Tu3bty5swZ6dChg+TKlUvGjh37L9nMRSaywapVq+Tx48fy/PlzWb16tZ6JMYyFAtOnT6/n6dmzp6Z77pipU6fqWoAiacZ5"
        "4cKFena4btq0Sa8C3pF17949GTdunFy7dk0j8cKFC9KrVy/lFoK9oy3OH8YdO3ZMypQpo+mLxWwMQSIEC+MRWJJoYW716tVl586d"
        "2nf48GE1ZoMGDWTr1q0ydOhQTYE3b95UkigYwxQsWFCKFCmiMhjHc1GIj1wlx1oOkSVLFjl16pQakEhFsUQunFq0aKFG4GB/IxuP"
        "pbBhD54otlGjRjrfp3dVCO8ob8qUKXL06FFZvny5nrN79+7SuXNnlUdksB/RkBzXq1evyooVK6R9+/bqCMytVauWOtr06dPVSYjC"
        "KOCBzkkz7v79+84TcF27dnXlypVz3ltcp06dnE9hzm/g/GWoz+3btztPxHXr1s15j3OesMO4PoSd927no8b59OZ8FDofyn4P5yZO"
        "nOhKly6tbePGjdq3fv16V6VKFecP6IYPH6593rOcT0HOE9ZvrxwuBW1t2rTRPu8IzjtCouwJEyYkyvYeq30m2ztWomwfRc6nLz0P"
        "8NHmOLc3lpsxY4b2eQM6X6E6r3jnHVT7vJFcqVKltHXp0kX7gHdY5f5fuKITUKxYMV1XqFAht2fPHufveNWdv+f/1WrXru28AV2N"
        "GjWcT9XxWjLjHeRJC1k87+zZs1oAELLly5eX4sWL6/2Bl/Tp00f27dsnnrh6BqUlY6SIEOfOndP7gBRAWAO8CPlEHOkFsJb7o23b"
        "tvpdv3598cbUNnjwYO0z7zacP39e18CfdAeQjUeT2002c5DfvHlz/abq5M6AM5EB8HSihmjyxtY+zkm00Y4fP659Bs6TEldw6dIl"
        "fc6aNUvq1aun6bV169Yyc+ZMjXj0bs0yFE/OGY+CSA2QgjCHQpncNWvWrNHw27Ztm+ZP0gZ3Cpc66QyFQJoU4L1VSYBQgWwWfhvo"
        "B+EY7xbmKMtHsjbvtdoHV9KtwWREgRwcLCnZr1690jPSKFwAhQGOxTyMCTizIXwH6CElrhQj3Ft79+7VMfSI85BScXRkcAZr7G3v"
        "8I+H1KFDh9QTyJdUJyzC08jNRIYPNR2/fPmyGnHdunVaYnPxQpDiwBAqxBCrLymYsvAquNEsmmlUhyHoSwrhGO8YBVilBC8KCED0"
        "cW4MxF0GuLM4N05ZoUIF7TOgn5S4YlD2JFK4l5o1aybLli1TfVI4UJ7DwVpoKHUeUhmW5UcWFz2XHimM6GBTymzSAVXH7t27lQzj"
        "YMuWLeplrVq10u9YSM4wofIAskiVYPTo0aooqkh/DyrH2bNn61gUye1h4LBUm2DIkCFaVJAxBg4cqH1UnqZg9kLmgAEDVA+03r17"
        "q9IM6C3kirGIlJArzr1y5UrZtWuXjuPckydP1jXoFphhrIV7pIY0nkHpOnLkSDUOUUHZimKoTKjTMQSlML85uEeoOog4SlZKTaok"
        "xqIKB+ZJKQHjUPpyhxGVeBp7N2zYUA9KKuWQfwPWIZtye8SIEVKzZk3N/1RrcKd0tsoUhbZr107nkuqJKrgRtRgFcA+lxJV7FSPg"
        "9OiMf4XxQx9QQeJ8GMN0YwbCJvrkDxanROWHKJclhrF/7GF17hTKPkITY/Xv318vSzamBO/bt69epiGQa0/b3LwCBUT7eEKK1EJZ"
        "7itDvZhJCaQZX3nJ0qVLE+8FW2Prrc8uUxrvwOaYMfBs7kjSC9FEnxmAxm+UYcOG6X2KwVjHN9mDuxhgbFJ8UlwXL16s5bavelV3"
        "6JjfeJyP/8YMGjRIdWlcw4YeQJy/L/RUkGIhORai5EsmEQ14Ak8DHhT+d8C8CpAC+KYyQymkCUhwEHI0T4oOcj2XO3LYkzWs5fcL"
        "c8jV8EAGlyueSiQzH49E8chGDlwpTuCAbJwI2cjgtwfn4D8YxoN+ogVFMI9+nnbp4zg4GzLtHuKc5oDow4oBxpHHGPLYn73s/qGP"
        "c5tOkYWhOI85aNRROS+Iq1SpkmNjJjBI492sF4UJiiLsh5DB5NjGGCEcj4VY4/RZPzJ5N66295/KDc/KGAZP6tzJATmsR/HIw2Ag"
        "OR0aF+MOkMMa5CgXlBUezsjy/JtmQJaRM8MwbqR4xmp20PA7bIBnmL5sXvgdNlsb9tl648Q34N2eybUo7Pw2lpxhDOG7AXsA+HoZ"
        "/zMEHzztOwr6YvWHiJLnGUsx1vdfWrgmKZnhe9ii86L9UXkG+qJI6uw215SKkZPSHzAO0TnWZ/0JCQnyDxxnx56wQglAAAAAAElF"
        "TkSuQmCC"
    ),
    "Rejoin_Raids.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAEAAAAAXCAYAAAC74kmRAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAdPSURBVFhHjZdZqI5dFMfXec3zPCUyU4bIPCSkiAuEIlyQSAiZidwYklzIUMiF3EhkiIylRIrMF8iYMfM8c77z"
        "W+f839Z5zvPy/Wu19157rbXX2nvttZ8nr0+fPvmZTMZ+/fpl+fn5lpeX5wTUCswL6ADxcun8H8hGtJ/k0UbbjJO8JKQLkMNneH/+"
        "/MnqFfBKBi+KkDH4acH/TS9JOAAleZLXXJSRXXi/f/8uxkuuKx0I4C/z6EKShzI/f/4sYSwiGnKFouAxlAbJ0mrBJI82zosXx+IB"
        "1mScDFyQvSTJX/qyB0/6Pq+OhHNB8zIWjagPNC8ScB6SI7RPnz61+/fv2/fv34s5CWKrDAVxXQA/SQBftXHwkn5m7fTq1cs1ooCM"
        "0OLkq1evfBxRunRpq1ChgtWuXdtq1KiRXTwGIXvwknj8+LFNnjzZ+vbta+PGjbPGjRsXzRSHbD1//txev37t/TJlylirVq2yBxLX"
        "S4sj8gB9zWUzAERjtPAJ/uPHjyXoyZMndvDgQevWrZvdvHnTT0knDNClr7SVXeH9+/e2ePFi69+/v/Xr18+zIAL5uHEE/+nTJ6fh"
        "w4fbt2/fitnViYOoix+KT4i+ZNImJZCc4xRu3bplt2/fdpkuXbrY9u3bbcGCBX6i0eGY7rKnPkT27Nmzxzfy/Pnzfqrw0ZGedNIg"
        "OaDA43pJ30G0KZm83r17O1dMoVSpUt5evnzZdx1MnDjRDhw44HOc+Jo1a2zq1Km+cMuWLa1OnTpulDHF9eXLl66LbNmyZa1KlSp+"
        "ZXCYwLleAHsdO3bMpjSbJ136FStWtLdv32azBD8uXLhglSpV8kx68+aNZwRrly9f3v2oWrWqy2ojYmxA8WUUuARo5QiOJ9GoUSNr"
        "3ry5B7xixQrnId+5c2d3kMBxCufXrl3r2fLu3Tu7cuWKzZ0717MIOXhad8KECdmU/vr1qwe0evVqe/DggV/BnTt3WoMGDXwtgcDu"
        "3r1rAwcOtGPHjrkcdOLECSuoa64LtIb66BG8Dsk3gIEoniC7nwRzutc/fvwo4hbuKHyIAM+ePWtjx461atWq2cOHD61hw4Y2c+ZM"
        "O3r0qF+XNKBL8KdPn7bx48e7LhtW8LHmehHUhCVLltjGjRutU6dOXpfgdejQwbZu3er6ZJHiUvC0xKaXJSMBCNDGgoZQBLsOcbLL"
        "ly93HjIXL170l4HTHzx4sH358sXu3LljLVq08OwYMGCAy7Zr1866du1awi5j0nz27NnWpEkT30QKJAExJpgIAp4yZYr3t2zZYs2a"
        "NbPWrVvbnDlz3NakSZM8IxQDlIwNym6AhCSgcQQpTU2gaHGHZ82a5fxNmzZ5yiNfuXJl27dvn7Vt29avCUHBV0qC+vXrl7ANPnz4"
        "4BUe7Nq1yzeZDST9Fy5c6HyBa/f582fvU1coqtSZDRs2eL9Hjx5Ws2bN7KkTE7HFWKGMdgPBNIEIigu7zBtMoIAdX7ZsmdWrV89t"
        "kAXode/e3TZv3mxHjhyxq1ev2r1791weIJcGUrNp06beV5FDtly5cnbjxg3nC3x7zJ8/3wMbPXq0H8ipU6ds27ZtNmzYMPeDK0Q8"
        "ijHGBcHzGqD7G4XSQPXFIQqhKjK7TsVVUKQqcjgzbdo031SeO+7kvxDX5YQh7MKnH8GLcubMGb9SFOPjx49b3bp1PfV3795thw8f"
        "tkePHhXL5mhf4wK7hZ+LkKBgooLQpk0bl+XegUWLFnkFB8hTA+CBVatW2ciRI71Q8dH0L7CZuio9e/b0K4FNii21IOLZs2d+xyl8"
        "PMcETnYOHTrU58lAXgOyKgJ78aB9WzklMSQU+xGMa9WqZevWrfM7SCpSuFSkmOfdBqQgtnFST2YusOlk0qFDh3w8ZswYryMUUoLl"
        "WYxgXey+ePHCP6nxBRvKTKBDVTyQgtdcJlfwUSgCvjKEggPYADKJdCN4nfb06dP9y5FTHTVqlGfH30DRWr9+vX8g8WXIm873A8+o"
        "1hTY8P3793ufDGOjrl+/bidPnnTepUuX7Ny5c369FYuCh/CXOX8FkpACbS6QBWwAQVF1ly5d6ifCPZwxY4bt2LHDXwDkrl27ZkOG"
        "DMlelVwgSIorP0h79+71p47iyjfAiBEjiqQKwTp8hc6bN8+LLNnGa8HLsXLlShs0aJDrKuAIAmctDj+vffv2+dpd2qQC94yvNkBl"
        "5U1WQeLpIz2RRxenOEUMc0J6GvVEsSGA0yXQOOYd1/rcW9blW4KD0JViQwB+8FogT53gEKgT6GKLAlm9evWsPVpAS/DKBuexAd4r"
        "gBQEBSphjWVQ0CKalw14IiC5uIb6kQfS+PRlSz4J4ucCviGDXrTjHjOA4mJJnhTURsCLwUtXsvBEcoA29iMvjU8rW/Fp+z+Qb+iB"
        "6J/PJI35RIGS+FEhDcmTjy0UAxNFvvq55OHJHmNB/qiVvggwl0sPFHpegKiUFnwa4Mfgow3aGET80BJP8rGf5AHWkY4QfZKO+vKL"
        "VnP0k2Rm9h9dj4XH6Xu+UgAAAABJRU5ErkJggg=="
    ),
    "Rejoin_Create1.png": (
        "iVBORw0KGgoAAAANSUhEUgAAADwAAAATCAYAAADMBm6RAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAadSURBVFhHhZZZiI9vFMfPb8zYlxm7sY9m7HuWhEiUSy5w4cKWhhu5QhJlTQopuZCkEJKxlShlV5YU2bPv+zJ2"
        "hvmc/3xfx/tv+NbT+yznOed8zznP87yZYcOG/SyHqWUyGf+WlZXZ34BcZWA/iDLqp/cxzsrKqhj9Hkd5WpUqVXwsP9XHTxp95L5/"
        "/24/fvxI5LSOTm9aoAlSEJGWi4aEtAyIfZEQGOOEZEQu3bKzs3092oQU5GjMIfft27dkzDqNPiBgrGWGDBlSvv8/J5lE6O3bt/bs"
        "2TP79OmTz9esWdMaNWpkdevWdcXMAfr6xjmNaTFbEYo4MtojWe1njE/05bgIixR9ZL5+/ZqsaZ0vugiYyCcZRjmbrl27Zr169bK9"
        "e/fa06dP7dGjR7Zz507r3Lmz3bx5MzECKvtGYwJjrUeyIJIV7t69aydOnLCjR4/anTt3XKfKNZ3ZL1+++HxsrAFlVuMsdRCC0OLF"
        "i23Dhg2Wl5dnq1atsnXr1lnLli1ty5YtNmPGDLt3794fzgONMR5JCHFOxDSXJgoYE+g3b944cfoiS9nSRAqyMQBqAN0aJz4MHDjQ"
        "e6WlpdamTRvbtWuXnTlzxkaOHGm5ubku9OHDB59r0aKFdevWzd69e2cvX770NUAUUV5YWGhVq1Z1XRyJjx8/uvMchebNm1u1atUS"
        "cuyngj5//mw5OTlWv35918/+q1ev2u3bt91Jjhd+0Nq3b++y6GcvfqGvdu3a1rhxYy9dEYvnnjnZ9ZImWjg4bdo0n5w9e7ZntWHD"
        "hq4IhXPmzLHNmze748i+f//eLl26ZDNnzrSHDx969nHkyZMn1rRpU9u9e7fLUTVLlizxLHEnAAj179/fDh8+7DJXrlyxuXPn2vXr"
        "1z1jkJbj9erV8z4+kXH0oH/Pnj324sULu3Xrli1fvtxevXqV6CcBIJa2kOnXr1+5vp9ujM0YaNCggRUVFSVRYR3lKCBykIIczuHA"
        "1q1b7ciRI56VVq1a2cGDB+3169d+NGrVqmUTJkywBw8e2KBBg6xZs2ZOlqOCPHsLCgps3LhxdujQIZs0aZKX55QpU2zhwoVuY9Gi"
        "RXby5Ek/y23btq1U/4ABA6xdu3buN74K4sE306dPHw8lUaZUIUIWO3To4AKQdcGKTYDMIgcUGKJK+UFg8ODBNnbsWDt//rzLjB8/"
        "3ubPn29jxoyxixcvevlzNI4fP+42qRbIYJfSpnQ5QthWSXfq1MmPwfbt2/+qn8RR9vIb6IuP2SwAMkfJkGEWEKIcJIwxxioXgLOU"
        "ZJcuXXxMtvv27ev9bdu2+TcCIjdu3HA5HSHuDeapDIANHCZzAncA4/v37/9T/4ULF5LnM4LxH4SrV69uZ8+eteHDh/uz9Pz5c79k"
        "AGR79OhhQ4cO9SeK8gHaC2SAL+VEiaZx+fJlL0VKderUqf7kHDhwwHbs2GGbNm2yOnXquE5KOuoGmvuXfhKXJgsIIvuSfzqeIc4V"
        "WLZsmWcBopxdLoOVK1fa9OnTPTOUpIByGeAH5dy5cx5JSpSyPHXqlAePs8uNzFGYOHGiPy0jRoyw9evX2+nTp32vEM8ftpCl7ElK"
        "1H/s2DEPWtQPsQh8E1lapnfv3kkoefO48XCIC4zII8x54XzNmzfPNm7c6FnCcc4XJdm1a1dXzBw36L59+1yGrOHw5MmT3Rilz1NF"
        "EHjCSkpK/O4YNWqUtW7d2mrUqOGlS2lin/POa7F27Vr/D+A16Nixo+3fv79S/bwqSgBfHUEFMVNevn/UDpEbPXq0FRcXOxHOFFFd"
        "sWKFZwKCOBIJcwGhnMY54yLjEunZs6cbIgs8K/zJ4QBHhWrq3r27PX782GbNmmVLly510iJMRiG7Zs0av0CpsNWrV3tZ49eCBQv+"
        "p593mTtI0FvMcQDuowgzIFoQhAzvGk8CBog8mdNFgpOUOnsoJRp9gDzO8nSRTcbsa9KkiZek9OungzcX0EeWW5r/dvoQwA4lTaXl"
        "5+d7sJDVUcMux4HMssY+gDx9AsIXbk64PEo/RZYFnwwtCgMyRJ85IBmgL6APOZrm4zjuYQ7IhtaA5gB9lWjcE30AymxSxhUytCx1"
        "tJBEomKOsebiV4iGBJzBmFoc06eJKA3InvRFH0C0y564zh7tQ4a+ypix/HYdUqQJNcBXGaVJTgZiE4k0Ua2lycYWdcqukLbN/oi4"
        "TzLY0r50K5f5nS1tqFhIxkBflMvxdCOqkbBI6ivHog70RqdlJyLetFGH+kAy8YISN8nl5OTYL2GEyyelV6HbAAAAAElFTkSuQmCC"
    ),
    "Rejoin_Projection.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAHIAAAAsCAYAAAC5Wez6AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAABUvSURBVHherdt1rGfFFQfwu7tQ3F1KcXcLUNyDO2FZNiEsQRf3UkKDB4q3WPgDS2Bb3J0Wd21xd3cr1v0MfH8Z"
        "Lve9fcg3Oe/OnTkzc+acM2fkd9+gESNGfPfNN9803377beNZpz1D3333XaGkoX5vl6UepBwNHjy4GXvssZvxxhuvGWeccZpBgwb9"
        "qM5XX33VfP75582XX35Z8vCH5+23327+97//NZNOOmkz8cQT9+p1QZl6Y0LaDj8iR1fduk08kWeyySZrJpxwwpJf87TbUga1XpQZ"
        "4+9+97tC0iC/5v/6668L6U9+9KKspPszJFKJcl944YXmgw8+KA2D/AhCgHHHHbeZcsopSzr1tNPmY0CGjCCAXx+Mh9RTlkGp/9//"
        "/rf56KOPSlr+rLPO2kw77bTlfUxI/4F0X/WSH57PPvusPIcMGVJkl0aRByLP1FNPXd4h/RkLpN3UVz7WWGMVXXhqH1IPj7qMRzco"
        "9WrdJW/QNtts850KKMYLycP47LPPNk888URPqC5oHE033XTNjDPOWPLw64SwDG0G4qmRGcjT9FmE+oHA8/XXXy8y7LLLLs0666zT"
        "7Lzzzs3zzz/fLL744j0FQAbVxkDzvYO8jz/+uHnyySeLIoNJJpmkmWeeeZo33nijeeaZZ4oca621VrPrrrs2L774YrPYYov9RJ60"
        "mbS26SMG7DIKPcR4sYP88Hmql7ZhyKKLLnqwDMwxXAjkUaLZWJe1CZ9OP/3002IY4YagE0wwQaE6bABe3v7JJ5/0wkWErYUGhqTY"
        "yy67rJlzzjnLTLjhhhuaqaaaqrQLqZ90IC9lPyf/lVdead5///0iZ0i0mHzyyZt33nmnyHPJJZcUw9LNTTfd1JNH/VCt00QkDl1H"
        "pZqfLujFM3XDh2rDg/KS/8N7j7ErbRBQdxjSmYFdfvnlzcorr1y86N133y2Ds5aNP/74xUvTHn6GpiRG1Abh8LSFDOTDv//97zLA"
        "u+++u7yro36QdJ0H9VhqpN02yPXWW2+Vdg4++OBCZh49cOro46677ioz9oEHHii85DG+UORgtIkmmqg4dAwIyvHFSTioiSCPrAhv"
        "yLs6abdGCa0aUuipEcIlLZ/AwklXA23ssccezXHHHVdmpDDLYBBhtPvFF1+UQc8yyyzFS70zvqdyeQZuzYXnnnuuefXVV5uZZ565"
        "tCusmRFLL710UQzwYg6VNng9XhS5owjAV/Prk+MJn4899ljz4YcfFr7w/+1vfyuh1Bj0SfFzzTVXmYWPPvpo4V9yySVLFAIO9957"
        "7/Vmlpmofes6cHj7DvqJ4Wzg6J5M3hkevzbJUcsP3qGUxZAay7NOe5oBtSFPPfXUZvfddy+zjQIWWGCB5qSTTioDwz/33HMX5avf"
        "BUbEx9Cedn+1gAGFzTHHHKUc3XzzzSVfSDvhhBOahRdeuMjw1FNPFaN0wW5S+LNGg/6efvrp0l4XKJwiI0+eMWSNSy+9tDyvuuqq"
        "5rTTTmsWXHDBIo/1OzO6Dfqab775iuHpaEygK/qcYoopij5jPEhafi+21J1Kh+qKAWUYrPVihhlmKDN26NChpUzHG220Uc+Iaefk"
        "k08uinjzzTd7GwjKNGAbmBtvvLGEFmU8leLsAu0OzTZYccUVCzEu8OqHHnqoGHGTTTZpbr311t6a+8gjjzT77LNPmTkPPvhgaYPc"
        "+PW78cYbN//6178Kv3Y4w1/+8pcy48grnHoGO+20Uy8/WG+99QpxZDDm//znP2WMfY3JDCaPiQG1fpZaaqkyhoTZf/zjH83000//"
        "ox1yG5FxcC1sG+mkL4jnCcMUF+i8jT/+8Y9l1tZbdHUPO+ywsomxvgqnHOEPf/hDs+OOOxalU5J+uvDaa68VA/31r38tg1522WV7"
        "65B6Rx11VHPllVcWXoayvuE/+uijm3/+85/N8ssvX/iFLs5x0EEHlXVYXn/ocm7glEL+QMYU5wxmn332soEzhiwtnNMmSjTJ7I09"
        "Ypu8/2S1bxuuZm6D51mvbF6ElUB+e7DC4JFHHlk8MuvEqquu2hxwwAElLWwKOdaozTffvMwUa+T5559fFNEF68vqq69e1mU455xz"
        "isLU22233coMWW211Zptt922KJhc+Pfaa6/Cf/3115ewK7LsvffeJW/0Lr4sG4ceemgJs4HQ6f3www8viu6Cmf5Lx7TGGmuUvQX9"
        "zDbbbEU2YOANNtigN7Ohyx6DKVxBFJ+nPIpIiOyCMo0vt9xyzXnnndfLu/jii3uLfnD77bc3+++/f5ld2Ug4fwElC3XObeqPGjWq"
        "p4x55523WWWVVUq6CyNHjizPxx9/vNl6662bl156qWycrKHWUpAfhJ8T8HjrpWXimGOOKWMggyOOcckP8p6deBforGtMItaYxkQ/"
        "f/7zn4uxnUl32GGHH0qaZpFFFilP/dd2qg36kzWSIqVrplQOsl4gjVtrLMhw4IEHljCQzUXw8MMPl6cbEDtJsOsE4YNiZ5pppjJz"
        "1b3oootKGSyzzDI/pH6KtGFmUXbkQtZqMCuC8Gf9shMW6qyNw4YNK+MYPnx44enC73//+z5nJLTHhH8gY8rSZDaawfVGKI6T8UGe"
        "MeiPDBliTGRwGskWvy/wIoqxwJsJ1sj2YOuObS5ASANrHcT4ni4BgvB1ob+yoJ5B4c+uVV9k5WA1HF+6QBdtx67RHpNwjH9MY6Jv"
        "wBvjdKG2UwgG1zNQCIgBdexcY+FvC571AuGxgRHHHVPsYlFf0E8cwzkLsmaa3co9p5lmmpIH4etC7n/POuusnkxdFJglkE2X9R21"
        "jwJ2jl0gCz31hfaYtA0DHVNs0YU6P3yo2CwJxGA8kQc7f0XhdQOQ9QKvxVn4EKKsLc6GHKE/RLF33nlnedogCLfWNyFY2wmLcMcd"
        "d/yQ+inuvffe8rTbi1whd7GihPNtkLb0KYTp0/be+K2R7pQ5RRtxZgaPcbrQHtPLL79cdqo/Z0z9oTZgiGzFkHkx+5DZGGOkvAvi"
        "OQO6JLcbyw1Ef3XA4RaEYbDVvvDCC4vC9bvZZpuVHS44lwnbfeGUU04pT7Kce+65ZZcnSjjfOQI4lmSTAc5rwIiOIOpxXBsxZ2Ey"
        "MGYQo1nnGMZus310qPFrx9Sf3mrdhjIJiyEZT8w2w7ItVsjDc2Dugrr1kzMk3ReUM7gw49xkmw8rrbRSGaAd7QUXXFAignVsiy22"
        "6DOUMZid6emnn17ebfHtQrXh1oXirVX77rtvGRdnu/baa5tjjz228Js1jOZCwbECHNZPPPHE4szGkw2KzYlwaDdJN13Q368dU3+g"
        "uzaRxXMwz+SRvCaG0IlQYP1xXOgrVLbz1R0ozGT92nLnFsSWnWC232aOs6l7TErtgk0V59tuu+3KbHKYz6WzNlxA+GnJrYp7XRsa"
        "YX3PPffs3QSFnwMcccQR5ZLA2PVN8XboZ555Zllb6cXSETAK4uygbKBjwtcFvP0hBgzYrDxHH6bL75GENAOz+CP5yN2hgdYNmFWu"
        "lHh6Gkf4Pa09qIZOKTY7P31ac7KDbAMfL3cuFKqyUXFwdgng2MDILiVS1oY2OI2IE/mMR5tdoGDnPFEKD/lc+WV85ObAGWdAHwst"
        "tFAp135/Y+JU9Gv9rKGuM6O6fZXlfB5Z8hy0++67l0tzuzSxXwcMGkE9hVYexbvkGYhdH+WEL7xJa0NYy/WaOjZGDtRt6Ft48ySL"
        "44DZIHT6iUhfG264YfP3v/+9tO0HZveWBpZjArmFPrNJGxSmDf0lclCCthE+950Zr3ZEJ316RxSkLU5CN8anXeN2Bq3HZt1XP2D8"
        "9q8rnAOfdrWv/7oNoV8b+N1CKTNek6XdfqC8GHLkyJHfERJpXCMK86wNWj9D9Xu7DP1SEE7IEoZcVLsHpRz3mXaolJSDfN1P0p7k"
        "AQY0cxlBWts1n3FzIg5r3MqhKOiHNNT1Boou/oHmtdEfz2CexWsy6HoQqdhuoK98SL26rD9+aPMDeSKLWcN73T/a0Pht0nrUlpER"
        "1MuTJwuVwjJD1mEp/LxepMnMqcefNKQOar/XpN82tctrvuSnzTxrCm/K8qxp0JZbbjn6+f0Lz0ylUJQSHlS/d6WhTtcKB+laYXVZ"
        "DfnOldk14zUDHbZdOugjwJs+8TGcjU1mYBA+MzBhDfCEzzPtpI+6jZRD+JIO6vygLq/RlT+QPmoMGjZs2Oiy7wfHaDUlPwrKe/1s"
        "57ephvdawPZA28AnvAqjwDg2P55pPwTaEz7NQs/khYeMwrPZlzUQsobmPe0F3rvK0jbkWee18XN4gv54QRmeQVtttdXo9PdhBmVW"
        "SnsmbbMjDOO1iRDasmOtjSgNyQt0BnUetPO9m4H6sm7rm1FsFPQbpUP6UsfMY0BGcmzK5kSeDYzZyYgIhGszEr++OYcQjF97kQdP"
        "zWdThE977fUZ2u8gL+MMuvj6QuqnTt1WL2/48OFl1xoy+Podo3OYLX6tOL/7CW/SMVr9hHQyJuCLcLb8NjQUl3aA0zCmiwRPoEgG"
        "pFy8nM3sZSxtpl08jJn7T+stR+G0kbHmcz7VXhcf4LOD5MzSXaj524hcbcjvq6yN8KSfMiMJTdgYEtVpd4Vu7vPNjC/KeK5do4bw"
        "1M+afg4YwbbbwX3EiBHlpymz85577ilXccrNSg5EkWaR2UpWNzSU7mLAb32265ziuuuua84+++wiCyMBJxm9Nyg3O7+GjwxkIQNe"
        "M5e8jGvG0hH8XD10QRuMh7raGzL6EHtwDACebbJLJKRvYMyGM844o8wQHq48CH8b8toeBBEMKMC3pO5tfYrBiIxqU7LEEkuUX+5d"
        "fwmZZqKLegqUdvGA11Wc8yYZzU6/b6pnht1yyy290Oru9bfgyzpLF2YvR7OmI3KTz/mxC9FJ9NFfun52AW+5a8UURu+hMSF1DUDo"
        "9Wu4GyCD4qEGI0z6Vka+G4/65xv1zSYwm/CPjhAlbF9zzTXNn/70p3LddcUVV5SrLddenI6iOBYjUjgjutT2GYc2GNR953777VfK"
        "11xzzfKpor78IvJb8XE+6zF5jNc743p653RQ67NOt1HboI12XtpJfm/nkMza8mHqD85gDMR4Qg/ivZSLzBbGczuSqydGCBgDsjnx"
        "kRYZRo0aVZxD29I8W4gjE0W5iMavbXV9myMkMvp9991XoojLBO9CoHJgnF/CJ1r4Fb/mIwuDcWQGd9uUTyQjI0PbWEGtX8/oN+m6"
        "PAhP9FRDGR2gUpoG6sYHArwhHzi56ffLgncKRm5k5LtWC+o+pAliFkjbEUJ9d5ofj4VbMuLnQDmaeBfywMW5d8q2Rt12220lP+Vt"
        "Psayng2Er6s9ZQxFfpHEz2h1Pgfn0HHejL3WQY3kxx4ItBddJY0Y2Jr8oxkJqTgQqEPxdo1+HgI/91gzhCBeucIKK5R8oVLbOUpA"
        "hEGEUZ6LdhsqCkZ+WwTKVN9AzEKK0o/61i1QP5sNZMZBvlpo8+XiYEx8ePC2+SJ/FxiXjByO4/WFvupD3X7SeaeLyP+j+RqGGl15"
        "AcUrd0i3qzXzGDbeaga58BYefVfKwIwBESjEuMqFJsaxydh+++0L5eOpOBn+2ivBgECoq51RyIOUt/kSssbEF/IOKRdOhVtkMwR5"
        "98M2kJFT94e6D8jYQpmJYJkRHZA0vf3kA+VUhDTaF1LOkLzDrANfg0Nm49VXX12ePFvIi2DpR36+MPD5PWPyYu34fMSngsC7652i"
        "ZwwRBfPODBrl15GU/1K+yFwbGOyy/SyFyAR59/NZYGxjQq37pNOvsdaXET0Djh5/0YM/daUgDfQFYSMhA6+GnbHAj7MQg9ZhVR3r"
        "Bg+VRyiOoD39Ecyv/r6f8cGx/zMx00FYy6C0BRTkPSHPOqUtikYJkSlv83GOX8Pno7P555+/RA2RB6SRnXRmj/NvG+QOahsYYwhP"
        "DChqGW+Ml3pFbxKgoC4cEwzK+mE3Z1DqOGrY2TnQG4TB2Hk6flA8ZYTfcYRgSL8cgsJ8Zm/HKBT7POL+++/vfSvqt0kwEP3X/7eZ"
        "Mk6k3I7RBsNPXpDyNl+uAn8pnzKzNLMxkM9J/QaLugxJ7jYxCmhPffU4Qrt9vKKTJYFee7tWVCPvabiGcMdYbjuERERxkDDqQ2UG"
        "EiohHfs0XxlDMCrogzIMXjjygbDvWvw/Bm9fd911i6HN+DibHXGMxQGUUfbaa69dzoBCnpsndfFlM/Zb8pHFbDF+M884yAJmjh+1"
        "ldkXRO4a0XsIOLw2GZAhvadu+PTBgNnwlejmZywFEaImecgVndmWEOfzB/k11l9//SKAMOkGJp07xLurJZBNjJ+lDNKMNVC/8stn"
        "ENds7i+PP/74skkyK7VnXXWT4oIgocVAyEM212jylTvfkd1s9YUcT2aUQw45pNQj12/FZ0ycmdLz7U4MYhaZiUKitpIPSeepnPza"
        "Q+k/ZXSN15OuYp8Az5DRXlb+9bxNaQAYkZCbbrppUTjvY7Sa8oEwL3HrwSBuevIxsxDKe3i10Jqv3AxYm2arfq2fjO1y3C7QzDXL"
        "nU/JQ2n4KNRHV75r5TjasSkyQHWtZeT2SaKdpfGoS3YfXfXHR/kUOhA+xhJN8DOG9o3V2JS3Ef2CNvCrT4fSjIgCvAmhjGj20YO6"
        "KEbvzUiEoZ32dFPTNQshQmnQgBk8YTbgtXZx9Y/EDOEjJ/W0QRjIRQLBM2hl+BnCTCULxfqXOd+K2hSZLdbLrLWRK3WjdO8M0sXH"
        "EOGDNl9kxEcW42XA5Nc8aReSrvPUY0BtpU5dF9FVZmCMB57tOn0asn7nEdYzg4JasJBZZz0wI80wAgDvpBhhVH1hloA+YDIQqAXL"
        "ALShLTLwVDMOeRdShTwh2HnTbtGZVZlZj9K/umRTVx+RPesLPvkUmz5qkCPrkLpmjvZQ7YRpu+6jfoZHP9rgXN67QCaOTO+pBzV/"
        "nV/aHzp0aO9zyBgPETz5IJ1nFwHvogjPehDKCRXlQVu4DDbpQF79TrHWK59Duv3Jp/k2I+FNO220y9ptQ19tJK8uq3nqdtppBmdA"
        "TlXPYFAeoiNLCZ2nXt0Xkl/X7+XFkCizLwbNE2N4pJOPgOF4WYRMPj4OwbvaAkItECjrD8o5giNNDWFbSFTebhP6yu8L4Y08dd12"
        "W9Lykl+nY8BQzZ8nndA5PXmmDIU/6f5QQqsGKF+jNcVY0hEw+dIMyMtQOgs/wRgP1QJCLVjSyrvQlW8NtRaDtcoaHL4BDXoMfSqv"
        "5YXk1QiPZ8q8M2BmX0Jo3Rbe6AhJB+FFaT/poO7rezTN/wESql439TMJKQAAAABJRU5ErkJggg=="
    ),
    "Rejoin_Calamity.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAEwAAAAZCAYAAACb1MhvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAkhSURBVFhHjZdZqM1fFMfXueZ5nscUQmRIEqIMRcYHlEgeZChCZCiSPCiKF2UokjEPhgeSIZFknqcMmed5nt3/"
        "+Sz/72nd7V7//7dWe++117TXb+21z8n07Nkz37IoVqyY08+fPy2TyVheXh7sHFjD//Xrl48CawjA//Hjh8+F/Pz8HAmaM6IT90C0"
        "n0K2kIm6Wks3ykDpGsQ1Z4+2AGuI83F+cpPHJosSJUoUSJYMAdYYVLJkCHlIjuJcMiKALja0BnEfyCdQDOKltoQoEwGP2NHRvDDi"
        "7JKXHXRUDPA4G8XgCSMZKdLgUJABKK7ZlwMgPdbRTlyLV9iYziHpAg4pPr5FQHxkFBej1pJj5NzFixd3GYE5vjgfBBi/ffvmY67C"
        "WESDQM4YpRwPzZx9OYAnaM4oGUiQjVSnMJJPQKyyE+PVPlBygGSiLCPJki3ZZ+QcVJJaC+PXr1+dD2V1fvcqBQEUKIRxBAszzBxo"
        "XzqShYDm2i+K/iajw8qmEGXAx48f7cOHDzkdKE2g1jFuRtYiQLKorLiX6devX74YSp6A0Tdv3tiDBw/s06dPbrhcuXJWq1Ytq1Sp"
        "Ui6IeAgFDwFk7t+/b8+ePfN1nTp1rHbt2rl9gTWysskYbQCtYwIE1nfu3LFOnTp5RVy+fNkaN27sfJHkqC7Oiz0RZxAJ379//0Mm"
        "j4kyGjfJ7qVLl6xFixa2Y8cOe/z4sSdu69at1qxZM7t69arLpY5lBxAc+yTr/fv3rv/8+XN3HOXjWry4jnwdHIgPjyS+ffvWZs2a"
        "ZVOmTLF37945/+7du3b06FGnhw8fuhxnwyexQaxF2GMvXkORJ0xCMQA2rl27ZvPnz7c1a9ZYlSpVbNmyZbZixQpr0KCBbdq0ySZP"
        "nmy3bt3K6YhkmDm2WUfA1z4obD+OHJo5pGRpDZQs1nzI3r1727Bhw6xp06a+/+jRI08kiSNhVA0+Y5LgKQ/sqcGLiNeTRWXrd5iC"
        "YYMeULduXdu+fbudPHnSstfWqlev7gZxDq9+/frWpk0bq1ixopf4y5cvvZK+fPnizzT8GjVq+Ct08eJFrzB0GzVqZC1btnRfr169"
        "cj2+JnJcc647+hyOagSlS5d23xyKloBvbL148cLjLV++vNvF/5MnT1yHD8s5SJTirly5sscF4OGnefPmfvbXr19764BftmxZv87M"
        "BWSI0a8kpCxCT58+tQkTJrggJd6kSRM/CITT2bNn28aNG61evXoe1PXr161r16526NAhTwDrBQsW+Nfla0XH8kd19ujRww4fPuw6"
        "N27ccB0SRdJJFkk+d+6c9e3b186ePesJ2rJliydm+PDhduXKFW8V3AL0VE337t1zvhIN+BjM58yZY5MmTfIry9XFJnzkSRiJIzHk"
        "QbokS32vQMJgMOel6dixo/MIFMdKJlVz/Phxmzt3rt28edOrY9CgQX5dkVu8eLHt27fPRo0aZWvXrvW+lYLKGjJkSKE6HD7q8EBM"
        "nz7d1q1bZ+fPn7du3brZsWPH3OeqVau8z/bq1cuWL1/uVwvotpA84gTEyXzv3r22efNm5w0ePNhj+fz5s7Vv396LYffu3QWSBbiK"
        "yk+me/fuvqPE4YzAyDTVQ2m3bt06tx9fGEB18EW4nkeOHHE9XtTbt2/71SEIZLHFARo2bGg1a9a0kiVLFqlDz0SHCmPkunEVebGp"
        "BPxT3Xw8/FNZjCSXpOGHW0FPI7nY0JVs1aqVV+i2bdv8ViCD75kzZ3rlDR061F/YMmXK5CoLfRLGOldhIoAQwRGkGiqEAsFSxlxb"
        "RvoHhyAIrjFfnR7HIbGTfi3A9fgvHYGrQ+JIDkkHjFx1Es9tAHy06Acb8IhPoH/Rn/ggGzZscN6AAQM84VQsSd2/f79XvZKFnRjP"
        "HwlDEKOnTp3yZLVr185LVsHQW6i4adOmeTXw22fRokV24MAB/2JckYULF/ohiwIB/k2HGFLAS/msFVcK+PEmAPEqVKhgO3fu9KRz"
        "LTkjlb81+5OJIsGurqH05btAwhRAtWrVvL8ADsZLoxeIL7p06VKbOHGi8+gNY8aM8avQp08fW7lypV8Dki6kByUxUWf16tV/6ETo"
        "ACl0mKJQoDKy+ryyVKeqZteuXdalSxcbO3asy6xfv96qVq2aq1bZx7/Io9CmjBI4vYWmTfM/ceKEGyVJzOlr8+bN84bJ00yVMfKC"
        "0aAPHjzoX09ID5bqUK2pzv9BWkER8Nnn8Lx+VNWSJUv8atOzSAwvPWceP368x3PhwoXcAye7+tisoTxtSkDZp0RnzJjhiaIpT506"
        "1ROGYV44KokmSx8ZMWKEnT592vr3728jR470nwdUH5DDCP4e/ZdOYXoRxMvHLQrskzB+P44ePdob+bhx4/wKcktIDC2BvgXoadys"
        "wpIF4JHcTOfOnbPz3wJ8Db4ySoCRpssDwNVDDkcEwQhojASg68nrhyN+SwGCQI+kA74wSaYvcsWRK1WqlAejXsnvPaAEkmAo/ifF"
        "BnL0Qx4fgG9iAPiFANcQGVoAZ0QPX8R05swZ/1fAX0C9jCLlBRAfZ81k/6w6V9nEKIKQEoeweNGQZzwxrDWj9CQHCfAAPA8k2QfR"
        "LnOImGIVUEWKUzzJyp74AB4figrP/qSygQMH2p49e7wKecTSGAA8Ek1FZ7I9yq0RNNUlZyIdjKCiMeZ6doW4HxMiEtATkFNCQTyc"
        "AA8/6lnyyag4geaQfGov+udfBleUSuMHMz2MnkZPjUCX2HROKNOhQwe3yIaarpww6sVw4eCUOYY4hPgalQA5ZB5l0GOPOftAPiPk"
        "V6PmAL9A63TEruZA/gFXEcIeD5x+SAPkpKdY5cvP0rZt23w2IK5jChImBQHZeFDpC0oyUMJA1ANRJx4OsBYpWVC6J2itWLSndQQx"
        "QPEDgKiXymidRzJgcj+1GZ2xL574GnWACIxqvyjIDyOkGDQnFkbNRdqXvGLSXGAdoT1GJTDa0F5ccw5koo7zERKxGQlEPmCUsnhA"
        "c+0BnKbQwUUxcOYxQZHYlw7zuBYPaA/EOJHRGnupHY2AuOUTRDvew2Iv0iajml3K58oBDGBc+5D6E/yYMOm7039lmYuAvihIDxHn"
        "IOox4ivuR3+QfMaqifri6cxRB/oNs38AkgR7ZEqUED8AAAAASUVORK5CYII="
    ),
    "Rejoin_Modifiers.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAFgAAAAUCAYAAAAJD/ojAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAknSURBVFhHnZhXiJU7EMdn1957xS72LopdRF8ExQaK2BVFUR9U7Cj6YnsRFbE/iCg2xF5QEbEhKjbsvffee25+"
        "s2f2Zr/9znq5fwgnmUwmk38mk3wnpU2bNk4CpKSkiHNO/vz5I6mpqVqoW9v6o4iTgWRyQ9hvdZsj9IW6+YKM+n+Bjc+WLZva+PXr"
        "V7qtcI5kv4zNnj27tn///q02qYe/cTC+MnmJUYqBuhm2CU3H2lFZMvnf2tFC/5MnT+T+/fvy48ePdJn5gl8fPnyQd+/eydevX9P1"
        "7927J9++fUu3Ywjbf/sNYWRbPStiQ6hu69at3ePHj+Xly5cJsUipUqW0sOs4zUIsellAqFu8eHEpU6ZMohWPOKfj8PTpU3n16pXW"
        "c+TIIfny5ZNhw4ZJ27ZtpW/fvlK+fHntw48XL15Irly5pGPHjqp38+ZN2bVrl0ycODFdv0KFCjo3hbVY3QhKRpTJbTPxBQ4YGxf5"
        "IUzOWMaltGrVyl24cEE+fvyYUBGpV6+eOs3RsCNFIYpY1PHjxxOaIvnz51f9EEwAbLKwHsqiuHTpknz69EnrgwcPls2bN8ubN28k"
        "Z86c0qdPH7l8+bLOj6/169eXdevWqY/g5MmTSizjTf/q1atpi/RzQgwkUacA+zW/DNSRQRIbQwl5iEMot7H4kUoluuARI0bI8+fP"
        "1Sh9Vp49eyYjR45MaP0LbJidsIQyq8fpWYkCMiGZEwaBRia+zZkzR9tnzpyRgQMHyuTJkyVv3rwZ9CEXu0YYiBIRnTfUBWwMMN2w"
        "L0p2XF9Ks2bNXBg5gAipWrWqVKpUSds2Kenhzp07ujMGIrh27dpaR+ft27eaE4l2dp5+0giLDcHmkWqYl8iCHMZ+//5d+4ng3bt3"
        "p6cjbNWqVUsePHigedcWQwpZtWqVks08BAFAv2HDhuo7fcyBXxTyM8ThW8mSJXUjAWNtPvo5xV++fNF65cqVJXfu3DqeU0XOxzYy"
        "bBQoUEDHAYKIMVpC1g0o9+zZU43RT8HooEGDMpALrB9CWfyQIUPk1KlTShabsWjRIp0wtPX582e1RxRyIZF316xZkymXs9E2pn//"
        "/vL+/XsZN26ctg0rV67U9rRp03TOUB8iIeHnz59y9+5dXdPRo0dVj4tzyZIluhGW923DKYxfuHChysaMGaM+k+fbt28ve/fuVTll"
        "//790rx5c7XPvKyVAmhnShEXL17U31GjRqkBG4QTpA6wZ88e/TXQz7HcsWOHTJ06VapUqaJtdrd79+56XNllooFIYoGHDx+Wfv36"
        "SaFChTRy/GUr+/btS1iMB2Thx/Xr1xOSNFJoI6c/CqIIMjdt2iSzZs2SGjVqqG/odunSRY4dOyblypXLcIIBl2WPHj3k0aNHGq34"
        "PGXKFFm8eLE0atRIN//169d6F6xYsULXgi+szwimLo0bN3b+eHoe0+B3y/nd0nq7du1c3bp1nT+arlu3birzE7qhQ4dqHTDWE+p8"
        "DtS2P+LO77LzxDlPqjtx4oTK/QXlihQp4nzacfPmzVOZjzCdA90SJUq4I0eOqBz40+L8BiVaae2aNWuqnvc9IU2T4wNzhetAju+e"
        "UDd27FiV+dTiWrZs6QoXLuwKFizoVq9erfIbN264okWLOp8StA38aXTVqlVzxYoVU31/qp0nVft85Ot4Cnx5Qp2/UHUdTZo0cXDq"
        "o9o1bdrUZUoRHGVuZ2BRTBk9erTKyHfkzxCM4dYGjOX2Jod7MnTXAXmaPMYx95ulsrVr14pfnOqWLl1aJk2apPJk4DhXrFhR83UI"
        "TgzyaATTJvIGDBig7QULFojfcE0ZrIF0AzyR6kMIUhvRj5zC3KQJQK7PkyeP3ivoUSdN+E3KkB6ox74iyE2A440RiOrQoYOGPDkv"
        "CvIvRw+Qf7k8sMlYSzkAHXQhGpw+fVovEoAul22IuCMP4uTJdMnDdglPnz5d/SIdQBZH3ACJRg4g5XD52ZH3kSwTJkzQNrmcNHPo"
        "0CHlo2vXrroBrNts8EtRgqMgp7HTDOKWtty7fft2zT3/BSwkunEglBEhAHIo1k4G04sCWdxcALmNsfwdV+z1EsJIwgZ3BfeGTzsy"
        "c+ZMvdy4V7jUN27cqPcSH0o2H79shq4o6jRHgGQOePfyegBLly7Vvih4WXDUgc9B6UeJY1inTh2tA3SICl4OoEWLFukbxrHlwvg/"
        "YDFWQtDGNwgERJvP4+LzsBbqVgieKA9GMHj48KG+fIj6uXPn6jOyevXq0qlTJ+33z121ad8ONi41ahRwbHmK8DkKoT6ZKzkc6egz"
        "DbC769ev1zrPG1IBzxbG4wy4du2aPtvQ3blzp8p69+6tEXH79m3dfZ5tIaKEgTgiLcqiQM6Tc8OGDdrmToEENpPSq1cvzdGksbJl"
        "y6pOCLOJHfyGYNbkL3kNIrgLI99IRZ4lwQBSw3y7fPlyzUNxYPJly5Zp/mUDyE18fvM88p/i+szBKd65XATz58/Xjxby7oEDB+T8"
        "+fOqm8wXA06b4yEgIk6ODILxjacia+Iz/8qVK3Lr1i092v6FIGfPnlUfs9o4yN22bZvWOd0EBXfGwYMHVYYNbNvXpvmjBMftPhPz"
        "YiCPcFHwOoDIZCRAXufOnWX27NkaqbwtGbd161a9YXnrcvsznkXzv8GWLVs0RfDHEm9gLtWsgJ9xviaTs0jmwz6+zZgxQ184tCH7"
        "3LlzGtX+GRf7h1VIMP3Dhw+X8ePHa/DABTJONu9r/nTCrvFj41L856Tj256nFp3sAJ/IXHAcH44Ecp5RGGVSCLSnmn/barK3C4oc"
        "xVOMI4gN0g1phmg1MDn9XDrc6LTt6WUPfruVsQXML+bBJ/syRM6rBB9Nbvr2dKOgyyc2hZcM4D5gTWw44Dka8sC/d8xH24B/6GAD"
        "m5xYxhOQ5g/68KNzN2jQwMvT/oYLDYFo22ByxlEA462thn2xvhChLK5u4yjJ5gfhWINFLL5Y9GXlS9S+6UAS481eFHEywHgCKRyr"
        "YRcll3oyIyEwaE7xa4sKi01mJZRF9bKyE5as+s2G1UFY/xts3TYmygsI7YUy6pSwP/aZhkJWhQXaA9xkf2tTt2KysC+sR3VMFtcX"
        "6vBrC6TYWsLfEFE9io3HntVDfqiH7XB85lOcIv8AeaivmfTGuj0AAAAASUVORK5CYII="
    ),
    "Rejoin_Weaken.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAO0AAAAlCAYAAACu9m5WAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAABoCSURBVHhe1dsF0C1H0QbgvQnuTnBPQggx3J1Ci8ISHEJwd3d3CncLDoUX7u7u7u7u5M8zfO+hM9nds+fei/xv"
        "1dSO9PT09HTP9Mz5vm0HHHDAYcMItm3btpWbxhSN+sMOO2wtj7n28Ei+IvVTWNcOO4NmCQ9Yp4c5LNVRxVSfKfopLJW70uGfcj/W"
        "urHH2qf69PVjY6qbSlPQ/x//+Ef71jSF8Ko06sb61HHnZICpdvWTTgsZfHsG6Put4wE9zZKxgzEljaGn68dYwmcdTc8TxuYxRrcE"
        "m/bZGWNvQjvGOzqbawv6cjBVH3677LJL+yonVdQyXn1Kff1WqOt5boJ1fdfJC+q27b///oelsTbMYa59E17rxtkUY4ru0Su+ltM/"
        "dZVfTxP05R5Tc6z8p3iHpvKo/SoqzRhq+zqZYR2/HmP8U5fyunHXtdcx5Pty/fbAO2msDPL617o5zI0VPn/961+HP/7xj62+8j72"
        "sY89HOUoRzkSj9DU+ppvbZx2q7xCz2gMczQZOPkpLKVbgvBZh368vl9tX8JzHc2Ozmt7+k/1WTon2FG5x7Bk7H7clOsXnzH5wt+3"
        "5vNNPujL24PIMcb7T3/6Uzv9L33pSw+XuMQlhhOd6ETDN7/5zeEd73jH8P73v7/1PeYxj7mKEGBqfqlv+TGnhb7TFNbRLeUDm9BW"
        "LFH+f5Kmx/bOK9i0P/rVAm/n2Dsq8xzGeNe6vr2WzSspSL621fb/Bn7/+983h7znPe85XOACFxje/e53D9/73veGYxzjGMO5z33u"
        "4eMf//jwlKc8pZ3ExznOcbZ6HRFTa7Btv/32mw2P5Wt9VcYU02CsfV0f6MeEftxaDuZoKj/5Mb5BbQ/m6NJW+4zxgEo/hbF+Peb4"
        "TPVPfS93xbqx+/Z19IAmdEvoyVVl6/OSx6KUg5oHY6Uu+f5bUWXr2ypCV3kH6jjs8Y9//OEOd7jDcN7znnd47GMfO3zgAx9oYfLR"
        "j370Yd999xtudKNDhk9/+tPDM57xjFZ/rGMd6wgnbo8q96677bbb/bbqj4AqyBzm6OpAc1g61hTmFLwplvBaOt6Ozguiw+SXIv3W"
        "9dEemp42bX1iXDUv7brrrqt8rZNqX2kMmaNv0t///vdV4qRS8qH5XwJ5/vKXvwxHO9rRhrvc5S7DhS984eFe97rX8K53vavJrN73"
        "a1/72vCtb31rOPCgA4eTnvSkwyc+8Ynhb3/7W9NVMKWnpkMn7VZ5EggJ9Oc//3n47ne/2wYGC3P6059+OOpRj9rKgOY73/nOikaI"
        "gCbA51e/+tXw4x//eKV0l/LTnva0LQ8RWHvGrhirm6P5yU9+MvziF79oeaAo94sxPj20Rx4YG7e2L0X69Pxq/RzfuTYh1y9/+cvh"
        "d7/7XTMG6yQsO+EJT9hCMX3T35d+fvrTn7byFNDR2ylOcYqWj3y+P/vZz4af//znbVyGSbcnOclJtnr+a47f/va3h1//+tctj9eJ"
        "T3zilgc0oasYq/tfBDnN36bykIc8ZDjggAOG+9///sN73/ve4bjHPW57dJLQ/eEPf2hrc57znKedxk7cRzziEU13fMl6QdZIn+Rh"
        "kdMGjv0rXOEKw2Me85hWFpM/9KEPPcIC/eAHPxie9axnDZe//OVb+epXv/rwxS9+sRkNEMBOw/mPd7zjtfKpTnWq4ZSnPGVrH0MV"
        "fgx9fYwp+NKXvtRkB8Z1xjOecTjTmc7Uyj3W8dpeVKUHfd06mql8xfe///22CXr82GuvvYYTnOAEbfe3kbpXfepTn2rzZ0DB5z73"
        "ubaWdafvwSBvdatbDXvvvfdWzT/xla98ZTjf+c7XxuOENou3ve1tw3ve8542Dt1JHPusZz3rcP3rX7/J8epXv7qt+ZhuU2eOO0P3"
        "/26Q0WHle/e7373dYZ/4xCcOb3zjG5vdS8JiOufUv/nNb9qa0OnFL37x4YY3vOHwkY98ZHjCE57Q1gC9udc1xjvlXRRqmoO4+61v"
        "fetWaWjHvx2jwouZ+sCr2W9/+9sVfycwh+Gw4EJO+AgpJbxK6utNLF8pu1jKqUte3wrl9OmTnU5Kvn6XpPRfkvq+Vf6kOs8+3ycb"
        "oUeO+93vfs1wnKzmymDOcpazHH6PutFw85vffPj6179+hDXXjuc6WDtrlWSDvtCFLjRc61rXahu3sZyyBx544HCxi12sneD6MGgn"
        "/jWvec3mvC95yUuGk5/85G3sHrWub4+8/2vJyWk9nbD0/uQnP3l4+9vf3uro1QnKEUWdknLW0Qb23Oc+t21897jHPdo6OmD6MTJ/"
        "2Lbvvvu2nApKj4H7pi6Qd0p+/vOfH0596lO3OuFS8nYRBvDBD36wlcEpZyJnPvOZW9kuY1d+3OMe18oPfvCDm9D1tN5ZiPyf/exn"
        "V5uLk9amseeee7ZyjyhmDnM0VV/rENp1Y3p1tDMD4yd/nCx9PWYwhjvf+c6r8qte9ap2EnoUucpVrjKc7nSna22vfe1rhw996EOr"
        "8JQjiZjghS984fDlL3+55Ss4n7VzjcmYnP/hD3944/+6172ubcBnP/vZh6te9aotDL7rXe/aTlt07njy1pvDOwA2xY6uTUVdp6V9"
        "An31kejZ/O94xzs2x2PX7rDWJ3xFPq4lHJceXdUcZPwluOAFL9g2Vevy9Kc/ffU41duT8i6Y8+6xnb7WJS/cqqetuNwi4GHHscNW"
        "cA4C5zTgPPUkfstb3tJ4AoP80Y9+tNoYODyDtVNXRGESQ3KpF4Lr89WvfrWFiIxcOyWNQT2lUaB+HFsypmhBm4TPD3/4wybTF77w"
        "hZVMlBoaCQ0+Qk1fd0RycACy+X2OrLWP+a5L6LwBCJ2k/fffv+m5tvuaR9X9ox/96HZX4sgciHNFj/QvjNXXXKN/ICsji6EliYxO"
        "c5rTrAwRrDuDBRuBU+T1r399K6vX7u3iUpe6VNto3vCGN7RNc53D1jEga536sXytW4Laf1NkLLozFw5Lp+6wrgY5VZ20bD7gP9ZD"
        "yiksOeje9773DY961KPaazPn1Y6/cZqjHs4n9Ifn/1XYqmjfEPpWb7d4b37zm7dKQwuPGCPmjEOMDgwrSBjNSNDqA/IMC3+7PSEf"
        "+MAHtjpGxVHcDSiAAzBOhuDLmezgjFi4xZEY9yc/+cmmPCEGQ0bbL4yyersdBeuL3obh0UybxMB8hT0cGv9vfOMb7f5HDxy10uIh"
        "CXnw1s/jizbGzOiFjOmTRC9zqYcNpybz8TWuXVoSKgtVrSX90TEHAg8jxgX6FEYHZKVruqdfIXC/aQZ4p83mbMNMBKPeGtHvla98"
        "5SbPa17zmhYWT8E8slbJ15T6oOaDsbopbELbg/4cZPe+972bo7nLOmHN14bnG6c1jnW0RnTGafVNu681+ehHP9pshk3f8pa3bP30"
        "OZKPakhjUgaohhMDMwDjyITjtNqcPkJheNrTnrZ6kbzoRS/anNAienQ62clO1urf+c53tslxWI8mH/vYx4brXOc67YGCcMK3K13p"
        "Su0F7jKXuUwzusjjYUWo9YIXvGC4yEUusjrNOcbBBx/cFGC3J1MPspOFYzkh0OF5tatdrW08FMpB99lnn1mZPMox8ugi4CD4Xu96"
        "12u86exc5zpXO2nIZ+zovSaoeejLU+AMNkZOJtl89LOO6unGVQbozu6u3brFaenAPN17bUyPf/zjh0MOOaTRWaPIIgGdf/jDH255"
        "p80zn/nMFgYD/RvT4xXgZ+1zAIRHkHLlX/OQ8lxaSrdpqlBmV6555z//+dvvsOyBToH92CjZNpsxZ33o2nrQSyJXX+3q6NPPPx5y"
        "z3nOc7aQ2UEWHtD6MyDJjjuW4qxxFgm9+wt42sYIjfsMYYGB5kT2GMVwnL5xahAaE5RAL3rRi9qk0eU3Ls7HwEzI5Z5xGcv4JnWT"
        "m9yk8bHDX+Ma12jOy9DAziUkZGw9KJBhv/SlL139HHWLW9yinaZxYIpaIhMnRl9BJ+blhLHZ2OTAAnlsyM9PWYggxmFzchdN6jee"
        "2uY0tE7ASCRrYN42Hn05or/MsXlYJ/dWP7kAXSY8Jg/5vPKS1dytqdOEnvALyIqHKEd0U+GF2juFByobxctf/vI2DtlA3zr3zDtf"
        "qPmKXmc7A0t4kqfKZP0veclLtrWVeh7a6VuSB7bLVvBRVx03NL42PK/J/EYf9PExa73t8EVZSZKBI9zUZCzejW984/bDMbizuAuJ"
        "xb1cMpS8Ij7vec9rNB6i1D/sYQ8brnvd67a6PfbYo+0kt7vd7Ybb3/72rc7uhZf+Qk0Tckc0OX898oAHPKAtvrsEJ2JM6k1Kvbuj"
        "e6VHF+M51Skq4bqT0aMXuZyE4C5BLicBiArIU2UiA+PGhzFXmcxZn4xhPK+1WQxtOd3kyXaGM5yh0dI1PVedC9ef9KQntfI6cBqb"
        "jU0Kws94nC2nK3CuF7/4xW3xE6baIEQM7sP6MRZGKLx1iuS6w+lsXLvttlubU+TFy7VCnSuDqEuy3jYKGwvd2twYHCNG5xseQS3H"
        "9lKXb6+rqT59f+jbK13FXP+U2dahhx7a7qKiSm3CXqExO7Fxskk2oS0OjEadpB3YCfCr/NJys5vdrB1wfiKztlWOI/3kUxun2jBx"
        "SgaOcXe1PIQIe9F49g44mHDZF9wNGYxT7HKXu1yr005or9Gc0k7udHUfAjsPR3aKmbDfwdxfGaj7JX7nOMc5WjtQXH8Kwt3udreV"
        "w77yla8cHvSgBzXjzhzJ0Mvk1ZSxMdoxmSo8PnFOmwhHZfCMF/TNbht95gs1vwl6frUcuCuJThgV+UBk4SQUEruXPec5z1ltPq94"
        "xSuGN73pTS3P2Kwdh6x8GaKQ32lO7zYD82Z0HF80Qmd+t7fRX/GKV2zOa/Mcc5igl793oupAkHLqaj7o2/PtU887qHXWkA2ba6LL"
        "yMg2tcf2bO5SNjtJG7qU9ZXU8R0+ICJLe8W2vffe+8jSbSFCjMGLrROBIXNSRm6nYKS3ve1t208Ayv6jYb/99mshGWeJsbvjuHSj"
        "IZzFXwfGb8f2EmnRGRxDcK92atvleuSlMobYw12TDFE8WAxGvVQmUQFlZwxXB6czQwahuE3OhgJkyk9gY/B45ffWCndL8DesIpHA"
        "g5GdOvOMAbib502Bw/mjiGtf+9rNYZ2O97nPfZrBaZuCOeHhzgZO9Gc/+9nNCadgA/V7rI3cHddGat0ZbYDvIx/5yLbZ0XuMMrLX"
        "b4+0zaH2G6Od41HH7mlqm8NGFGITfOpTn9r+mMRcJD5Brwln2RFdJ/Iyb5sfx8UPLf2os242ODqjI28jiaKCdtJOQVtSD8JxVvB6"
        "5rGJw4Jnb7uuwbJTa3fnDBhxL8w6mJyJOvk4gLuTDcKm4KcYIe+d7nSn1am2BIzQ/a/uepuATPpuin6sWrbL2hST6DMQ+nPatNG5"
        "tSCDDYSR+DIcG4MkSvAinN/GGY+Q2GblNLQB2jhtVPQbORgUIwqMk9NjDGhdCzisUNyG7a2BQXrRdn1i4AzX1SmPWzD1DZTH2lJf"
        "U8VU+1i9NOewFfQuNPZw5ODwjiFktg6cNcl6SNVG8KJH9fTviijPmYXErmX+dc+bEGdPn6DdfnuBxoAmCThlQmSLKbQCp4TT1KTR"
        "5DHKfVEIBiZjwgzeLmR3BieSfvmdUKIcdRJjc1IwMI9Myk43j1Lu1R5RPERNnarBbW5zmxZag4cW92QnQjAmk5MsqZfJib+9qDoF"
        "eUZOpzVVkCH1dAjk5ahkkSJ/YINMlAOuHtZBtCQqkEQrHBgiV50bp+yjj9AxOicFx3QKeQElm7u7dn804I8rPLKAez2DXQL9e2Tc"
        "nY3wrLzH8tZd3tsDx/VHLeyQ45oX3XJMGyinlNSlf5xWO33RrTcEf+RCV65s6DNOxeqXXw194xwYTv8njcBJGQhejM+OmztfXo79"
        "xVTG45g5SYST7jzCTQtsYTkIZ/RY5bUuk919991bH5uEENGmwIjdqab+2gkYlj9SsDu6h8Otb33rFo5SHphbL5PNwqOXU5Ax9jL1"
        "2ESXPaKbTWADucENbtBkksjJAS08fQlzz3a2s21R//OfKMyDUdi4zMPpx+gkc+LknDnw+EbHka/K6CQXwtuoPc6xAevvVAVfp00t"
        "B1Nz7cf4T6OOT79kTqI3tku/NiiO5jAQZdBfTk/tnNhBIsnTbXVaefq/733v28JsfxiDNqdsj9VDVJB86mtbkDqnk/tfBae1cAHD"
        "ECZV1NDYTu50JDx43Tz44INXd1e/w/o91r1KSEdZkhMC/DzhlPfAw/FqSDEGiiKfE8M4gZ8oKFhyYgklq0xOEC/RTiP3816mKT3N"
        "6bDWj9GljpG87GUva4m+GVDakhhQ1bPfTekjxmZTzW+m6G241sBmlM2XXmxGdA/+9PGyl71sywulbbZo9Id8RT6uKx66RFA2UTqk"
        "F5sFGQ466KDmtDYGUG8NwiNQXpp6+qDWzaUx2oDMNcVRa7Ip0Tsn9YLs6uLdwF8JOqhyurI5eYeCFMdVD96DrI0T20lL1w4OqDJF"
        "xm177bXX6p/g54AmDEJvsfzsk7CXIF5h60MF4S28v2wKMimKwMtdymOSOylljMHjjskJ69xpGVQeSCr82G+jYECQySdkdvo4MSU/"
        "VfhZxA4JjNcfWHgNpTh38CUyiQzcLy1e6oXr9SEK7/oQJZIYw9haWHiLDgmdg6yLJCR22gqzpoCXk8ELd36rJbuf4ZwSY7BWriPG"
        "iD7B2DY2umJsDNLPPE55a6veA1he6isOPfTQdnJn8w4yH8h3Z6LyH9O1Oomea3vNV7lyh+WI8l7NhcnPf/7z2waGD7+Io2ejsp76"
        "2PRFeu6wdIhHf+j0cq7utDWlrqKWk7fr5s4KQgQCho/EwOrPQxzdQ4pFBULa7YUFjNrJKtRSz9HcgfzPoTCNc+jndOZMN73pTdvC"
        "G9OdwM8VnEjfdSCbk1NI4lUUOBqejM0YHtrmZEKPLnPpET1tgqq7JAtP11J1WMhcLazNhqx+F/V7q81QO6Pyk5i18irpj1GcpuGv"
        "nz8kcW2gTwal3kORtRPJ0HHG1gZ440tnNkqPTH4Djz7ohk0w4Dw6+Sqr7x0WIlPG6LGj9T1vsnIk8vtKnIs+e0c134S0HE5SVq8f"
        "XnTgUVQUt++++7YNT1/6y4mrHzsS/Xh0+sxnPtN+SQHXwR6ROXJvOzy8PNJJq7wi2Mr3NKCOMecUUHbS9oZloeorpB1e+BSEN+Pi"
        "MCYkr54yLe7YjuzERU+JFCZUQW+8gOFAHV8obaMAinQSUirgy5nxAu3uwU7RXqbQqHOCZwxlc+Rk4AQSDkanZEoIOgd8tgeMgm6q"
        "zIyKvPRuEwD1kQnQm4P1jCGaA131G1P6uiIZC+jVxtoDT4ksHML8yVHtqsoBfXkMvfxjQCORP/nU128PfOlAyhj9twIftGyR3vyF"
        "nV9VbKAiL+NH7/p733GyOqw4LJ3XB86MEfmUk29O23KHI5VLUGkrwzEs5Ru6MaVArUc7RTeFpfSb8q3Qt5/v0vnPYVMeY3IEOypP"
        "7T+lqzkdzvXBe67vHPTtw1pQToKME1TnrGP35SVAzwFt6h47/RzpOuJv2G2KNitXQSesaMNf4zl4hMSRyRefKmOg7ghOuw5TTKYG"
        "WIqpvpsoLLThNdW31lfasX5LeI7xWIqevufft4+N1eeh7zeFStePXbGU3xiPOb4w1T42F/mklIPk+4igAk+JgwYZp6/fFFUW4KAi"
        "Tv+t447LaUWQ7vveStxh/UebKKy+E0zhCHPd2U5b80sxRR+FrsNSOvh30Qabzn0O28trk35o181zKb+ezxL9hSZj9GP19b5JU8ip"
        "CVUG+ThmP26l215UmfBzTXHyu7v6c1ePn950/JzofUEoXUPidQjNtj333HPR63HQ0yqPTXgTnjuKTRS+lHZHFnFnzH2Ox5TOp7Cj"
        "8tTxkl8iQ+hgnQzak3r0dfhm7F4G5bFQ9z+JyGt8byXC5dxpIx9n7UP5sblXaNe/Oe1W3ZFQBx9j2NdN0fXI4MnDJuXke/T1fd9A"
        "OW2wlN8UKq8x9O1Lxp/jmbbab50MPaboe9mCWjdFMwZ0eQTqET5py3zqvGoelKXqmJUGr5RrHqoM6msZaj/oy8FY3x79WFDr5FMP"
        "Pb/annxoZp22omc6hdCNCRpEiOShF3AJltIFm46xKX8Ym2+Pfvzap8q4CUI/NsfKq+c7N17qfKV6XxyjX4KMl2+POKNv8oExp/r9"
        "N9DL0+tkXXuPJe34bdtjjz1aeNwKW52Sr3U9xmiD2mesf2in2mp95dtjrq3HJrRQZawyVT592xjG+i/pV1HpxvqoG6Pp6/r6fi6b"
        "AH3tD2N1KccBhYu+lW6sT5VxLA99OUi9b0Xq6rfHWB8Y49n3D03fp+ZrGcZoexyJB6etDT1S34i3UspTqHQVU33GBM6k5tDTbA8P"
        "6OlSxk++8k259unHhbG6TTDXv5cnWCKHcu0zhima1Pn2Kah5mCrnOzZWXw5CW/vIB7VtjG8w17YUUzJMYR1NbV8n3+r/aeeY9gyD"
        "ME/d2CRqfmdgU2VvQr8p7ynszDkv4bVEbjSVbl2fTdqX8t3RMf8/YG69tretx7Z99tmnaSqdNlXcugXbGUaHR2h2RL4lqPR13Dls"
        "ovBNsY535Fsn67p5zLVHhkpT5er7pjzWb26cvq2fe8+3Yo4vTMk7NUYwNocx9Hz68VKeqg9SHhtvxcM/DNSKKeHGBoDQT/Wb6rNu"
        "vCn09PjM8dhR/kswNsc5VPqx8TKnOb7r5j2GTeXcXkzJtU7epfPJPKKjTfqN0Va9LOU1hiX6zWNeHaf2m5uPvu0lfvfdd99IyiWC"
        "BZvQTsEEKp9NlLqOdh3vvn0JNqXPmGP9NuW1BOt41jlPzb+vzxzmsI5mCY85TMn678DY/JXH6nrMyZi22tc36Z9Ou8vwf9kN43SI"
        "UINEAAAAAElFTkSuQmCC"
    ),
    "Rejoin_FriendsOnly.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAHgAAAAaCAYAAAB8WJiDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAyrSURBVGhDlZp5rM5HF8fnXkvtVYpaWlW1xBpXxRrSf5qGLohKRUlU0zQVCWKJiJbaIwSREP7StKpotGkklIgI"
        "impViS322Klaat9en8P3ec8d83vKNzl+s5xz5sw5M2dmnqugY8eOD8JjPHjwINy/fz+UKFEiFBYWWhmiXFBQ8JjrSaT60AUhC927"
        "dy9Xz6frWYA+dPGN4dsoa2yALch5O1I6BMnjF/xBOZYH0qF26vIfsnfv3rX2WC4F6SpVqpTJpcZM6WFuJUuWNLp9+3awGXtGGQO8"
        "0nwk+LIgp6YMBCmZLGjSQGW+KRIoKyjAl2PeFCQvOykLWXp8na9kPU8K3j/w+s2gPk8p0O7lHnnfgeDSKWM889NAvDIQyCkpPRqH"
        "bz5SYPiq7Ntj8vx8NQZ1D/H/F3mfeKTaBN+Xjw9436gs32t8zxMjJQ8KpcAroYwjVH9aaBL6YqDXJdDmSUFIEX1Z/XF7Pj2aF+Rt"
        "UNnD131Z+j2yeAF1+RBZ4P2gPt8mZLV7xPK+LlsKKeQqj3cceRxIUP36ZoH+EydOhMOHD1v+p+6d4usq+3rc/jS8MYkHSAbQpnuA"
        "6jF5Wd8uh6kP+Hpc9vAOlz+BL8eQDniwSTrU5usx1Kfx7JJF5fTp0+HChQvWoc4YpO/GjRuH0qVL54zwOHbsWBg4cGDo3Llz+Oij"
        "j0K9evWKGRjLqJ7qE3x7Pj6Bfuby999/W53LRsOGDc12f7l6Gl0A+5Uqkb98+XK4dOlSuHXrlvU/99xzoUqVKqFy5cpWB9INIQtx"
        "UZIe2vkKp06dMt8DLlWyF9u1KOH3MiDWJV9LDsrt4PPnz4crV66Eq1evhn///de+MQ0dOtS+kvGEciY/evTo8Oabb4YuXbqEGzdu"
        "FOvXV+W4L66n2oFviwkQXOYA9ejRw4IhWSGWAb7u+3Eaczl+/Hj48MMPw5o1a8K5c+eMKH/wwQfhyJEjxuOBLEGVTiEOFMGVj99/"
        "//1w8+ZN44FSdgsqx36CtDAswLpYCWfOnAn79+9/grTDpZCvp7Jly4Zly5aFkydPhi1btuQmJ5JcStbzqT9uy9fuKQXJgZhPdd+v"
        "r4LLItm6dWsYP358aNGiRbh48aItJMpfffVV+PXXXy0w8HldqQA/LbwewByA2r0vCKjqfFUuaN++/QO29I4dO2wFgQEDBoSffvrJ"
        "Au9BnfTM5ACTr1ChQrh27ZqVCfDZs2etD96WLVtaugAMxg5HFidItlq1aqYTsLDoh5dUVbVqVUuHnOeqv/DCC48Mf7wgSX1kH3Yr"
        "kyxXrlz4559/cimUuWzfvt1SKRkKfdohtL344ouhYsWKxuv1ApxEgNidmzZtCg0aNAh79uwJ/fr1s3sGqFu3bvj2229D06ZNbRN0"
        "6tTJ+FjkLAD04QM/F+bLuLSBv/76q5jvWSz4QrvwpZdeCjVq1LAy8z1w4EDuTc3xULt2beuD8Ds2Mw5j261K0fZ4+eWXQ/369cNr"
        "r72W+zIZAqD0179//zB79mzb2cOGDbMJaCCcgJPRfefOHXNSr169wsaNGy0ApLt58+bZ5JUZlFpZMKRW0tUff/xhgeH73nvvhaNH"
        "j+bGuH79utkzZcoUa0fP119/HWrWrPl4Fo+ADYz/1ltvhdWrVxsftHbtWgsIdwf0eaiO4/v27WtBY2G8++675txGjRoZAdrY5dT7"
        "9Olj9mouyHfv3t1s//33322Rs+C6desWDh06lJuLB/7Cf8jiK/QwBwi7J0yYYG379u0zHvVBwO9mC7BWigcBOHjwoBmhL0Z7vpEj"
        "R4aePXvazTk+f4CMR9fSpUvDpEmTzAmsblYXk2ZnsHAw2OOzzz4L06dPN9tYja+++mqYMWOGnYEsJJxMcNevX28Xuueff95WPQFb"
        "tWrVYy2PgFPGjBkT5s6dG1q1amVOUXpdsGCBLVR0xcBGHMwcwY8//mi2kKmEMmXKWNuKFSusznmMbo+sufTu3fsJXoB+xiJIZC4u"
        "rQoydrKgwHfffWeXOwVX/lY8aSvkH213gR3BGYrzPXE79SAVNGnSJLRu3TrMnz/f6h4MworFgVy8cOzDW7s5lgyxaNEiS5M4Wald"
        "qFOnjukuKioyh5AaweDBg83pBHnIkCHWR6ZAP3qpk7I9yAiffvqplckaZCMWGpdGbPz4449zjpaTIAKM7ubNm1vftm3b7FjxPKBS"
        "pUq2KwG87HQPzQU/8bLwc0kFGBCTdevWWfmdd97JLepXXnnF5gi+//57CzB2KMig2A6mEgeYnK8U5CnGnDlzTJYdSBrHITEIBgEG"
        "s2bNCps3b7YUBJHWAekPeTkMoJvVTjBw6sKFC60dPpxOGiT1gW+++cbOJfqwfdSoUdYusPAIMuDsY4ewMxiDcrt27ews8/ZjC3Xs"
        "JDsAFqvuFAJ8nHv0AXhjfzIOfn799dftvI/n4ucNqGMPOxR07drV5gtRBpz3ZFbmBr8nBRcqjI0BAx4e9Ey8fPnyxYgLjgepTxck"
        "lMWgjQmwesHYsWOtDWdzfvrVy+S9Dp4gpD9AMFjBQBMi+OwG8Ntvv5l9BATe3bt3W7vAKh8xYoQ5mRTKEcHuwNGc8wSNXSh4O+jz"
        "wSPg9Hv6r0XAXMhU8NLn56Jd58E8uCyuXLnS5smibNasmfmL3QwIvi6cCihy0qfFaik6BdIAD25P3HhjIC9lDJKC+lkQ/tnliYWQ"
        "gmTzAUd5PuoeOH/Dhg3mpHHjxoVffvklVK9e3VIzaQ5HEnRBzuLLAt61a5e1t2nTxo4ZOVXEznrjjTeMB15kYl9IJm7Pgs5RLoWA"
        "ncu8OnToYHXsZlFKH9/YV9SLeyKCFxbFQImckQKTJYCAHcMvYQ+fZkaURTzLUgZmAb3cnAG6cDL8rHjOYg/9sgVNnTrVfm3jyOEm"
        "C9q2bWs6kFXQAF92//Lly63OzZ6sQvaRP7hc0kYf4HcA7WaPLP+kIN3oWbx4sbWxc99++20LMk9a7izxQqaucRSTYn9s8FA9q12Q"
        "UjklBkYuWbLEyoMGDbIVyLEAcYvkjOYdWKtWrcyAptpZvT///LOVuVmzOzmTmDiXRA9SGcElVX7yySd2I0WnzxraXewcgTZSpc54"
        "AsmYpFvGgki5tHGksZB5E3NcxJCPYj/RHvsUaGyyDQuK3xTwHyDo8XHJfBRLD1sCqQE0cEwpZLUDAsENm1s5ZW7j3CJxjm6BvHHj"
        "myeQ0SlwCZk5c6b9jsu5y0+Gf/75p71pYxmOBp4dgKcSY5NKeQcDxufyx2JVoPkqTfIjA08T3tLcJ+Dfu3ev0c6dO+1HDvo4z1PH"
        "GJD/8vnKQ3zMTQuZzUE7GUU/zgiac6zffqp8WmQ5WzpS/bTxwwMO+vLLL80pOIxgk2pYlTxXeEpkIUsvt2veiD/88IOdjejlDax0"
        "KdDOW3T48OEWELIKNrEreZuT+rh9+93FnEQcB4zHbZuLIouDiw9E+YsvvrA0Dy8BgVc+iZGaSwwvy07VbRrwQxFz9XrgV7r2svAU"
        "PDyvrIW3o253pB3dUGODSHPiYzJ6k8HHTiHlAulgYPoYGDlumZx1gJSHsyH4OCslj26eSNpV/DTIbRWwe7kkoZNUj+3czKmT1oCc"
        "gB3YiB7asEFnLYFjJ5BFZCPQmBBlgX50cN5rDuhgsaJH8tjOjy7en9igMbg76PWiVKt5ow9e+OCH8Av6wOeff27ZisUtfZAWlvRK"
        "NhdggcZ80CR4+1HGCTllTjZLj2+XPE6knTKQLo3loba4z9vh9WQhlqcOyRadxdLp+X3dj6G54Bsc7fuyZASNLVl0cdxQJsNNnDjR"
        "7gxsGrKNB7x6hrEJNAeQ9xYtwOyNkgIU8vUKgS9nAVkFAlCWAwD1FEmOr0h1L+f7Y8rXLx0qA1/Ognjwhed/Fr8gC5AnUxBYMibB"
        "BdwfpINvqizk7LF/E5CQF0SIup9ErBjQl0UKgC4wQHX1iWKZuN33A5Xjvph8vychVc7q95AvGEOAl3bJpPwleD5u+tycOcZ4GUyb"
        "Ni1MnjzZjiYBXq/fjwusz6doP3hsiJSRQuiTo2K+FOCLgTyyEP2qCyqnZH2byuL3ekFKPgX4WLhQVnqWzhRS8toIWXJql82c1ZQh"
        "3tfcLTjr8Tn3FP68KBm+6IaXfmRJz9QZVygoKirKecAbIgX6agJeMWXVsxD3qc5X8t6hKWTpp93rwSagepZcCvDiKOkEWfZ4aBzJ"
        "A/kGqD+fLvVzUdJPoT5IWfDjQrr4+bFy//G9WKMro0AGawJZKzwLvt/r02qnLTUhyWXpp12yfP2iexa7kGNuyFAGlIF4vD7f52XQ"
        "QRtz0mYAWXJq1/gKEn3iBeLzoF/jsnupS/b/COF/K9L6u4iXfAAAAAAASUVORK5CYII="
    ),
    "Rejoin_Create2.png": (
        "iVBORw0KGgoAAAANSUhEUgAAAEMAAAAZCAYAAABq35PiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAf1SURBVFhHnZhHqBVNE4brXnMWMybMOeewUhDEjKJgVnChqBsFcSO60YVuxIURTLgwYAQTIghmEEyImHPOOTvf"
        "PPXd93x9xznn+P8vFNNTXamrq6vnnIK+fftGhYWFVlBQYP8PoijK6DIWwnESzEG/f/+2EiVKOO/Xr19GHAI2c9lAF6DPGAr1c0G6"
        "pUuXth8/frgfdAtzJUFBZyOMhs98FMopIKAxfD2T4zQSwnE+SDdMtnLgydDE3xLBJxOQXGg4TsqKQNq7nhonoTnFjX1BOtmeApXw"
        "Bw9GMthsC0jj53vPRcnFJOdzkRC+53uGkG+NnegZSeE3b97Y69ev7evXrx5omTJlrEqVKlajRo3MuUxzkAvI4xBo8dodzYUBZsPP"
        "nz/tw4cPLkdcFSpUKGZbzySSvkuVKuV9Cl3FUaid5Pn582e7efOmjRw50g4fPmxPnjyxV69e2cmTJ2369On2+PFje/funcuiA8Jn"
        "LpIMugoIZLMlMBaBGzdu2Lhx42z8+PFWsmRJ37A0hDYE2Qk3NExiQa9evWJe5EahAwcOWJMmTVzg2bNn3m3r16/v71TMkCFD/Fmp"
        "UiXn/a/AFwlI3iLZdhSEQV+5csU+fvzo46lTp9q5c+e8OtIQLhQbAN9UBTzWxjNDPXr08GTcvn3bK6Bly5ZeHRMmTLCrV696oHXq"
        "1LHNmzdb9+7d7fnz59ahQwdr2LChPX361I8TwBhBffr0yXVIKE6xTTWRwG/fvmXkatWqlZnXTnEEXrx44YtlzNVH0jmeLOLWrVv2"
        "/v37zMJIxqZNm1ymadOmLi9/xCV/FStWtNq1a2fmqSiAj3AjvIFyBik9EoGBwYMHO69FixbWrFkzD3r06NGeSRbBmHmOEIFDkyZN"
        "shUrVjhvzpw5nhTk79696/InTpzwhNy/f99Wr17tAb18+dKDIAbZWbp0qV2/ft3evn1rFy5csLlz53rS0cWuEgE2bNjgSYLPEcff"
        "nTt3bNSoUXb8+HFPyL1792zlypW+aBItoCdgE/KegRIBgz179vhCy5UrlxEioxyhESNG2NixY+3MmTOe1RDz5s3zXvPw4UP78uWL"
        "6z148MC2b99uixcv9kQ/evTId2HYsGFehY0aNfKkcVTQgYd9mjWLqFevns2ePdsOHTrkySB5165dK/JovjjelVQSvW3btlR/bEaD"
        "Bg3cH7GpebJ+iLFXBtXQvn17N3j27FkvK/gihOvWresBXr582eUrV67s8gKZb9OmjXXr1s3WrFnjzqiWfv36eXLjW8uPFwFR2twE"
        "a9eu9b5EWQ8cODDTwKlG7PTv399tt2vXzuLeZlu3brVWrVo5D7ABXbp0sR07dri/iRMnFvPXsWPHP/xxCYQJCNfoyWCX2Q1AYDS3"
        "UBACGKRKKHHxBI4IBhs3buz9grNNMsDy5cvt1KlTXsYQZQ2aN2/uZ50zv3v3bmvbtq3zOCKAIybQt6Bks0SfCiPuNH+sLelPVQEp"
        "MZlksDiMAZKiIyAFCMCHUEyCUiVRwvfv371SwIIFC9wGJcru01cEqkD2e/bs6ed7//79dv78eW/qAuWe5hdd+FRr0h89CJ+hP5Kh"
        "7ydkRJ4MBFgE5Q8ICCMCgoAmxq7QlXFMKeaDurTOehphi/nJkyfb0aNHbcaMGZ5wSp8bLR/CBf2tP+xLhyQoMZ6MqlWr2q5du9zQ"
        "8OHDvWzDjxmUSdixY8fsyJEjNmDAgMx1GIJgRMjjHKxbt87POucYYizau3evJ3/+/Pkuu2TJEm/mq1atsn379jkvF7SoNH+9e/d2"
        "SvrjdgToCZlksONbtmzxr7uyZct6EPAoU64qsHPnTndIhdCxabLZQDJIMA0PzJw50/r06eNnmOMzZswYvx0uXbrkjZlAypcv77Ic"
        "U2T4nlm0aJHzQmAbO4CPQW4sbhEaetIfm4hs0h82lMSwMqxz585Rp06dotatW0fxdRTFi4/5/yLuvFHsrOgtiuLyi+Jj5HJdu3aN"
        "4gUUzUTRlClTovjMOj++CfwZfyxFp0+fLpKI3FZ8exS9RdHGjRujmjVrRvHRi+IruIj7r198EUvcTJ2HfWJE/uDBg86LF+Ey8WKj"
        "+Jsoql69ejF/cZL+8IdMfKulklcGmaIiKH16Bg3o4sWLVq1aNe/gfAQtW7bM4qR5hnNVBYj9+pNdGDp0qC1cuNC/Zuk37CDNkd2j"
        "yyMDf9asWbZ+/Xq3Hwfsuzho0KBixxXwNTpt2jSvTm4srk4+C2jM2OHngvwRe9IfPMUnsH5/xvd0sRkEuVkgypV3zhhGCVKKgG8E"
        "fY5zI3GlklB0VIpcYzRb7NG84HNFc4zC3zeUqj7FGfPRF95yjLm2ZZMbgpsCWeyRCI4x8yQJIn4An43FH0eHGMJ1aJxJhhgYg4AW"
        "BsmA5kKEvLSx9CD5SUOoK7BYdIiFsWxkiyVpXzIkE33ZS8J9FI0zQFkGeCqAkGRUFPKScrnshJRrXjY0BuE4H7R46YTJCOf8owsi"
        "GMovDCrfO2OReOFcOE7KiJc2F8rwJGDxFHj4DJGUg6SPPY2TCYH8h1qSAApaPMRYxsXTe5IvAhon5cL3NBLCoEN+CPHT5rVQxRMi"
        "tA0yPUNBhMp6T0OaY0G21HOwhR29/y1kQ/GAbPEIzMsHT975rcVmAuxlg/8HykCL1480lDEUOpdxnuE4RPjOvOxqUUn5NCAjOf0j"
        "xi2gseYUW/ge2sc3OvDRVwwCsv+9m/0DcV6KmNgwDa4AAAAASUVORK5CYII="
    ),
    "Rejoin_Start.png": (
        "iVBORw0KGgoAAAANSUhEUgAAADMAAAAUCAYAAAAgCAWkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMA"
        "AA7DAcdvqGQAAAXdSURBVFhHlZZXT1VbEMfnwJGmlEjvIAgqTcEHFCECoTwRCQnhWRI+B5/GF0J4ND4QEx+kxEhRSiw06UgTRBGQ"
        "u3+Dc7I8F7i5k6yz95419T+zZh3fo0ePTiWITk//xbqU/o88sq68z+fT9fv37z+cM95FdJkv38OHD//adZ2Z0WAD8F2e6VhgbjCu"
        "LXt3eUbBPJ4kaHZ58h0SEqLrPApByARPTk7k6OhIjo+P9Z3l8lm8I+/K8jw8PAzsuQtyvy1AI+MZ2R5Ps22+fv78ea4PW77Kykrv"
        "eaYYHh4uFRUVkpmZKRERESpgaGDo69evMjMzI3Nzcxp8amqq1NTUKP/jx4/y7ds35V+EnDmFQNsQZ9m3S9+/f5fo6Gh5/Pix/Pjx"
        "Q8bHxzUOEguWx0ZoWlpatxm7fv26tLa2Sl1dndy5c0fy8/MlLy9PSktL9ZmQkKCBf/jwQZO/deuWdHV1qd7Ozo4cHBzosgDVQWio"
        "+P1+XSRpfCN4YWFhgeCQZ58KAExKSop0dnYqwEtLS4EKnUehHrrdoF9UVCTV1dWSm5srX758kWfPnkl/f78MDg7Kp0+fZHd3V+Li"
        "4rQyJJOeni53794V78xpoARgjkD0169fyvPAkqysLJW/du2aBswei/fk5GQFDht0RlJSkga2vr6uOmVlZVJVVaW6JMjCB4kCqHUB"
        "vvwkwoqPj1f0Y2JiFIHR0VHZ3NxUQRyS5N7enjpBkSqBWmRkpOpmZ2fr3sbGhqytrWm1SAI99kGcBEj0/fv36gM7yBDswsKCbG1t"
        "qRxBEqzZNRDoFDqA7gBc4rZKQn5eYGKAFRUVpYFyHtgjAZRJjATpXQxfvXpVl7UJIMTGxqo+eiUlJdLe3h74JlASBIDe3l4ZHh7W"
        "lqRVm5qaZHl5WRMkqdXVVY0JXWxSNYLmHT/45TuYQj3j3bygDGogjXBGRoYUFhbK7du3paCgQFsMNGglZCk3hu/du6fJjo2NycTE"
        "hMzOzqoczmiH6elprcTk5KQe5uLiYq0gIAHMzZs3xRtCqv/mzRv5/PmzLC4u6j5EIgCzv78vQ0NDao9jQKzEAbBGfn5A14ygzNmp"
        "ra3Vd6pFUFNTUxog5wUEOUe0H+0AkiMjI/Lu3TtZWVnRSjDdsEnAAACRfENDg1YIXfQggkL/+fPngQECoAADdXR0KEADAwOaCF1i"
        "1ULWSJPBmFXm9evXaoTDb61D31IZJt2LFy80aRBxUYEAxRxw/hgq1ooEef/+fQ2Cb5arb9WGj77ZD/bBt+kiZ8ko3xggRckJZn5+"
        "Xl6+fKkJvXr1Ss8KZabcTBhTNkf2rgY9R5yhGzduaHVp1cTERAWFu8vVc4lk3CSM7J0ntiGL2ZaR7sIAtadPn8qTJ0905IIglyAt"
        "Rc/TVsjBP88hIBAQxMHNycnR+4lR3tfXJz09PfL27VttWzeAiyhYBh/4ho8NS95dIRYUfQ2DA9rc3CxtbW3S0tKik8YQtksRAiV0"
        "OPygziHmTqAlrZ8ZqUyrBw8e6C3OaLUgLiL23Crxznmh5YkDH9xd2KctkTMdPwoExt3AWWlsbNTKMKU4QwTMvEeYO2R7e1udosPh"
        "pyVJlIC5R0CNvx0cfPaxxTRkiFAx+CZHMDZgLDA3WWKDT2xcFfX19frNpLNpeOXKlUBCvvLycu95Nj0IGvS4hRnREMYxQMsxfZgm"
        "3AnwQYuzQTU4c9wR/G9jinFZerbVDva57DhLVIuJhw0GCf74F8H5ZLS7BJAAAFi0LdeFTUl8AQLJQIFk+AAhCGcEyfQyQQ4/wdg/"
        "AkoMYYCkuGQBAKRImgry1wQbLOTRp/1IjoqzQJcxTZAEh3075C7Bww7VQQcf2CNmO0eQz2unU8ppDBRxzrLzRMAoWsLBhEEWFWQh"
        "hx14Fhx87FmvW8WRoWK0nt1HwWR6rg/0tRp/Ytd3r6c1GSNL6iK6bD9g1LNnNo0HuX4uosvsQ64tlms/cM9ctkDB1nn7LNs3CtaB"
        "gnXc5cr+1zL6+1vkH0XzaMQEAF13AAAAAElFTkSuQmCC"
    ),
}


# ============================================================================
#  SETTINGS
# ============================================================================
def screen_size():
    try:
        return int(user32.GetSystemMetrics(0)), int(user32.GetSystemMetrics(1))
    except Exception:
        return 1920, 1080


def make_area(left, top, right, bottom):
    """Stored as the user sees it: bottom-left X/Y and top-right X/Y."""
    return {"blx": left, "bly": bottom, "trx": right, "try": top}


def default_settings():
    sw, sh = screen_size()
    half = make_area(0, 0, sw // 2 - 1, sh - 1)

    def clamp(l, t, r, b):
        return make_area(max(0, l), max(0, t), min(sw - 1, r), min(sh - 1, b))

    areas = {k: dict(half) for k in IMAGES}
    areas["retry"] = clamp(836, 801, 1035, 927)
    areas["zenin"] = clamp(689, 82, 1038, 195)
    return {
        "areas": areas, "rotation": ["x", "c"], "slots": ["1"], "hr": "", "ct": [], "weapons": [],
        "loops_inf": True, "loops_count": 10, "stop_key": "f6", "log_clear": 10, "scan_full": False, "lock_on": "", "scale_pct": 0, "slot_when": "Both",
        "slot_method": "Press key", "slot_pos": {"1": [0, 0], "2": [0, 0]},
        "rejoin": True, "rejoin_text": REJOIN_TEXT,
        "screen": "Full Screen", "corner": "Top Left", "resolution": f"{sw}x{sh}",
    }


def load_settings():
    cfg = default_settings()
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        for key, value in data.items():
            if key == "areas" and isinstance(value, dict):
                for name, area in value.items():
                    if name in cfg["areas"] and isinstance(area, dict):
                        cfg["areas"][name].update({k: int(v) for k, v in area.items() if k in cfg["areas"][name]})
            elif key in cfg:
                cfg[key] = value
    except Exception:
        pass
    slots = cfg.get("slots")
    cfg["slots"] = [k for k in SLOT_KEYS if isinstance(slots, list) and k in slots] or ["1"]
    cfg["rejoin"] = bool(cfg.get("rejoin", True))
    if not isinstance(cfg.get("rejoin_text"), str) or not cfg["rejoin_text"].strip():
        cfg["rejoin_text"] = REJOIN_TEXT
    if cfg.get("slot_method") not in SLOT_METHODS:
        cfg["slot_method"] = "Press key"
    pos, clean = cfg.get("slot_pos"), {}
    for k in SLOT_KEYS:
        try:
            clean[k] = [int(pos[k][0]), int(pos[k][1])]
        except Exception:
            clean[k] = [0, 0]
    cfg["slot_pos"] = clean
    return cfg


def save_settings(cfg):
    try:
        SETTINGS_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception as exc:
        print(f"[WARN] could not save settings: {exc}")


def region_of(area):
    """(left, top, right, bottom) from the bottom-left / top-right pair, in any order."""
    left, right = sorted((area["blx"], area["trx"]))
    top, bottom = sorted((area["try"], area["bly"]))
    return left, top, right, bottom


def calibrate_scale(gray):
    """Find what size (fraction of the stored images) the game UI is drawn at. Returns (scale, key, score) or None."""
    half = cv2.resize(gray, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
    best = None

    def score_at(img, s):
        t = cv2.resize(img, None, fx=s * 0.5, fy=s * 0.5, interpolation=cv2.INTER_AREA)
        if min(t.shape) < 8 or t.shape[0] >= half.shape[0] or t.shape[1] >= half.shape[1]:
            return 0.0
        return float(np.nan_to_num(cv2.matchTemplate(half, t, cv2.TM_CCOEFF_NORMED)).max())

    for key, (name, _label, _thr) in IMAGES.items():
        if key in REJOIN_KEYS:  # menu images are not on screen during a raid and would only add noise
            continue
        img = cv2.imread(str(ROOT / name), cv2.IMREAD_GRAYSCALE)
        if img is None:
            continue
        coarse = sorted(((score_at(img, float(s)), float(s)) for s in np.arange(0.50, 1.81, 0.05)), reverse=True)
        for _sc, s0 in coarse[:2]:
            for s in np.arange(s0 - 0.05, s0 + 0.0501, 0.01):
                if s < 0.5:
                    continue
                sc = score_at(img, float(s))
                if best is None or sc > best[2]:
                    best = (round(float(s), 2), key, sc)
    return best if best and best[2] >= 0.75 else None  # a weak match is noise, not a real button


def ensure_images():
    for name, b64 in EMBEDDED.items():
        path = ROOT / name
        if not path.exists():
            path.write_bytes(base64.b64decode(b64))


# ============================================================================
#  SETTINGS WINDOW
# ============================================================================
BG, CARD, CARD2, EDGE = "#0b0c14", "#14162a", "#1d2040", "#2a2e57"
FG, MUTED, DIM = "#eceef9", "#8186ad", "#4a4f78"
ACCENT, RED, GREEN = "#8b5cf6", "#ff3b5c", "#3ddc97"
FONT = "Segoe UI"


class ChipGroup:
    """Row of tick chips. mode: 'single' (pick one), 'optional' (pick one or none), 'multi' (cap)."""

    def __init__(self, parent, options, selected, mode="single", cap=None, columns=6, fmt=str, on_change=None):
        self.options, self.mode, self.cap, self.fmt = list(options), mode, cap, fmt
        self.on_change, self.enabled = on_change, True
        self.sel = [o for o in self.options if o in (selected or [])]
        if mode == "single" and not self.sel:
            self.sel = [self.options[0]]
        self.frame = tk.Frame(parent, bg=CARD)
        self.labels = {}
        for i, option in enumerate(self.options):
            lb = tk.Label(self.frame, padx=10, pady=5, font=(FONT, 9, "bold"), bd=0)
            lb.grid(row=i // columns, column=i % columns, padx=3, pady=3, sticky="w")
            lb.bind("<Button-1>", lambda _e, o=option: self.click(o))
            self.labels[option] = lb
        self.refresh()

    def click(self, option):
        if not self.enabled:
            return
        if self.mode == "multi":
            if option in self.sel:
                self.sel.remove(option)
            elif self.cap is None or len(self.sel) < self.cap:
                self.sel.append(option)
            else:
                return
        elif option in self.sel and self.mode == "optional":
            self.sel = []
        else:
            self.sel = [option]
        self.refresh()
        if self.on_change:
            self.on_change()

    def set_enabled(self, enabled):
        self.enabled = enabled
        self.refresh()

    def clear(self):
        self.sel = []
        self.refresh()

    def refresh(self):
        full = self.mode == "multi" and self.cap is not None and len(self.sel) >= self.cap
        for option, lb in self.labels.items():
            on = option in self.sel
            blocked = (not self.enabled) or (full and not on)
            lb.config(text=("\u2714 " if on else "\u2716 ") + self.fmt(option),
                      bg=ACCENT if on else CARD2,
                      fg="#ffffff" if on else (DIM if blocked else FG),
                      cursor="arrow" if blocked else "hand2")
            if on and not self.enabled:
                lb.config(bg="#4a3a80")


def run_settings(cfg):
    root = tk.Tk()
    root.title(f"{APP_NAME} - Settings")
    root.configure(bg=BG)
    w, h = 1000, 880
    root.geometry(f"{w}x{h}+{max(0, (root.winfo_screenwidth() - w) // 2)}+{max(0, (root.winfo_screenheight() - h) // 2 - 20)}")
    root.minsize(860, 600)
    result = {"cfg": None}

    # ---- fixed footer ---------------------------------------------------------
    footer = tk.Frame(root, bg=CARD, highlightbackground=EDGE, highlightthickness=1)
    footer.pack(side="bottom", fill="x")
    status = tk.Label(footer, text="Set everything up, then press Save & Launch.", bg=CARD, fg=MUTED,
                      font=(FONT, 10), anchor="w")
    status.pack(side="left", padx=18, pady=12)

    def say(text, color=MUTED):
        status.config(text=text, fg=color)

    # ---- header ---------------------------------------------------------------
    head = tk.Frame(root, bg=BG)
    head.pack(fill="x", padx=26, pady=(18, 4))
    tk.Label(head, text="CALAMITY ", bg=BG, fg=FG, font=("Segoe UI Black", 26)).pack(side="left")
    tk.Label(head, text="CLEAVER", bg=BG, fg=RED, font=("Segoe UI Black", 26)).pack(side="left")
    tk.Label(head, text="Jujutsu Zero  \u00b7  Nayoa Calamity auto-raider", bg=BG, fg=MUTED,
             font=(FONT, 11)).pack(side="left", padx=16, pady=(14, 0))

    # ---- scrollable body ------------------------------------------------------
    body = tk.Frame(root, bg=BG)
    body.pack(fill="both", expand=True, padx=(26, 8), pady=(6, 0))
    canvas = tk.Canvas(body, bg=BG, highlightthickness=0)
    sb = tk.Scrollbar(body, orient="vertical", command=canvas.yview)
    inner = tk.Frame(canvas, bg=BG)
    win = canvas.create_window((0, 0), window=inner, anchor="nw")
    inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>", lambda e: canvas.itemconfig(win, width=e.width))
    canvas.configure(yscrollcommand=sb.set)
    canvas.pack(side="left", fill="both", expand=True)
    sb.pack(side="right", fill="y")
    root.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120), "units"))

    def card(title, sub=""):
        f = tk.Frame(inner, bg=CARD, highlightbackground=EDGE, highlightthickness=1)
        f.pack(fill="x", pady=6, padx=(0, 14))
        tk.Label(f, text=title, bg=CARD, fg=ACCENT, font=(FONT, 11, "bold")).pack(anchor="w", padx=16, pady=(12, 0))
        if sub:
            tk.Label(f, text=sub, bg=CARD, fg=MUTED, font=(FONT, 9)).pack(anchor="w", padx=16)
        b = tk.Frame(f, bg=CARD)
        b.pack(fill="x", padx=14, pady=(6, 12))
        return b

    def entry(parent, var, width=7):
        return tk.Entry(parent, textvariable=var, width=width, bg=CARD2, fg=FG, insertbackground=FG, relief="flat",
                        font=("Consolas", 10), highlightthickness=1, highlightbackground=EDGE,
                        highlightcolor=ACCENT, justify="center")

    def small_button(parent, text, command, bg=CARD2):
        return tk.Button(parent, text=text, command=command, bg=bg, fg=FG, activebackground=ACCENT,
                         activeforeground="#fff", relief="flat", bd=0, padx=10, pady=3, font=(FONT, 9),
                         cursor="hand2")

    # ---- SCAN MODE ------------------------------------------------------------
    SCAN_AREAS, SCAN_FULL = "Use search areas", "Fullscreen scan"
    sm = card("SCAN MODE", "Fullscreen scan searches your whole screen for every image, so you don't need to set any "
                           "X/Y areas. Search areas are faster because they only look in small boxes.")
    scan_mode = ChipGroup(sm, [SCAN_AREAS, SCAN_FULL], [SCAN_FULL if cfg.get("scan_full") else SCAN_AREAS], "single",
                          columns=2)
    scan_mode.frame.pack(anchor="w")
    area_widgets = []

    # ---- IMAGE AREAS ----------------------------------------------------------
    ar = card("SEARCH AREAS", "Each image is only searched inside its rectangle (screen pixels). Smaller boxes scan faster. "
                              "Put Roblox on screen, press GRAB AREA, then hover each corner when asked (3 seconds each).")
    area_vars = {}

    def grab(xv, yv, what):
        def tick(n):
            if n > 0:
                say(f"Move the mouse to the {what} corner... {n}", ACCENT)
                root.after(1000, lambda: tick(n - 1))
            else:
                pt = wintypes.POINT()
                user32.GetCursorPos(ctypes.byref(pt))
                xv.set(str(pt.x))
                yv.set(str(pt.y))
                say(f"Grabbed {pt.x}, {pt.y}", GREEN)
        tick(3)

    def grab_area(vs, name):
        """Minimises this window, then reads the bottom-left and top-right corners from the mouse."""
        toast = tk.Toplevel(root)
        toast.overrideredirect(True)
        toast.attributes("-topmost", True)
        toast.configure(bg=ACCENT)
        msg = tk.Label(toast, bg=ACCENT, fg="#ffffff", font=(FONT, 16, "bold"), padx=26, pady=12)
        msg.pack()
        toast.geometry(f"+{max(0, root.winfo_screenwidth() // 2 - 330)}+30")
        root.iconify()

        def point(xv, yv, what, then):
            def tick(n):
                if n > 0:
                    msg.config(text=f"{name}: hover the {what} corner ... {n}")
                    root.after(1000, lambda: tick(n - 1))
                else:
                    pt = wintypes.POINT()
                    user32.GetCursorPos(ctypes.byref(pt))
                    xv.set(str(pt.x))
                    yv.set(str(pt.y))
                    msg.config(text=f"{what} corner saved:  {pt.x}, {pt.y}")
                    root.after(900, then)
            tick(3)

        def finish():
            toast.destroy()
            root.deiconify()
            say(f"{name}: area saved", GREEN)

        point(vs["blx"], vs["bly"], "BOTTOM-LEFT",
              lambda: point(vs["trx"], vs["try"], "TOP-RIGHT", finish))

    def add_area_rows(parent, keys):
        for col, text in enumerate(["Image", "Bottom-left X", "Bottom-left Y", "Top-right X", "Top-right Y"]):
            tk.Label(parent, text=text, bg=CARD, fg=MUTED, font=(FONT, 9)).grid(row=0, column=col, sticky="w", padx=4)
        for row, key in enumerate(keys, start=1):
            a = cfg["areas"][key]
            vs = {n: tk.StringVar(value=str(a[n])) for n in ("blx", "bly", "trx", "try")}
            area_vars[key] = vs
            tk.Label(parent, text=IMAGES[key][1], bg=CARD, fg=FG, font=(FONT, 10)).grid(row=row, column=0, sticky="w", padx=4, pady=4)
            for col_i, n in enumerate(("blx", "bly", "trx", "try"), start=1):
                w_ = entry(parent, vs[n])
                w_.grid(row=row, column=col_i, padx=4)
                area_widgets.append(w_)
            for w_, col_i, pad in (
                    (small_button(parent, "GRAB AREA", lambda v=vs, n=IMAGES[key][1]: grab_area(v, n), bg=ACCENT), 5, (12, 4)),
                    (small_button(parent, "BL", lambda v=vs: grab(v["blx"], v["bly"], "bottom-left")), 6, 2),
                    (small_button(parent, "TR", lambda v=vs: grab(v["trx"], v["try"], "top-right")), 7, 2)):
                w_.grid(row=row, column=col_i, padx=pad)
                area_widgets.append(w_)

    add_area_rows(ar, [k for k in IMAGES if k not in REJOIN_KEYS])

    # ---- AUTO REJOIN ----------------------------------------------------------
    rj = card("AUTO REJOIN", "If the game kicks you, the Disconnected box (Leave / Reconnect) is spotted, ALL other image searching "
                             "stops, and the macro walks back into a raid: Leave > Search > type the game name > Play > Gamemodes > "
                             "Raids > Create > Projection > Calamity > Modifiers > Weaken > Friends Only > Create > Start. "
                             "Then the normal macro carries on until the next kick.")
    rejoin_on = ChipGroup(rj, ["On", "Off"], ["On" if cfg.get("rejoin", True) else "Off"], "single", columns=2)
    rejoin_on.frame.pack(anchor="w")
    txt_row = tk.Frame(rj, bg=CARD)
    txt_row.pack(anchor="w", pady=(8, 2))
    tk.Label(txt_row, text="Type in the Search box:", bg=CARD, fg=MUTED, font=(FONT, 9)).pack(side="left")
    rejoin_text = tk.StringVar(value=cfg.get("rejoin_text", REJOIN_TEXT))
    entry(txt_row, rejoin_text, width=26).pack(side="left", padx=8)
    tk.Label(rj, text="Search area of every rejoin image (same as above - Fullscreen scan overrides these):",
             bg=CARD, fg=MUTED, font=(FONT, 9)).pack(anchor="w", pady=(6, 0))
    rj_grid = tk.Frame(rj, bg=CARD)
    rj_grid.pack(anchor="w", fill="x")
    add_area_rows(rj_grid, REJOIN_KEYS)

    def scan_mode_changed():
        full = scan_mode.sel[0] == SCAN_FULL
        for w_ in area_widgets:
            w_.config(state="disabled" if full else "normal")
        say("Fullscreen scan: the whole screen is searched, no areas needed." if full
            else "Search areas: each image is only searched inside its box.", ACCENT)
    scan_mode.on_change = scan_mode_changed
    for w_ in area_widgets:
        w_.config(state="disabled" if scan_mode.sel[0] == SCAN_FULL else "normal")

    # ---- ATTACK ROTATION ------------------------------------------------------
    rt = card("ATTACK ROTATION", "Keys pressed over and over from the moment the raid starts until it ends.")
    rotation = ChipGroup(rt, ROTATION_KEYS, cfg["rotation"], "multi", columns=8, fmt=str.upper)
    rotation.frame.pack(anchor="w")

    # ---- SLOTS ----------------------------------------------------------------
    sl = card("SLOTS", "Pick slot 1, 2 or both. With both, the macro runs one full attack rotation on a slot, "
                       "swaps to the other slot, runs it again, and keeps alternating.")
    slots = ChipGroup(sl, SLOT_KEYS, cfg["slots"], "multi", columns=2, fmt=lambda k: f"Slot {k}")
    slots.frame.pack(anchor="w")
    tk.Label(sl, text="Equip the slot:", bg=CARD, fg=MUTED, font=(FONT, 9)).pack(anchor="w", pady=(8, 0))
    slot_when = ChipGroup(sl, SLOT_WHEN, [cfg.get("slot_when", "Both")], "single", columns=3)
    slot_when.frame.pack(anchor="w")
    tk.Label(sl, text="How to equip a slot:", bg=CARD, fg=MUTED, font=(FONT, 9)).pack(anchor="w", pady=(8, 0))
    slot_method = ChipGroup(sl, SLOT_METHODS, [cfg.get("slot_method", "Press key")], "single", columns=2)
    slot_method.frame.pack(anchor="w")
    tk.Label(sl, text="Click position: instead of pressing 1 / 2, the mouse glides to the X/Y you set for that slot "
                      "and clicks it once. Press GRAB POINT, then hover the slot for 3 seconds.",
             bg=CARD, fg=MUTED, font=(FONT, 9), justify="left", wraplength=880).pack(anchor="w", pady=(4, 0))
    pos_frame = tk.Frame(sl, bg=CARD)
    pos_frame.pack(anchor="w", pady=(4, 0))
    slot_pos_vars, pos_widgets = {}, []

    def grab_point(xv, yv, name):
        """Minimises this window, then reads one point from the mouse after 3 seconds."""
        toast = tk.Toplevel(root)
        toast.overrideredirect(True)
        toast.attributes("-topmost", True)
        toast.configure(bg=ACCENT)
        msg = tk.Label(toast, bg=ACCENT, fg="#ffffff", font=(FONT, 16, "bold"), padx=26, pady=12)
        msg.pack()
        toast.geometry(f"+{max(0, root.winfo_screenwidth() // 2 - 330)}+30")
        root.iconify()

        def tick(n):
            if n > 0:
                msg.config(text=f"{name}: hover the slot ... {n}")
                root.after(1000, lambda: tick(n - 1))
            else:
                pt = wintypes.POINT()
                user32.GetCursorPos(ctypes.byref(pt))
                xv.set(str(pt.x))
                yv.set(str(pt.y))
                msg.config(text=f"{name} saved:  {pt.x}, {pt.y}")
                root.after(900, finish)

        def finish():
            toast.destroy()
            root.deiconify()
            say(f"{name}: point saved", GREEN)
        tick(3)

    for r_i, k in enumerate(SLOT_KEYS):
        px, py = cfg.get("slot_pos", {}).get(k, [0, 0])
        xv, yv = tk.StringVar(value=str(px)), tk.StringVar(value=str(py))
        slot_pos_vars[k] = (xv, yv)
        tk.Label(pos_frame, text=f"Slot {k}   X", bg=CARD, fg=FG, font=(FONT, 10)).grid(row=r_i, column=0, sticky="w", padx=(4, 4), pady=3)
        ex = entry(pos_frame, xv)
        ex.grid(row=r_i, column=1, padx=4)
        tk.Label(pos_frame, text="Y", bg=CARD, fg=FG, font=(FONT, 10)).grid(row=r_i, column=2, padx=(8, 4))
        ey = entry(pos_frame, yv)
        ey.grid(row=r_i, column=3, padx=4)
        gb = small_button(pos_frame, "GRAB POINT", lambda a=xv, b=yv, n=f"Slot {k}": grab_point(a, b, n), bg=ACCENT)
        gb.grid(row=r_i, column=4, padx=(12, 4))
        pos_widgets += [ex, ey, gb]

    def slot_method_changed():
        click_mode = slot_method.sel[0] == "Click position"
        for w_ in pos_widgets:
            w_.config(state="normal" if click_mode else "disabled")
    slot_method.on_change = slot_method_changed
    slot_method_changed()

    # ---- LOCK ON --------------------------------------------------------------
    LOCK_KEYS = set("abcdefghijklmnopqrstuvwxyz0123456789")
    lo = card("LOCK ON", "The key you press in the game to lock on. Press SET KEY, then press that key (A-Z, 0-9) "
                         "or click the middle mouse button. It is pressed once each time Ready is detected, right after the slot key.")
    lock = {"key": cfg.get("lock_on", "") if cfg.get("lock_on", "") in LOCK_KEYS | {"mmb"} else "", "listening": False}
    lo_row = tk.Frame(lo, bg=CARD)
    lo_row.pack(anchor="w")
    keycap = tk.Label(lo_row, width=9, pady=8, font=("Consolas", 16, "bold"), bd=0)
    keycap.pack(side="left", padx=(0, 12))

    def lock_refresh():
        if lock["listening"]:
            keycap.config(text="PRESS...", bg=RED, fg="#ffffff")
        elif lock["key"]:
            keycap.config(text="MMB" if lock["key"] == "mmb" else lock["key"].upper(), bg=ACCENT, fg="#ffffff")
        else:
            keycap.config(text="NONE", bg=CARD2, fg=DIM)

    def lock_stop():
        lock["listening"] = False
        root.unbind_all("<Key>")
        root.unbind_all("<ButtonPress-2>")
        lock_refresh()

    def lock_set(key):
        lock["key"] = key
        lock_stop()
        say(f"Lock On set to {'middle mouse button' if key == 'mmb' else key.upper()}", GREEN)

    def lock_key(e):
        ks = e.keysym
        if ks == "Escape":
            lock_stop()
            say("Lock On unchanged", MUTED)
        elif len(ks) == 1 and ks.lower() in LOCK_KEYS:
            lock_set(ks.lower())
        elif ks not in ("Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R", "Caps_Lock"):
            say("Only letters A-Z, numbers 0-9 or the middle mouse button work. Esc cancels.", RED)
        return "break"

    def lock_listen():
        lock["listening"] = True
        lock_refresh()
        say("Press the Lock On key now (or middle click). Esc cancels.", ACCENT)
        root.focus_force()
        root.bind_all("<Key>", lock_key)
        root.bind_all("<ButtonPress-2>", lambda _e: (lock_set("mmb"), "break")[1])

    def lock_clear():
        lock["key"] = ""
        lock_stop()
        say("Lock On cleared - the macro won't press a lock-on key", MUTED)

    lock_refresh()
    small_button(lo_row, "SET KEY", lock_listen, bg=ACCENT).pack(side="left", padx=4, ipady=4)
    small_button(lo_row, "CLEAR", lock_clear).pack(side="left", padx=4, ipady=4)

    # ---- HEAVENLY RESTRICTION / CURSED TECHNIQUE / WEAPONS ---------------------
    hr_card = card("HEAVENLY RESTRICTION", "Pick one, or none to use both a cursed technique and weapons. "
                                           "Physical locks cursed techniques, Sorcerer locks weapons.")
    hr = ChipGroup(hr_card, [SHR, PHR], [cfg["hr"]] if cfg["hr"] else [], "optional", columns=2)
    hr.frame.pack(anchor="w")
    ct_card = card("CURSED TECHNIQUE", f"Up to {SELECT_CAP} can be selected.")
    ct = ChipGroup(ct_card, CURSED_TECHNIQUES, cfg["ct"], "multi", cap=SELECT_CAP, columns=4)
    ct.frame.pack(anchor="w")
    wp_card = card("WEAPON", f"Up to {SELECT_CAP} can be selected.")
    wp = ChipGroup(wp_card, WEAPONS, cfg["weapons"], "multi", cap=SELECT_CAP, columns=4)
    wp.frame.pack(anchor="w")

    def hr_changed():
        choice = hr.sel[0] if hr.sel else ""
        if choice == PHR:
            ct.clear()
        if choice == SHR:
            wp.clear()
        ct.set_enabled(choice != PHR)
        wp.set_enabled(choice != SHR)
    hr.on_change = hr_changed
    hr_changed()

    # ---- LOOPS ----------------------------------------------------------------
    lp = card("LOOPS", "Loops goes up by 1 every time Raid Summary: Successful is seen (a failure does not count).")
    loops_mode = ChipGroup(lp, ["Amount", "Inf"], ["Inf" if cfg["loops_inf"] else "Amount"], "single", columns=2)
    loops_mode.frame.grid(row=0, column=0, sticky="w")
    loops_var = tk.StringVar(value=str(cfg["loops_count"]))
    tk.Label(lp, text="how many:", bg=CARD, fg=MUTED, font=(FONT, 9)).grid(row=0, column=1, padx=(20, 6))
    entry(lp, loops_var, 7).grid(row=0, column=2)

    # ---- STOP / LOG CLEARER ---------------------------------------------------
    sk = card("STOP KEY", "Press it to stop the macro, press it again to restart it.")
    stop = ChipGroup(sk, STOP_KEYS, [cfg["stop_key"]], "single", columns=12, fmt=str.upper)
    stop.frame.pack(anchor="w")
    lc = card("LOG CLEARER", "The console is wiped and redrawn this often.")
    logc = ChipGroup(lc, LOG_CLEAR_MINUTES, [cfg["log_clear"]], "single", columns=6, fmt=lambda m: f"{m} min")
    logc.frame.pack(anchor="w")

    # ---- SCREEN / RESOLUTION --------------------------------------------------
    sc = card("SCREEN", "Window layout of Roblox. Smaller layouts also try smaller copies of the images.")
    screen = ChipGroup(sc, SCREEN_MODES, [cfg["screen"]], "single", columns=3)
    screen.frame.pack(anchor="w")
    corner = ChipGroup(sc, CORNERS, [cfg["corner"]], "single", columns=4)
    corner.frame.pack(anchor="w", pady=(6, 0))

    def screen_changed():
        corner.set_enabled(True)  # corner/side can be picked with any screen mode
    screen.on_change = screen_changed
    screen_changed()
    rs = card("RESOLUTION")
    res = ChipGroup(rs, RESOLUTIONS, [cfg["resolution"]] if cfg["resolution"] in RESOLUTIONS else [RESOLUTIONS[0]],
                    "single", columns=6)
    res.frame.pack(anchor="w")

    # ---- IMAGE SIZE -----------------------------------------------------------
    sz = card("IMAGE SIZE", "How big the game UI is compared to the saved images. Leave blank/0 for Auto (slower, tries many sizes). "
                            "A fixed size is faster and more accurate: press AUTO-DETECT with a game button on screen.")
    scale_var = tk.StringVar(value=str(cfg.get("scale_pct") or ""))
    sz_row = tk.Frame(sz, bg=CARD)
    sz_row.pack(anchor="w")
    entry(sz_row, scale_var, 6).pack(side="left", ipady=3)
    tk.Label(sz_row, text="%", bg=CARD, fg=MUTED, font=(FONT, 10)).pack(side="left", padx=(4, 14))

    def do_calibrate():
        found, err = None, ""
        try:
            with (mss.MSS() if hasattr(mss, "MSS") else mss.mss()) as sct:
                shot = np.asarray(sct.grab(sct.monitors[1]))
            root.deiconify()
            say("Measuring... one moment", ACCENT)
            root.update()
            found = calibrate_scale(cv2.cvtColor(shot, cv2.COLOR_BGRA2GRAY))
        except Exception as exc:
            err = str(exc)
            root.deiconify()
        if found:
            scale_var.set(str(int(round(found[0] * 100))))
            say(f"Image size set to {int(round(found[0] * 100))}% (matched {IMAGES[found[1]][1]}, score {found[2]:.2f})", GREEN)
        else:
            say("Couldn't find a game button. Show Ready / Retry / Raid Summary on your main monitor and try again. " + err, RED)

    def calibrate():
        say("Put Roblox on screen with a game button visible (Ready / Retry / Raid Summary). Starting in 3 seconds...", ACCENT)
        root.iconify()
        root.after(3000, do_calibrate)

    small_button(sz_row, "AUTO-DETECT", calibrate, bg=ACCENT).pack(side="left", padx=4, ipady=4)
    small_button(sz_row, "AUTO (blank)", lambda: scale_var.set("")).pack(side="left", padx=4, ipady=4)

    # ---- save / quit ----------------------------------------------------------
    def collect():
        out = {"areas": {}}
        if scan_mode.sel[0] == SCAN_FULL:
            sw_, sh_ = screen_size()
            out["areas"] = {k: make_area(0, 0, sw_, sh_) for k in IMAGES}
        else:
          try:
            for key, vs in area_vars.items():
                out["areas"][key] = {n: int(v.get().strip()) for n, v in vs.items()}
                l, t, r, b = region_of(out["areas"][key])
                if min(l, t) < 0 or r - l < 1 or b - t < 1:
                    say(f"{IMAGES[key][1]}: the search area is empty or negative.", RED)
                    return None
          except ValueError:
            say("Search areas must be whole numbers.", RED)
            return None
        if not rotation.sel:
            say("Pick at least one Attack Rotation key.", RED)
            return None
        if not slots.sel:
            say("Pick at least one Slot.", RED)
            return None
        click_mode = slot_method.sel[0] == "Click position"
        slot_pos = {}
        if click_mode:
            try:
                for k in slots.sel:
                    slot_pos[k] = [int(slot_pos_vars[k][0].get().strip()), int(slot_pos_vars[k][1].get().strip())]
            except ValueError:
                say("Slot X/Y must be whole numbers.", RED)
                return None
            for k, (px_, py_) in slot_pos.items():
                if px_ < 0 or py_ < 0 or (px_ == 0 and py_ == 0):
                    say(f"Set the X/Y for Slot {k} (press GRAB POINT and hover the slot).", RED)
                    return None
        for k in SLOT_KEYS:  # keep the saved point of a slot that isn't ticked right now
            if k not in slot_pos:
                try:
                    slot_pos[k] = [max(0, int(slot_pos_vars[k][0].get().strip())), max(0, int(slot_pos_vars[k][1].get().strip()))]
                except ValueError:
                    slot_pos[k] = [0, 0]
        if lock["key"] and (lock["key"] in rotation.sel or (not click_mode and lock["key"] in slots.sel)):
            say(f"Lock On key {lock['key'].upper()} is already used by the rotation or slots - pick another.", RED)
            return None
        rj_text = rejoin_text.get().strip()
        if rejoin_on.sel[0] == "On" and not rj_text:
            say("Auto rejoin: type what should be searched for (e.g. Jujutsu: Zero).", RED)
            return None
        try:
            pct = int(scale_var.get().strip() or 0)
        except ValueError:
            pct = -1
        if pct != 0 and not 30 <= pct <= 200:
            say("Image size must be blank (Auto) or a whole number between 30 and 200.", RED)
            return None
        inf = loops_mode.sel[0] == "Inf"
        try:
            count = int(loops_var.get().strip())
        except ValueError:
            count = 0
        if not inf and count < 1:
            say("Loops: enter a whole number of 1 or more, or pick Inf.", RED)
            return None
        out.update({
            "rotation": [k for k in ROTATION_KEYS if k in rotation.sel], "slots": [k for k in SLOT_KEYS if k in slots.sel], "hr": hr.sel[0] if hr.sel else "",
            "ct": list(ct.sel), "weapons": list(wp.sel), "loops_inf": inf, "loops_count": max(count, 1),
            "stop_key": stop.sel[0], "log_clear": logc.sel[0], "screen": screen.sel[0],
            "corner": corner.sel[0], "resolution": res.sel[0], "scan_full": scan_mode.sel[0] == SCAN_FULL, "lock_on": lock["key"], "scale_pct": pct, "slot_when": slot_when.sel[0],
            "slot_method": slot_method.sel[0], "slot_pos": slot_pos,
            "rejoin": rejoin_on.sel[0] == "On", "rejoin_text": rj_text or REJOIN_TEXT,
        })
        return out

    def on_save():
        data = collect()
        if data is None:
            return
        save_settings(data)
        result["cfg"] = data
        root.destroy()

    tk.Button(footer, text="SAVE & LAUNCH", command=on_save, bg=RED, fg="#fff", activebackground="#ff6b85",
              activeforeground="#fff", relief="flat", bd=0, padx=22, pady=8, font=(FONT, 10, "bold"),
              cursor="hand2").pack(side="right", padx=(8, 16), pady=8)
    small_button(footer, "Quit", root.destroy).pack(side="right", pady=8, ipady=4)
    root.mainloop()
    return result["cfg"]


# ============================================================================
#  CONSOLE
# ============================================================================
R, B, D = "\x1b[0m", "\x1b[1m", "\x1b[2m"
C = {"INFO": "\x1b[38;5;75m", "RAID": "\x1b[38;5;141m", "PHASE": "\x1b[38;5;220m", "WIN": "\x1b[38;5;84m",
     "LOSE": "\x1b[38;5;203m", "CLICK": "\x1b[38;5;213m", "STOP": "\x1b[38;5;208m", "RUN": "\x1b[38;5;84m",
     "WARN": "\x1b[38;5;214m", "LOCK": "\x1b[38;5;51m", "JOIN": "\x1b[38;5;45m", "MOVE": "\x1b[38;5;111m", "KEY": "\x1b[38;5;183m", "DBG": "\x1b[38;5;245m", "ERR": "\x1b[38;5;196m"}
print_lock = threading.Lock()


def enable_console():
    try:
        k = ctypes.windll.kernel32
        out = k.GetStdHandle(-11)
        mode = ctypes.c_ulong()
        k.GetConsoleMode(out, ctypes.byref(mode))
        k.SetConsoleMode(out, mode.value | 0x0004)          # ANSI colours
        inp = k.GetStdHandle(-10)
        k.GetConsoleMode(inp, ctypes.byref(mode))
        k.SetConsoleMode(inp, (mode.value & ~0x0040) | 0x0080)  # clicking the window no longer freezes it
    except Exception:
        pass


LOG_DIR = ROOT / "logs"
LOG_KEEP = 10             # how many session log files to keep
log_fh = None


def init_log(cfg):
    """Open logs/session_<date>_<time>.log. Everything the console shows (plus the DBG scores) goes in there."""
    global log_fh
    try:
        LOG_DIR.mkdir(exist_ok=True)
        old = sorted(LOG_DIR.glob("session_*.log"))
        for f in old[:max(0, len(old) - (LOG_KEEP - 1))]:
            try:
                f.unlink()
            except Exception:
                pass
        path = LOG_DIR / time.strftime("session_%Y-%m-%d_%H-%M-%S.log")
        log_fh = open(path, "w", encoding="utf-8", buffering=1)
        sw, sh = screen_size()
        log_fh.write(f"{APP_NAME} session log - {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        log_fh.write(f"python {sys.version.split()[0]} | opencv {cv2.__version__} | numpy {np.__version__} | "
                     f"screen {sw}x{sh}\n")
        log_fh.write("settings: " + json.dumps(cfg) + "\n")
        log_fh.write("-" * 70 + "\n")
        return path
    except Exception as exc:
        log_fh = None
        print(f"[WARN] could not create log file: {exc}")
        return None


def log(tag, msg):
    stamp = time.strftime("%H:%M:%S")
    with print_lock:
        if log_fh is not None:
            try:
                log_fh.write(f"{stamp}  {tag:<5}  {msg}\n")
            except Exception:
                pass
        if tag == "DBG":  # match scores only go to the log file, not the console
            return
        print(f"  {D}{stamp}{R}  {C.get(tag, '')}{B}{tag:<5}{R}  {msg}", flush=True)


def print_header(cfg):
    v, rd = "\x1b[38;5;141m", "\x1b[38;5;203m"
    restriction = cfg["hr"] or "None (cursed technique + weapons)"
    loops = "Infinite" if cfg["loops_inf"] else f"{cfg['loops_count']} raids"
    rows = [("Rotation", " ".join(k.upper() for k in cfg["rotation"])), ("Slots", " + ".join(cfg["slots"])),
            ("Restriction", restriction),
            ("Slot press", cfg.get("slot_when", "Both")),
            ("Slot method", cfg.get("slot_method", "Press key") + (
                " " + " ".join(f"S{k}=({cfg['slot_pos'][k][0]},{cfg['slot_pos'][k][1]})" for k in cfg["slots"])
                if cfg.get("slot_method") == "Click position" else "")),
            ("Lock On", ("MMB" if cfg.get("lock_on") == "mmb" else cfg.get("lock_on", "").upper()) or "-"),
            ("Technique", ", ".join(cfg["ct"]) or "-"), ("Weapons", ", ".join(cfg["weapons"]) or "-"),
            ("Loops", loops), ("Stop key", cfg["stop_key"].upper()),
            ("Log clear", f"every {cfg['log_clear']} min"), ("Screen", cfg["screen"]),
            ("Resolution", cfg["resolution"]),
            ("Image size", f'{cfg["scale_pct"]}%' if cfg.get("scale_pct") else "Auto"),
            ("Auto rejoin", ("On  (types \"" + cfg.get("rejoin_text", REJOIN_TEXT) + "\")") if cfg.get("rejoin", True) else "Off")]
    top, bot, hl = "\u2554" + "\u2550" * 58 + "\u2557", "\u255a" + "\u2550" * 58 + "\u255d", "\u2500" * 60
    side = "\u2551"
    with print_lock:
        os.system("cls" if os.name == "nt" else "clear")
        print("\x1b[3J", end="")  # also wipe the scrollback, so only the redrawn header + settings remain
        print()
        print(f"  {v}{top}{R}")
        print(f"  {v}{side}{R}   {B}C A L A M I T Y{R}  {rd}{B}C L E A V E R{R}  {v}{B}\u25c6{R}{' ' * 22}{v}{side}{R}")
        print(f"  {v}{side}{R}   {D}Jujutsu Zero  \u00b7  Nayoa Calamity auto-raider{R}{' ' * 12}{v}{side}{R}")
        print(f"  {v}{side}{R}   {v}\u25c6{R} {D}Made By{R} {B}Diamond/Lemon{R}{' ' * 32}{v}{side}{R}")
        print(f"  {v}{bot}{R}")
        for name, value in rows:
            print(f"   {D}{name:<12}{R}{value}")
        print(f"  {D}{hl}{R}", flush=True)


def fmt_time(seconds):
    s = int(seconds)
    return f"{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"


# ============================================================================
#  MACRO
# ============================================================================
IDLE, RAID, WAIT_RETRY = "idle", "raid", "wait_retry"
shutdown, paused, attacking, busy = threading.Event(), threading.Event(), threading.Event(), threading.Event()
rejoining = threading.Event()   # set while the rejoin protocol runs: the normal scanner stands still
lock = threading.Lock()
actions = queue.Queue()
pool = concurrent.futures.ThreadPoolExecutor(max_workers=len(SCAN_KEYS) + 1)
cfg_live = {}
regions, templates = {}, {}
S = {"state": IDLE, "loops": 0, "rejoins": 0, "rj_step": 0, "phase2": False, "retry_since": 0.0, "result_block": 0.0, "ready_block": 0.0}
start_time = time.monotonic()


def load_templates(cfg):
    pct = int(cfg.get("scale_pct", 0) or 0)
    if pct > 0:  # the buttons are not all drawn at exactly the same size, so try +-2% around the chosen size
        scales = [round(pct / 100.0 + d, 2) for d in (0.0, -0.01, 0.01, -0.02, 0.02)]
    else:
        scales = SCALES.get(cfg["screen"], [1.0])
    for key, (name, label, _thr) in IMAGES.items():
        img = cv2.imread(str(ROOT / name), cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise SystemExit(f"Missing or unreadable image: {name} (put it next to this file)")
        if key in CROPS:
            c0, c1 = CROPS[key]
            img = img[:, int(img.shape[1] * c0):int(img.shape[1] * c1)]
        rel = REL_SCALE.get(key, 1.0)
        key_scales = REJOIN_SCALES if key in REJOIN_KEYS else scales
        templates[key] = []
        for s in [round(x * rel, 3) for x in key_scales]:
            t = img if s == 1.0 else cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
            small = cv2.resize(t, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
            templates[key].append((t, small if min(small.shape) >= 8 else None, s))
        if cfg.get("scan_full"):
            sw_, sh_ = screen_size()
            regions[key] = (0, 0, sw_, sh_)
        else:
            regions[key] = region_of(cfg["areas"][key])
        l, t_, r, b = regions[key]
        if (r - l) < img.shape[1] * min(key_scales) * rel or (b - t_) < img.shape[0] * min(key_scales) * rel:
            log("WARN", f"{label}: search area is smaller than the image - it can never match")


def grab_gray(sct, key, cache=None):
    reg = regions[key]
    if cache is not None and reg in cache:  # fullscreen scan: grab the screen once per tick, not once per image
        return cache[reg]
    left, top, right, bottom = reg
    shot = np.asarray(sct.grab({"left": left, "top": top, "width": right - left, "height": bottom - top}))
    gray = cv2.cvtColor(shot, cv2.COLOR_BGRA2GRAY)
    if cache is not None:
        cache[reg] = gray
    return gray


def find(sct, key):
    return match(key, grab_gray(sct, key))


def match(key, gray):
    """Two-stage match: a quick half-size pass finds candidates, a full-size pass confirms them."""
    left, top = regions[key][0], regions[key][1]
    ox, oy = CLICK_OFFSET.get(key, (0.0, 0.0))
    gh, gw = gray.shape
    gray_small = None
    best, pos = 0.0, None
    best_sc = 0.0
    for t, small, sc in templates[key]:
        th, tw = t.shape
        if th > gh or tw > gw:
            continue
        if small is None or gh < small.shape[0] * 2 or gw < small.shape[1] * 2:
            res = np.nan_to_num(cv2.matchTemplate(gray, t, cv2.TM_CCOEFF_NORMED))
            _, mx, _, loc = cv2.minMaxLoc(res)
            cand = (mx, loc[0], loc[1])
        else:
            if gray_small is None:
                gray_small = cv2.resize(gray, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
            res = np.nan_to_num(cv2.matchTemplate(gray_small, small, cv2.TM_CCOEFF_NORMED))
            _, mx, _, loc = cv2.minMaxLoc(res)
            if mx < COARSE_GATE:
                if DEBUG_SCORES:
                    BEST[key] = max(BEST.get(key, (0.0, 0.0)), (float(mx), sc))
                continue
            x0, y0 = max(loc[0] * 2 - 6, 0), max(loc[1] * 2 - 6, 0)
            x1, y1 = min(loc[0] * 2 + tw + 6, gw), min(loc[1] * 2 + th + 6, gh)
            res = np.nan_to_num(cv2.matchTemplate(gray[y0:y1, x0:x1], t, cv2.TM_CCOEFF_NORMED))
            _, mx, _, loc2 = cv2.minMaxLoc(res)
            cand = (mx, x0 + loc2[0], y0 + loc2[1])
        if cand[0] > best:
            best, best_sc, pos = cand[0], sc, (left + cand[1] + tw // 2 + int(ox * tw), top + cand[2] + th // 2 + int(oy * th))
    if DEBUG_SCORES:
        BEST[key] = max(BEST.get(key, (0.0, 0.0)), (float(best), best_sc))
    return (pos[0], pos[1], best) if pos and best >= IMAGES[key][2] else None


# ---- input -----------------------------------------------------------------
# Mouse moves and clicks are sent with SendInput (real input events Roblox sees), not SetCursorPos.
ULONG_PTR = ctypes.c_size_t
MOVE, LEFTDOWN, LEFTUP, ABSOLUTE, VIRTUALDESK = 0x0001, 0x0002, 0x0004, 0x8000, 0x4000
MIDDLEDOWN, MIDDLEUP = 0x0020, 0x0040


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class _InputUnion(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _InputUnion)]


def send_mouse(flags, dx=0, dy=0):
    inp = INPUT(0, _InputUnion(mi=MOUSEINPUT(dx, dy, 0, flags, 0, 0)))
    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))


def cursor_pos():
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y


def move_abs(x, y, vs):
    vx, vy, vw, vh = vs
    nx = int(round((x - vx) * 65535 / max(vw - 1, 1)))
    ny = int(round((y - vy) * 65535 / max(vh - 1, 1)))
    send_mouse(MOVE | ABSOLUTE | VIRTUALDESK, nx, ny)


def wait_until(t):
    """Accurate wait: sleep most of it, spin the last couple of milliseconds."""
    while True:
        remaining = t - time.perf_counter()
        if remaining <= 0:
            return
        time.sleep(remaining - 0.002 if remaining > 0.004 else 0)


def glide_to(tx, ty):
    """Curved, eased move at about 200 steps per second. Returns False if it was interrupted."""
    vs = tuple(user32.GetSystemMetrics(i) for i in (76, 77, 78, 79))
    tx, ty = int(tx), int(ty)
    sx, sy = cursor_pos()
    dx, dy = tx - sx, ty - sy
    dist = math.hypot(dx, dy)
    if dist >= 2:
        dur = min(1.3, 0.30 + dist / 2000.0)
        nx, ny = -dy / dist, dx / dist
        bend = random.uniform(-0.08, 0.08) * min(dist, 600)
        c1 = (sx + dx * 0.30 + nx * bend, sy + dy * 0.30 + ny * bend)
        c2 = (sx + dx * 0.70 + nx * bend * 0.5, sy + dy * 0.70 + ny * bend * 0.5)
        steps = max(30, int(dur * 200))
        t0 = time.perf_counter()
        for i in range(1, steps + 1):
            if paused.is_set() or shutdown.is_set():
                return False
            t = i / steps
            e = t * t * t * (t * (6 * t - 15) + 10)  # smootherstep easing
            u = 1 - e
            x = u**3 * sx + 3 * u * u * e * c1[0] + 3 * u * e * e * c2[0] + e**3 * tx
            y = u**3 * sy + 3 * u * u * e * c1[1] + 3 * u * e * e * c2[1] + e**3 * ty
            move_abs(int(round(x)), int(round(y)), vs)
            wait_until(t0 + dur * t)
    time.sleep(0.08)
    move_abs(tx + 3, ty, vs)   # small wiggle so Roblox registers the cursor arriving / hovering
    time.sleep(0.05)
    move_abs(tx - 3, ty, vs)
    time.sleep(0.03)
    move_abs(tx, ty, vs)
    time.sleep(0.08)
    if cursor_pos() != (tx, ty):  # absolute coordinates can be 1 px off, snap to the exact pixel
        user32.SetCursorPos(tx, ty)
        time.sleep(0.03)
    return True


def click():
    send_mouse(LEFTDOWN)
    time.sleep(0.07 + random.uniform(0, 0.03))  # held long enough for Roblox to register it
    send_mouse(LEFTUP)


SCAN_DIGITS = {str(n): 0x02 + (n - 1) % 10 for n in range(1, 11)}
SCAN_DIGITS["0"] = 0x0B


def send_scan(scan, up=False):
    flags = 0x0008 | (0x0002 if up else 0)  # KEYEVENTF_SCANCODE (+ KEYUP)
    inp = INPUT(1, _InputUnion(ki=KEYBDINPUT(0, scan, flags, 0, 0)))
    if user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT)) != 1:
        raise OSError("SendInput was blocked")


def tap(key, hold=0.04):
    try:
        if key in SCAN_DIGITS:  # slot keys: send the raw scan code, held a little longer so Roblox sees it
            send_scan(SCAN_DIGITS[key])
            time.sleep(max(hold, 0.07))
            send_scan(SCAN_DIGITS[key], up=True)
        else:
            pydirectinput.keyDown(key)
            time.sleep(hold)
            pydirectinput.keyUp(key)
    except Exception as exc:
        log("ERR", f"key {key} failed: {exc}")


CHAR_SCAN = {" ": 0x39, ";": 0x27, "-": 0x0C, ".": 0x34, ",": 0x33, "/": 0x35, "'": 0x28}
for _row, _first in (("qwertyuiop", 0x10), ("asdfghjkl", 0x1E), ("zxcvbnm", 0x2C), ("1234567890", 0x02)):
    for _i, _c in enumerate(_row):
        CHAR_SCAN[_c] = _first + _i
SHIFTED = {":": ";", "_": "-", "?": "/", "!": "1", "@": "2", "#": "3", "$": "4", "%": "5", "&": "7", "(": "9", ")": "0"}
SC_SHIFT, SC_CTRL, SC_ENTER = 0x2A, 0x1D, 0x1C


def press_scan(scan, hold=0.04):
    send_scan(scan)
    time.sleep(hold)
    send_scan(scan, up=True)


def type_text(text, gap=0.07):
    """Types text with real scan-code key presses (shift for capitals and : etc). Unknown characters go in as unicode."""
    for ch in text:
        if paused.is_set() or shutdown.is_set():
            return
        base = SHIFTED.get(ch, ch.lower())
        shift = ch in SHIFTED or ch.isupper()
        try:
            if base in CHAR_SCAN:
                if shift:
                    send_scan(SC_SHIFT)
                    time.sleep(0.02)
                press_scan(CHAR_SCAN[base])
                if shift:
                    time.sleep(0.02)
                    send_scan(SC_SHIFT, up=True)
            else:  # not on the table: send it as a unicode character
                for up in (False, True):
                    inp = INPUT(1, _InputUnion(ki=KEYBDINPUT(0, ord(ch), 0x0004 | (0x0002 if up else 0), 0, 0)))
                    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
                    time.sleep(0.03)
        except Exception as exc:
            log("ERR", f"typing {ch!r} failed: {exc}")
        time.sleep(gap)


def focus_roblox():
    """Bring the Roblox window to the front so clicks and keys land in the game. Silent if it can't."""
    try:
        found = []
        proto = ctypes.WINDOWFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def each(hwnd, _lp):
            if user32.IsWindowVisible(hwnd):
                buf = ctypes.create_unicode_buffer(64)
                user32.GetWindowTextW(hwnd, buf, 64)
                rc = wintypes.RECT()
                user32.GetWindowRect(hwnd, ctypes.byref(rc))
                if buf.value == "Roblox" and rc.right - rc.left > 300 and rc.bottom - rc.top > 300:
                    found.append(hwnd)
            return True
        user32.EnumWindows(proto(each), 0)
        if found and user32.GetForegroundWindow() != found[0]:
            if user32.IsIconic(found[0]):
                user32.ShowWindow(found[0], 9)
            user32.SetForegroundWindow(found[0])
            time.sleep(0.15)
    except Exception:
        pass


def lock_on_press():
    key = cfg_live.get("lock_on", "")
    if not key:
        return
    if key == "mmb":
        send_mouse(MIDDLEDOWN)
        time.sleep(0.05)
        send_mouse(MIDDLEUP)
    else:
        tap(key, 0.05)
    log("LOCK", f"Lock On pressed ({'MMB' if key == 'mmb' else key.upper()})")
    time.sleep(0.1)


mouse_lock = threading.RLock()   # one thing moves the mouse at a time (Ready/Retry clicks vs slot clicks)


def equip_slot(k, why):
    """Equip slot k: press its key, or glide the mouse to its X/Y and click it once."""
    if cfg_live.get("slot_method", "Press key") != "Click position":
        tap(k)
        log("KEY", f"Slot {k} pressed ({why})")
        return
    try:
        x, y = cfg_live["slot_pos"][k]
    except Exception:
        log("ERR", f"Slot {k} has no X/Y set - pressing the key instead")
        tap(k)
        return
    with mouse_lock:
        focus_roblox()
        if paused.is_set() or shutdown.is_set() or not glide_to(x, y):
            return
        click()
    log("CLICK", f"Slot {k} clicked at ({x}, {y}) ({why})")


def boost_thread():
    """Give the calling thread high priority so image matching can't make the mouse stutter."""
    try:
        k = ctypes.windll.kernel32
        k.GetCurrentThread.restype = wintypes.HANDLE
        k.SetThreadPriority.argtypes = [wintypes.HANDLE, ctypes.c_int]
        k.SetThreadPriority(k.GetCurrentThread(), 2)
    except Exception:
        pass


def actor():
    boost_thread()
    while not shutdown.is_set():
        try:
            kind, x, y = actions.get(timeout=0.2)
        except queue.Empty:
            continue
        try:
            focus_roblox()
            log("MOVE", f"Moving to {kind} at ({int(x)}, {int(y)})")
            if paused.is_set() or not glide_to(x, y):
                continue
            cx, cy = cursor_pos()
            if abs(cx - int(x)) > 4 or abs(cy - int(y)) > 4:
                log("WARN", f"Cursor is at ({cx}, {cy}), not ({int(x)}, {int(y)}) - retrying with DirectInput move")
                try:
                    pydirectinput.moveTo(int(x), int(y))
                    time.sleep(0.1)
                    pydirectinput.moveRel(3, 0)
                    time.sleep(0.05)
                    pydirectinput.moveRel(-3, 0)
                    time.sleep(0.1)
                except Exception as exc:
                    log("ERR", f"DirectInput move failed: {exc}")
            count = 3 if kind == "ready" else 5
            for _ in range(count):
                if paused.is_set() or shutdown.is_set():
                    break
                click()
                time.sleep(0.16 + random.uniform(0, 0.06))
            if paused.is_set() or shutdown.is_set():
                continue
            if kind == "ready":
                if cfg_live.get("slot_when", "Both") in ("At Ready", "Both"):
                    for k in cfg_live["slots"]:  # the slot(s) picked in settings: 1, 2, or 1 then 2
                        equip_slot(k, "Ready")
                        time.sleep(0.15)
                if (cfg_live.get("slot_method") == "Click position" and cfg_live.get("lock_on") == "mmb"
                        and not paused.is_set() and not shutdown.is_set()):
                    # the cursor is still on the hotbar slot, and a middle click over a UI button does nothing:
                    # glide back out to where the Ready button was (open game view) before locking on
                    with mouse_lock:
                        glide_to(x, y)
                    time.sleep(0.1)
                lock_on_press()  # Lock On key, once, right after the slot key(s)
            now = time.monotonic()
            with lock:
                S["ready_block"] = now + READY_COOLDOWN
                if kind == "retry":
                    S["state"], S["result_block"] = IDLE, now + RESULT_COOLDOWN
            if kind == "ready":
                log("CLICK", f"Ready clicked {count}x")
            else:
                log("CLICK", f"Retry clicked {count}x")
        except Exception as exc:
            log("ERR", f"click failed: {exc}")
        finally:
            busy.clear()


# ---- attack rotation -------------------------------------------------------
def rotation_worker():
    """One full pass through the rotation keys per slot; with both slots it swaps after every pass."""
    keys, slots = cfg_live["rotation"], cfg_live["slots"]
    idx, was_attacking = 0, False
    while not shutdown.is_set():
        if not attacking.is_set() or paused.is_set():
            was_attacking = False
            time.sleep(0.02)
            continue
        if not was_attacking:  # attack just started: equip the first slot
            was_attacking, idx = True, 0
            focus_roblox()
            if cfg_live.get("slot_when", "Both") in ("At attack start", "Both"):
                equip_slot(slots[0], "attack start")
                time.sleep(SLOT_SWAP_DELAY)
            log("KEY", f"Rotation: {' '.join(k.upper() for k in keys)}")
        finished = True
        for k in keys:
            if not attacking.is_set() or paused.is_set() or shutdown.is_set():
                finished = False
                break
            tap(k, 0.03)
            time.sleep(KEY_GAP)
        if finished and len(slots) > 1 and attacking.is_set() and not paused.is_set():
            idx = (idx + 1) % len(slots)
            equip_slot(slots[idx], "swap")
            time.sleep(SLOT_SWAP_DELAY)


# ---- auto rejoin -----------------------------------------------------------
def select_all():
    """Ctrl+A, so typing replaces whatever is already in the search box."""
    try:
        send_scan(SC_CTRL)
        press_scan(CHAR_SCAN["a"])
        send_scan(SC_CTRL, up=True)
    except Exception as exc:
        log("ERR", f"Ctrl+A failed: {exc}")


def rejoin_click(label, x, y, clicks):
    with mouse_lock:
        focus_roblox()
        log("MOVE", f"Rejoin: moving to {label} at ({int(x)}, {int(y)})")
        if paused.is_set() or shutdown.is_set() or not glide_to(x, y):
            return False
        for _ in range(clicks):
            if paused.is_set() or shutdown.is_set():
                return False
            click()
            time.sleep(0.16 + random.uniform(0, 0.06))
    log("CLICK", f"Rejoin: {label} clicked {clicks}x")
    return True


def rejoin_wait(sct, key):
    """Looks ONLY for this step's image (plus the disconnect box, in case the Leave click missed).
    Returns ("hit", pos), ("dc", pos) if the disconnect box is on screen, or (None, None) if the macro was stopped."""
    t0 = last_warn = time.monotonic()
    rival = RIVALS.get(key)
    while not (shutdown.is_set() or paused.is_set()):
        r = match(key, grab_gray(sct, key))
        if r and rival:  # look-alike button (Create 1 vs Create 2): only count it if the rival doesn't fit better
            rv = match(rival, grab_gray(sct, rival))
            if rv and rv[2] > r[2] and abs(rv[0] - r[0]) < 40 and abs(rv[1] - r[1]) < 40:  # same spot, rival fits better
                r = None
        if r:
            return "hit", r
        d = match("disconnect", grab_gray(sct, "disconnect"))
        if d:
            return "dc", d
        now = time.monotonic()
        if now - last_warn >= 60:
            last_warn = now
            log("WARN", f"Rejoin: still looking for {IMAGES[key][1]} ({int(now - t0)}s) - check its search area, or click it yourself")
        time.sleep(0.1)
    return None, None


def rejoin_gone(sct, key, timeout=5.0):
    """After a step's clicks: wait until that image has left the screen, so the next step can't mistake it for its own."""
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout and not (shutdown.is_set() or paused.is_set()):
        if not match(key, grab_gray(sct, key)):
            return True
        time.sleep(0.15)
    return False


def rejoin_run(first_hit):
    """The whole protocol, strictly in order: step 1 (Leave) to step 13 (Start). Returns True when Start was clicked."""
    hit = first_hit
    with (mss.MSS() if hasattr(mss, "MSS") else mss.mss()) as sct:
        while not (shutdown.is_set() or paused.is_set()):
            S["rj_step"] = 1
            log("JOIN", f"Step 1/{REJOIN_TOTAL}: Leave")
            if not rejoin_click("Leave", hit[0], hit[1], 1):
                return False
            rejoin_gone(sct, "disconnect", 6.0)
            time.sleep(1.0)
            again = False
            for n, key, clicks, do_type in REJOIN_STEPS:
                label = IMAGES[key][1]
                S["rj_step"] = n
                log("JOIN", f"Step {n}/{REJOIN_TOTAL}: looking for {label}")
                kind, r = rejoin_wait(sct, key)
                if kind is None:
                    return False
                if kind == "dc":
                    log("JOIN", "The Disconnected box is still (or again) on screen - back to step 1 (Leave)")
                    hit, again = r, True
                    break
                if not rejoin_click(label, r[0], r[1], clicks):
                    return False
                log("JOIN", f"Step {n}/{REJOIN_TOTAL} done: {label}")
                if do_type:
                    text = cfg_live.get("rejoin_text") or REJOIN_TEXT
                    time.sleep(0.7)
                    select_all()
                    time.sleep(0.1)
                    log("JOIN", f"Step {n}/{REJOIN_TOTAL}: typing {text!r} and pressing Enter")
                    type_text(text)
                    time.sleep(0.25)
                    press_scan(SC_ENTER, 0.07)
                elif n != REJOIN_TOTAL:
                    rejoin_gone(sct, key)   # don't move on until this button is off the screen
                time.sleep(REJOIN_SETTLE)
            if not again:
                S["rj_step"] = 0
                return True
    return False


def rejoin_worker(first_hit):
    boost_thread()
    ok = False
    try:
        log("JOIN", "Disconnected box found - REJOIN PROTOCOL started (every other image search is off)")
        ok = rejoin_run(first_hit)
    except Exception as exc:
        log("ERR", f"rejoin failed: {exc}")
    finally:
        if ok:
            with lock:
                S.update(state=IDLE, phase2=False, result_block=0.0, ready_block=0.0)
            attacking.clear()
            log("JOIN", f"Rejoin finished (rejoin #{S['rejoins']}) - normal scanning is back on")
        elif not shutdown.is_set():
            log("JOIN", "Rejoin stopped - normal scanning is back on")
        S["rj_step"] = 0
        busy.clear()
        rejoining.clear()


def start_rejoin(hit):
    rejoining.set()
    attacking.clear()
    busy.clear()
    while not actions.empty():
        try:
            actions.get_nowait()
        except queue.Empty:
            break
    release_keys()
    with lock:
        S.update(state=IDLE, phase2=False)
        S["rejoins"] += 1
    threading.Thread(target=rejoin_worker, args=(hit,), daemon=True).start()


def release_keys():
    for k in cfg_live.get("rotation", []):
        try:
            pydirectinput.keyUp(k)
        except Exception:
            pass


# ---- scanner / state machine -----------------------------------------------
def on_result(win):
    cfg = cfg_live
    with lock:
        S["state"], S["phase2"], S["retry_since"] = WAIT_RETRY, False, time.monotonic()
        if win:
            S["loops"] += 1
        loops = S["loops"]
    attacking.clear()
    if win:
        log("WIN", f"Raid beaten  |  Loops: {loops}")
        if not cfg["loops_inf"] and loops >= cfg["loops_count"]:
            log("INFO", f"Reached {cfg['loops_count']} loops - stopping")
            shutdown.set()
    else:
        log("LOSE", f"Raid failed - heading to Retry  |  Loops stay at {loops}")


def tick(sct):
    now = time.monotonic()
    cache = {}
    keys = SCAN_KEYS + (("disconnect",) if cfg_live.get("rejoin", True) else ())  # the disconnect box is searched 24/7
    grays = {k: grab_gray(sct, k, cache) for k in keys}    # screen grabs on this thread
    jobs = {k: pool.submit(match, k, grays[k]) for k in keys}  # matching runs in parallel
    hits = {k: jobs[k].result() for k in keys}
    if hits.get("disconnect"):
        return start_rejoin(hits["disconnect"])
    with lock:
        state, block, ready_block = S["state"], S["result_block"], S["ready_block"]
    if state != WAIT_RETRY and now >= block:
        s, f = hits["success"], hits["failed"]
        if s and (not f or s[2] >= f[2]):
            return on_result(True)
        if f:
            return on_result(False)
    if state == WAIT_RETRY:
        if now - S["retry_since"] > RETRY_TIMEOUT:
            with lock:
                S["state"] = IDLE
            return log("WARN", "Retry never showed up - going back to normal scanning")
        if not busy.is_set():
            r = match("retry", grab_gray(sct, "retry", cache))
            if r:
                busy.set()
                actions.put(("retry", r[0], r[1]))
        return
    if busy.is_set():
        return
    if hits["ready"] and now >= ready_block:
        with lock:
            S["state"], S["phase2"] = IDLE, False
        attacking.clear()
        busy.set()
        log("RAID", "Ready found - raid starting")
        actions.put(("ready", hits["ready"][0], hits["ready"][1]))
        return
    if hits["zenin"] and state == IDLE:
        with lock:
            S["state"] = RAID
        log("RAID", "Zen'in Elite found - raid started, attacking")
        attacking.set()
    if hits["chase"]:
        with lock:
            first = not S["phase2"]
            S["phase2"] = True
            if S["state"] == IDLE:
                S["state"] = RAID
        if first:
            log("PHASE", "Chase took too long - phase 2 started")
            attacking.set()


def scanner():
    last_dbg = time.monotonic()
    with (mss.MSS() if hasattr(mss, "MSS") else mss.mss()) as sct:
        while not shutdown.is_set():
            if DEBUG_SCORES and time.monotonic() - last_dbg >= DEBUG_EVERY:
                last_dbg = time.monotonic()
                try:
                    match("retry", grab_gray(sct, "retry"))  # Retry is normally only searched after a result - check it here too
                except Exception:
                    pass
                log("DBG", "best score/needed@size  " + "  ".join(
                    f"{k}={BEST.get(k, (0.0, 0.0))[0]:.2f}/{IMAGES[k][2]:.2f}@{BEST.get(k, (0.0, 0.0))[1]:.2f}"
                    for k in SCAN_KEYS + ("retry",)))
                BEST.clear()
            t0 = time.monotonic()
            if paused.is_set():
                time.sleep(0.1)
                continue
            if rejoining.is_set():  # rejoin protocol running: it does its own searching
                time.sleep(0.1)
                continue
            if busy.is_set():  # mouse is moving/clicking: leave the CPU to it so it stays smooth
                time.sleep(0.01)
                continue
            try:
                tick(sct)
            except Exception as exc:
                log("ERR", f"scan error: {exc}")
                time.sleep(0.5)
            time.sleep(max(0.0, SCAN_DELAY - (time.monotonic() - t0)))


# ---- stop key / log clearer ------------------------------------------------
def toggle_pause():
    if paused.is_set():
        with lock:
            S.update(state=IDLE, phase2=False, result_block=0.0, ready_block=0.0)
        paused.clear()
        log("RUN", "Restarted - scanning again")
    else:
        paused.set()
        attacking.clear()
        busy.clear()
        while not actions.empty():
            try:
                actions.get_nowait()
            except queue.Empty:
                break
        release_keys()
        log("STOP", f"Macro stopped - press {cfg_live['stop_key'].upper()} again to restart")


def hotkey_watcher():
    vk = 0x6F + int(cfg_live["stop_key"][1:])  # F1 = 0x70
    was = False
    while not shutdown.is_set():
        down = bool(user32.GetAsyncKeyState(vk) & 0x8000)
        if down and not was:
            toggle_pause()
        was = down
        time.sleep(0.02)


def log_clearer():
    every = cfg_live["log_clear"] * 60
    last = time.monotonic()
    while not shutdown.is_set():
        time.sleep(1.0)
        if time.monotonic() - last >= every:
            last = time.monotonic()
            print_header(cfg_live)
            log("INFO", f"Console cleared (every {cfg_live['log_clear']} min)  |  Loops: {S['loops']}  "
                        f"|  Time: {fmt_time(time.monotonic() - start_time)}")


# ---- stats window ----------------------------------------------------------
def run_stats_window():
    root = tk.Tk()
    root.title(APP_NAME)
    root.configure(bg=BG)
    root.attributes("-topmost", True)
    root.resizable(False, False)
    root.geometry(f"260x205+{max(0, root.winfo_screenwidth() - 290)}+40")
    tk.Label(root, text="CALAMITY CLEAVER \u25c6", bg=BG, fg=RED, font=("Segoe UI Black", 11)).pack(pady=(10, 0))
    tk.Label(root, text="Made By Diamond/Lemon", bg=BG, fg=ACCENT, font=(FONT, 8, "bold")).pack(pady=(0, 6))
    loops_lb = tk.Label(root, bg=BG, fg=FG, font=(FONT, 14, "bold"))
    time_lb = tk.Label(root, bg=BG, fg=FG, font=(FONT, 14, "bold"))
    state_lb = tk.Label(root, bg=BG, fg=GREEN, font=(FONT, 9, "bold"))
    rejoin_lb = tk.Label(root, bg=BG, fg=MUTED, font=(FONT, 10, "bold"))
    loops_lb.pack()
    time_lb.pack()
    rejoin_lb.pack()
    state_lb.pack(pady=(4, 0))

    def update():
        elapsed = fmt_time(time.monotonic() - start_time)
        loops_lb.config(text=f"Loops  {S['loops']}")
        time_lb.config(text=f"Time  {elapsed}")
        rejoin_lb.config(text=f"Rejoins  {S['rejoins']}")
        if paused.is_set():
            state_lb.config(text="STOPPED", fg=RED)
        elif rejoining.is_set():
            state_lb.config(text=f"REJOINING  step {S['rj_step']}/{REJOIN_TOTAL}", fg="#ffb84d")
        else:
            state_lb.config(text="RUNNING", fg=GREEN)
        try:
            ctypes.windll.kernel32.SetConsoleTitleW(f"\u25c6 {APP_NAME} | Loops {S['loops']} | {elapsed}")
        except Exception:
            pass
        if shutdown.is_set():
            root.destroy()
        else:
            root.after(250, update)

    def on_close():
        shutdown.set()
        root.destroy()
    root.protocol("WM_DELETE_WINDOW", on_close)
    update()
    root.mainloop()


def main():
    global start_time
    ensure_images()
    cfg = run_settings(load_settings()) if tk else None
    gc.collect()  # destroy leftover Tk objects here, on the main thread (stops Tcl_AsyncDelete crash)
    if cfg is None:
        return
    cfg_live.update(cfg)
    enable_console()
    log_path = init_log(cfg)
    load_templates(cfg)
    print_header(cfg)
    log("INFO", "Settings saved - macro launched")
    if log_path:
        log("INFO", f"Logging to logs\\{log_path.name}  (send me this file if something goes wrong)")
    start_time = time.monotonic()
    try:
        with (mss.MSS() if hasattr(mss, "MSS") else mss.mss()) as _s:
            for _k, (_l, _t, _r, _b) in regions.items():
                if _k in REJOIN_KEYS:
                    continue
                _img = np.asarray(_s.grab({"left": _l, "top": _t, "width": _r - _l, "height": _b - _t}))
                cv2.imwrite(str(LOG_DIR / f"debug_area_{_k}.png"), _img[:, :, :3])
        log("INFO", "Saved debug_area_*.png (what each search box sees) in the logs folder")
    except Exception as exc:
        log("WARN", f"could not save debug screenshots: {exc}")
    for target in (scanner, actor, rotation_worker, hotkey_watcher, log_clearer):
        threading.Thread(target=target, daemon=True).start()
    log("RUN", f"Scanning every {int(SCAN_DELAY * 1000)} ms  |  {cfg['stop_key'].upper()} stops / restarts")
    try:
        gc.disable()  # worker threads must never trigger cleanup of Tk objects
        run_stats_window()
        gc.enable()
        gc.collect()
        while not shutdown.is_set():
            time.sleep(0.25)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown.set()
        attacking.clear()
        time.sleep(0.2)
        release_keys()
        log("INFO", f"Stopped  |  Loops: {S['loops']}  |  Time: {fmt_time(time.monotonic() - start_time)}")


def _thread_crash(args):
    tb = "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback))
    if log_fh is not None:
        log_fh.write(f"THREAD CRASH ({args.thread.name if args.thread else '?'})\n{tb}\n")
    traceback.print_exception(args.exc_type, args.exc_value, args.exc_traceback)


threading.excepthook = _thread_crash

if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        tb = traceback.format_exc()
        traceback.print_exc()
        if log_fh is not None:
            log_fh.write("CRASH\n" + tb + "\n")
        sys.exit(1)
